use strict;

our $listname = 'hdbclient.lst';

sub getExternalFileListName{
    return $listname;
}

1;
