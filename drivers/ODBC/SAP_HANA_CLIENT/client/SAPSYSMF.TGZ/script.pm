sub Postinstall{
    # load/refresh manifest
    $_[0]->{installation}->getManifest (1);
}

1;
