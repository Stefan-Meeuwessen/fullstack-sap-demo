package main

import (
	"bytes"
	"context"
	"database/sql"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"

	driver "SAP/go-hdb/driver"
)

func testBasic(connStr string, tableName string, id int, bArr []byte, cArr []byte) {
	fmt.Println("Testing insert of LOB data directly")
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	res := doBasicInsert(db, tableName, id, bArr, cArr)

	rowsAffected, err := res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("%d rows affected ", rowsAffected)

	doSelectAndCompare(db, tableName, id, bArr, cArr)
}

// LOB writing
// The lob write chunks are controlled by the control property lobChunkSize
func testFileWriteLOBInsert(connStr string, tableName string, id int) {
	fmt.Println("Testing insert of LOB data using WriteLOB from a file")
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	stmt, err := db.Prepare(fmt.Sprintf("INSERT INTO %s VALUES(?, ?, ?)", tableName))

	if err != nil {
		log.Fatal(err)
	}

	defer stmt.Close()

	theString := "aaaaa"
	// The files will be closed by the WriteLOB
	file, err := os.Open(createTemporaryFileWithContent(theString))
	defer os.Remove(file.Name())

	if err != nil {
		log.Fatal(err)
	}
	file2, err := os.Open(createTemporaryFileWithContent(theString))
	defer os.Remove(file2.Name())
	if err != nil {
		log.Fatal(err)
	}

	lob1 := driver.NewWriteLOB(file)
	lob2 := driver.NewWriteLOB(file2)

	_, err = stmt.Exec(id, lob1, lob2)

	if err != nil {
		log.Fatal(err)
	}

	theBytes := []byte(theString)
	doSelectAndCompare(db, tableName, id, theBytes, theBytes)
}

// Piecewise LOB writing
// The lob write chunks are controlled by the control property lobChunkSize
func testPipedWriteLOBInsert(connStr string, tableName string, id int, bArr []byte, cArr []byte) {
	fmt.Println("Testing chunked insert of LOB data using WriteLOB from piped buffer")
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	stmt, err := db.Prepare(fmt.Sprintf("INSERT INTO %s VALUES(?, ?, ?)", tableName))

	if err != nil {
		log.Fatal(err)
	}

	pipeWriters := make([]*io.PipeWriter, 2)
	insertValues := make([]interface{}, 3)
	insertValues[0] = id

	for i := 1; i < 3; i++ {
		pipeReader, pipeWriter := io.Pipe()
		pipeWriters[i - 1] = pipeWriter
		insertValues[i] = driver.NewWriteLOB(pipeReader)
	}

	errors := make(chan error)

	go func() {
		res, err := stmt.Exec(insertValues...)

		if err != nil {
			errors <- err
		} else {
			errors <- verifyRowsAffected(res)
		}
	}()

	// Actually put the data to write
	for i := 0; i < len(pipeWriters); i++ {
		if i == 0 {
			pipeWriters[i].Write(bArr)
		} else {
			pipeWriters[i].Write(cArr)
		}

		pipeWriters[i].Close() // Signal end
	}

	err = <-errors

	if err != nil {
		log.Fatalf("%v", err)
	}

	doSelectAndCompare(db, tableName, id, bArr, cArr)
}

// Piecewise LOB reading
// The lob writing is controlled by the control property lobChunkSize
// Note, that data must be inserted via testBasic() for this to work
func testPipedReadLOBFetch(connStr string, tableName string, id int, bArr []byte, cArr []byte) {
	fmt.Println("Testing fetch of LOB data using ReadLOB")
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	_ = doBasicInsert(db, tableName, id, bArr, cArr)

	queryStmt, err := db.Prepare(fmt.Sprintf("select b, c from %s where a=?", tableName))
	if err != nil {
		log.Fatal(err)
	}
	defer queryStmt.Close()

	dataBuffers := make([]bytes.Buffer, 2)
	pipeReaders := make([]*io.PipeReader, 2)
	readValues := make([]interface{}, 2)

	for i := 0; i < 2; i++ {
		pipeReader, pipeWriter := io.Pipe()
		pipeReaders[i] = pipeReader
		readValues[i] = driver.NewReadLOB(pipeWriter)
	}

	errors := make(chan error)

	go func() {
		ctx := driver.NewReadLobFetchContext(context.Background())
		err := queryStmt.QueryRowContext(ctx, id).Scan(readValues...)
		errors <- err
	}()

	for i := 0; i < len(pipeReaders); i++ {
		_, err := dataBuffers[i].ReadFrom(pipeReaders[i])

		if err != nil {
			log.Fatal(err)
		}

		pipeReaders[i].Close()
	}

	err = <-errors

	if err != nil {
		log.Fatalf("%v", err)
	}

	if !bytes.Equal(bArr, dataBuffers[0].Bytes()) {
		log.Fatalf("Expected blob data: %v but found blob data: %v",
			bArr, dataBuffers[0].Bytes())
	}

	if !bytes.Equal(cArr, dataBuffers[1].Bytes()) {
		log.Fatalf("Expected nclob data : %v but found nclob data: %v",
			cArr, dataBuffers[1].Bytes())
	}
}

func testPipedReadLOBColumnsFetchNulls(connStr string, tableName string, id int) {
	fmt.Println("Testing fetch of Null LOB data using ReadLOB")
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	_ = doNullInsert(db, tableName, id)

	queryStmt, err := db.Prepare(fmt.Sprintf("select b, c from %s where a=?", tableName))
	if err != nil {
		log.Fatal(err)
	}
	defer queryStmt.Close()

	dataBuffers := make([]bytes.Buffer, 2)
	pipeReaders := make([]*io.PipeReader, 2)
	readValues := make([]interface{}, 2)
	readLOBs := make([]*driver.NullReadLOB, 2)

	for i := 0; i < 2; i++ {
		pipeReader, pipeWriter := io.Pipe()
		pipeReaders[i] = pipeReader
		nullReadLOB := driver.NewNullReadLOB(pipeWriter)
		readValues[i] = nullReadLOB
		readLOBs[i] = nullReadLOB
	}

	errors := make(chan error)

	go func() {
		ctx := driver.NewReadLobFetchContext(context.Background())
		err := queryStmt.QueryRowContext(ctx, id).Scan(readValues...)
		errors <- err
	}()

	for i := 0; i < len(pipeReaders); i++ {
		_, err := dataBuffers[i].ReadFrom(pipeReaders[i])

		if err != nil {
			log.Fatal(err)
		}

		pipeReaders[i].Close()
	}

	err = <-errors

	if err != nil {
		log.Fatalf("%v", err)
	}

	if readLOBs[0].Valid {
		log.Fatalf("Expected blob data to be NULL but found blob data: %v",
			dataBuffers[0].Bytes())
	}

	if readLOBs[1].Valid {
		log.Fatalf("Expected nclob data to be NULL but found nclob data: %v",
			dataBuffers[1].Bytes())
	}
}

// Helpers
func createTable(connStr string, tableName string) {
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	//Drop the table if it exists and ignore the errors
	_, _ = db.Exec(fmt.Sprintf("DROP TABLE %s", tableName))

	//Create a table
	_, err = db.Exec(fmt.Sprintf("CREATE TABLE %s (A INT UNIQUE,B BLOB, C NCLOB)", tableName))

	if err != nil {
		log.Fatal(err)
	}
}

func createTemporaryFileWithContent(content string) string {
	dir, err := os.Getwd()

	if err != nil {
		log.Fatal(err)
	}

	file, err := os.CreateTemp(dir, "lob_insert_test")

	if err != nil {
		log.Fatal(err)
	}

	defer file.Close()

	if _, err := file.Write([]byte(content)); err != nil {
		log.Fatal(err)
	}

	return file.Name()
}

func verifyRowsAffected(res sql.Result) error {
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected != 1 {
		return fmt.Errorf("Expected rows affected: 1 but found %d ", rowsAffected)
	}

	id, err := res.LastInsertId()
	if err == nil {
		return errors.New("Expected error found no error")
	}
	if id != -1 {
		return fmt.Errorf("Expected last inserted id: -1 but found %d ", id)
	}
	return nil
}

func doBasicInsert(db *sql.DB, tableName string, id int, bArr []byte, cArr []byte) sql.Result {
	stmt, err := db.Prepare(fmt.Sprintf("INSERT INTO %s VALUES(?, ?, ?)", tableName))

	if err != nil {
		log.Fatal(err)
	}

	res, err := stmt.Exec(id, bArr, cArr)
	if err != nil {
		log.Fatal(err)
	}

	stmt.Close()
	return res
}

func doNullInsert(db *sql.DB, tableName string, id int) sql.Result {
	stmt, err := db.Prepare(fmt.Sprintf("INSERT INTO %s VALUES(?, ?, ?)", tableName))

	if err != nil {
		log.Fatal(err)
	}

	res, err := stmt.Exec(id, nil, nil)
	if err != nil {
		log.Fatal(err)
	}

	stmt.Close()
	return res
}

func doSelectAndCompare(db *sql.DB, tableName string, intVal int, binVal []byte,
	chVal []byte) {
	var (
		retBinVal []byte
		retChVal  []byte
	)
	queryStmt, err := db.Prepare(fmt.Sprintf("select b, c from %s where a=?", tableName))
	if err != nil {
		log.Fatal(err)
	}
	defer queryStmt.Close()

	err = queryStmt.QueryRow(intVal).Scan(&retBinVal, &retChVal)

	if err != nil {
		log.Fatal(err)
	}

	if !bytes.Equal(binVal, retBinVal) {
		log.Fatalf("Expected lob of length: %d but found lob of length: %d", len(binVal), len(retBinVal))
	}

	if !bytes.Equal(chVal, retChVal) {
		log.Fatalf("Expected lob of length: %d but found lob of length: %d", len(chVal), len(retChVal))
	}
}
//^^Helpers

//To run this use: go run lob_examples.go -dsn hdb://user:password@host:port
func main() {
	var connStr string
	//dsn is of the form: hdb://user:password@host:port?connectProp1=value&connectProp2=value
	flag.StringVar(&connStr, "dsn", "hdb://user:password@host:port", "database dsn")

	if !flag.Parsed() {
		flag.Parse()
	}

	tableName := "TESTTABLE"
	createTable(connStr, tableName)

	// Data to insert/verify
	bArr := make([]byte, 100000)
	cArr := make([]byte, 100000)

	for i := 0; i < len(bArr); i++ {
		cArr[i] = 'A' + uint8(i%26)
		bArr[i] = uint8(i % 2)
	}

	testBasic(connStr, tableName, 1, bArr, cArr)
	testFileWriteLOBInsert(connStr, tableName, 2)
	testPipedWriteLOBInsert(connStr, tableName, 3, bArr, cArr)
	testPipedReadLOBFetch(connStr, tableName, 4, bArr, cArr)
	testPipedReadLOBColumnsFetchNulls(connStr, tableName, 5)
}
