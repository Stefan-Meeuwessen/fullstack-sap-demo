package main

import (
	driver "SAP/go-hdb/driver"
	"context"
	"database/sql"
	"flag"
	"fmt"
	"log"
	"os/exec"
	"reflect"
	"strings"
)

func testVendorErrorsFromDB(connStr string) {
	badDsn := "hdb://invaliduser:invalidpassword@invalidhostname"
	db1, err := sql.Open("hdb", badDsn)
	if err != nil {
		log.Fatal(err)
	}
	defer db1.Close()
	ctx := driver.NewPingDetailedErrorContext(context.Background())

	if db1 != nil {
		defer db1.Close()
		err = db1.PingContext(ctx)

		validateError(err, driver.ErrorLevel_Error, 10, "authentication failed", "HY000")
	} else {
		validateError(err, driver.ErrorLevel_Error, 10, "authentication failed", "HY000")
	}

	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	_, err = db.Exec("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = db.ExecContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = db.Prepare("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = db.PrepareContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = db.Query("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = db.QueryContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")
}

func testVendorErrorsFromConn(connStr string) {
	badDsn := "hdb://invaliduser:invalidpassword@invalidhost"
	db1, err := sql.Open("hdb", badDsn)
	if err != nil {
		log.Fatal(err)
	}
	ctx := driver.NewPingDetailedErrorContext(context.Background())

	if db1 != nil {
		defer db1.Close()
		conn, err := db1.Conn(context.Background())

		if err != nil {
			validateError(err, driver.ErrorLevel_Error, 10, "authentication failed", "HY000")
		} else {
			err = conn.PingContext(ctx)
		}
	} else {
		validateError(err, driver.ErrorLevel_Error, 10, "authentication failed", "HY000")
	}

	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	conn, err := db.Conn(context.Background())

	if err != nil {
		log.Fatal(err)
	}

	_, err = conn.ExecContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = conn.PrepareContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = conn.QueryContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")
}

func testVendorErrorsFromTx(db *sql.DB) {
	tx, _ := db.Begin()
	defer tx.Rollback()

	_, err := tx.Exec("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = tx.ExecContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = tx.Prepare("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = tx.PrepareContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = tx.Query("Invalid")

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")

	_, err = tx.QueryContext(context.Background(), "Invalid") // This is an error

	validateError(err, driver.ErrorLevel_Error, 257,
		"sql syntax error: incorrect syntax near \"Invalid\"",
		"HY000")
}

func testVendorErrorsFromStmt(db *sql.DB) {
	schemaName := getUniqueNameStartingWith("GolangTestStmtErrors")
	tableName := "TestTable"
	createSchema(db, schemaName)
	defer dropSchema(db, schemaName)
	createTableInSchema(db, schemaName + ".", tableName, "(a tinyint)")
	stmt, err := db.Prepare("insert into " + schemaName + "." + tableName + "(a) values (?)")

	if err != nil {
		log.Fatal(err)
	}

	defer stmt.Close()
	_, err = stmt.Exec()

	if err == nil {
		log.Fatal("Expected error on insert but got no error")
	}

	validateError(err, driver.ErrorLevel_Error, -11103,
		"Expected number of input parameters: 1, got: 0", "HY000")

	const MaxUint = ^uint(0)
	const MaxInt = int(MaxUint >> 1)

	_, err = stmt.Exec(MaxInt)

	if err == nil {
		log.Fatal("Expected error on insert but got no error")
	}

	validateError(err, driver.ErrorLevel_Error, -10427, "provided number of out range", "HY000")

	_, err = stmt.ExecContext(context.Background(), MaxInt)

	if err == nil {
		log.Fatal("Expected error on insert but got no error")
	}

	validateError(err, driver.ErrorLevel_Error, -10427, "provided number of out range", "HY000")

	stmt2, err := db.Prepare("select a from " + schemaName + "." + tableName + " where a = ?")

	if err != nil {
		log.Fatal(err)
	}

	defer stmt2.Close()

	_, err = stmt2.Query(MaxInt)

	if err == nil {
		log.Fatal("Expected error on insert but got no error")
	}

	validateError(err, driver.ErrorLevel_Error, -10427, "provided number of out range", "HY000")

	_, err = stmt2.QueryContext(context.Background(), MaxInt)

	if err == nil {
		log.Fatal("Expected error on insert but got no error")
	}

	validateError(err, driver.ErrorLevel_Error, -10427, "provided number of out range", "HY000")
}

func TestVendorErrorsErrorsFromRows(db *sql.DB) {
	schemaName := getUniqueNameStartingWith("GolangTestStmtErrors")
	tableName := "TestTable"
	createSchema(db, schemaName)
	defer dropSchema(db, schemaName)
	createTableInSchema(db, schemaName + ".", tableName, "(a int, b nvarchar(20))")
	stmt, err := db.Prepare("insert into " + schemaName + "." + tableName + "(a, b) values (?, ?)")

	if err != nil {
		log.Fatal(err)
	}

	defer stmt.Close()


	inputData := make([][]interface{}, 4)
	for i := 0; i < len(inputData); i++ {
		inputData[i] = []interface{}{int(i + 1), "aaaa"}
	}

	_, err = stmt.Exec(inputData)

	if err != nil {
		log.Fatal(err)
	}

	// Fetch with an unknown type to the driver = driver-level error
	// Bulk fetching = driver-level error
	const MaxUint = ^uint(0)
	const MaxInt = int(MaxUint >> 1)

	rows, err := db.Query("select a from " + schemaName + "." + tableName)

	if err != nil {
		log.Fatal(err)
	}

	defer rows.Close()

	var (
		bulkBytes   driver.BulkNullBytes
		bulkInts    driver.BulkNullInt64
		bulkFloats  driver.BulkNullFloat64
		bulkBools   driver.BulkNullBool
		bulkTimes   driver.BulkNullTime
		bulkStrings driver.BulkNullString
	)

	// Easiest is driver-level error from bulk fetching
	count := 0
	for rows.Next() {
		switch count {
		case 3:
			err = rows.Scan(&bulkStrings)
		case 2:
			err = rows.Scan(&bulkTimes)
		case 1:
			err = rows.Scan(&bulkBools)
		case 0:
			fallthrough
		default:
			err = rows.Scan(&bulkFloats)
		}

		if err == nil {
			log.Fatalf("Count %d: Expected error fetching data into object but got no error",
				count)
		} else {
			// In this case, we don't really get a HdbError, we get a generic error that contains
			// the error text from our internal error (obtained from the Error() implementation)
			// validateError(t, err, ErrorLevel_Error, -11102, "Error: Not bulk fetching", "HY000")
			if !strings.Contains(err.Error(), "-11102: Error: Not bulk fetching") {
				log.Fatalf(
					"Count %d: Expected HANA specific error while fetching data, but got: \"%v\"",
					count, err)
			}
		}

		count++
	}

	rows2, err := db.Query("select b from " + schemaName + "." + tableName)

	if err != nil {
		log.Fatal(err)
	}

	defer rows2.Close()
	count = 0

	for rows.Next() {
		switch count {
		case 1:
			err = rows.Scan(&bulkInts)
		case 0:
			fallthrough
		default:
			err = rows.Scan(&bulkBytes)
		}

		if err == nil {
			log.Fatalf("Count %d: Expected error fetching data into object but got no error",
				count)
		} else {
			// In this case, we don't really get a HdbError, we get a generic error that contains
			// the error text from our internal error (obtained from the Error() implementation)
			// validateError(t, err, ErrorLevel_Error, -11102, "Error: Not bulk fetching", "HY000")
			if !strings.Contains(err.Error(), "-11102: Error: Not bulk fetching") {
				log.Fatalf(
					"Count %d: Expected HANA specific error while fetching data, but got: \"%v\"",
					count, err)
			}
		}

		count++
	}
}

func testVendorWarningsFromDB(connStr string) {
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	schemaName := getUniqueNameStartingWith("GOLANGTESTSTMTERRORS")
	procedureName := "Warn"
	createSchema(db, schemaName)
	defer dropSchema(db, schemaName)
	setupStoredProcedureGeneratingWarning(db, schemaName, procedureName)
	doWarningsTestForDB(connStr, "", schemaName, procedureName, false) // not specified = default = disabled => no warning returned (we skip setting the property)
	doWarningsTestForDB(connStr, "0", schemaName, procedureName, false) // specified as "0" = disabled => no warning returned
	doWarningsTestForDB(connStr, "false", schemaName, procedureName, false) // specified as "false" = disabled => no warning returned
	doWarningsTestForDB(connStr, "off", schemaName, procedureName,  false) // specified as "off" = disabled => no warning returned
	doWarningsTestForDB(connStr, "no", schemaName, procedureName, false) // specified as "no" = disabled => no warning returned
	doWarningsTestForDB(connStr, "true", schemaName, procedureName, true) // specified as "t" = true => warning returned
	doWarningsTestForDB(connStr, "yes", schemaName, procedureName, true) // specified as "yes" = true => warning returned
	doWarningsTestForDB(connStr, "on", schemaName, procedureName, true) // specified as "on" = true => warning returned
	doWarningsTestForDB(connStr, "1", schemaName, procedureName, true) // specified as "1" = true => warning returned
}

func testVendorWarningsFromStmt(connStr string) {
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	schemaName := getUniqueNameStartingWith("GOLANGTESTSTMTERRORS")
	procedureName := "Warn"
	createSchema(db, schemaName)
	defer dropSchema(db, schemaName)
	setupStoredProcedureGeneratingWarning(db, schemaName, procedureName)
	doWarningsTestForStmt(connStr, "", schemaName, procedureName, false) // not specified = default = disabled => no warning returned (we skip setting the property)
	doWarningsTestForStmt(connStr, "0", schemaName, procedureName, false) // specified as "0" = disabled => no warning returned
	doWarningsTestForStmt(connStr, "false", schemaName, procedureName, false) // specified as "false" = disabled => no warning returned
	doWarningsTestForStmt(connStr, "off", schemaName, procedureName,  false) // specified as "off" = disabled => no warning returned
	doWarningsTestForStmt(connStr, "no", schemaName, procedureName, false) // specified as "no" = disabled => no warning returned
	doWarningsTestForStmt(connStr, "true", schemaName, procedureName, true) // specified as "t" = true => warning returned
	doWarningsTestForStmt(connStr, "yes", schemaName, procedureName, true) // specified as "yes" = true => warning returned
	doWarningsTestForStmt(connStr, "on", schemaName, procedureName, true) // specified as "on" = true => warning returned
	doWarningsTestForStmt(connStr, "1", schemaName, procedureName, true) // specified as "1" = true => warning returned
}

func dropSchema(db *sql.DB, schemaName string) {
	_, _ = db.Exec("drop schema " + schemaName + " cascade")
}

func createSchema(db *sql.DB, schemaName string) {
	dropSchema(db, schemaName)
	_, err := db.Exec("create schema " + schemaName)

	if err != nil {
		log.Fatal(err)
	}
}

func createTableInSchema(db *sql.DB, schemaName string, tableName string,
	tableDefinition string) {
	_, err := db.Exec("create table " + schemaName + tableName + tableDefinition)

	if err != nil {
		log.Fatal(err)
	}
}

func getUniqueNameStartingWith(prefix string) string {
	output, err := exec.Command("uuidgen").Output()
	var uniqueName string

	if err == nil {
		uniqueName = prefix + fmt.Sprintf("%s", output)
		separatorCount := strings.Count(uniqueName, "-")
		uniqueName = strings.Replace(uniqueName, "-", "", separatorCount)
	} else {
		uniqueName = prefix
	}

	return strings.TrimSpace(uniqueName)
}

func validateError(err error, expectedErrorLevel driver.HdbSeverityLevel,
	expectedErrorCode int, expectedErrorText string, expectedSqlState string) {
	if err == nil {
		log.Fatal("Got no error when an error was expected")
	}

	// Check that it is an instance of a driver.HdbError
	v := reflect.ValueOf(err)
	hdbError, ok := v.Interface().(*driver.HdbError)

	if !ok {
		log.Fatalf("Expected to get an driver.HdbError but got: %v", err)
	}

	if hdbError.NumberOfErrors() != 1 {
		log.Fatalf("Expected to NumberOfErrors() to be 1 but got: %d", hdbError.NumberOfErrors())
	}

	if hdbError.ErrorLevel() != expectedErrorLevel {
		log.Fatalf("Expected to get an Error Level: %d but got: %d", expectedErrorLevel,
			hdbError.ErrorLevel())
	}

	if hdbError.ErrorCode() != expectedErrorCode {
		log.Fatalf("Expected to get an Error Code: %d but got: %d", expectedErrorCode,
			hdbError.ErrorCode())
	}

	if !strings.Contains(hdbError.ErrorText(), expectedErrorText) {
		log.Fatalf("Expected to get Error Text containing: \"%s\" but got: \"%s\"", expectedErrorText,
			hdbError.ErrorText())
	}

	if hdbError.SqlState() != expectedSqlState {
		log.Fatalf("Expected to get SQL State: %s but got: %s", expectedSqlState,
			hdbError.SqlState())
	}

	if expectedErrorLevel == driver.ErrorLevel_Warning {
		if !hdbError.IsWarning() {
			log.Fatal("Expected IsWarning() to be true but got false")
		}
		if hdbError.IsError() {
			log.Fatal("Expected IsError() to be false but got true")
		}
	}

	if expectedErrorLevel == driver.ErrorLevel_Error {
		if !hdbError.IsError() {
			log.Fatal("Expected IsError() to be true but got false")
		}
		if hdbError.IsWarning() {
			log.Fatal("ExpecteWarning() to be false but got true")
		}
	}
}

func setupStoredProcedureGeneratingWarning(db *sql.DB, schemaName string,
	procedureName string) {
	_, err := db.Exec("CREATE COLUMN TABLE " +
				schemaName + "." + "TCURN(MANDT NVARCHAR(3) NOT NULL DEFAULT '000'," +
				"FCURR NVARCHAR(5) NOT NULL," +
				"TCURR NVARCHAR(5) NOT NULL," +
				"GDATU NVARCHAR(8) NOT NULL," +
				"NOTATION NVARCHAR(1) NOT NULL)")

	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("CREATE COLUMN TABLE " + schemaName + "." + "TCURX(CURRKEY NVARCHAR(5) NOT NULL," +
				"CURRDEC DECIMAL(1) NOT NULL DEFAULT 0)")
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("CREATE COLUMN TABLE " + schemaName + "." + "TCURF(MANDT NVARCHAR(3) NOT NULL DEFAULT '000'," +
				"KURST NVARCHAR(4) NOT NULL," +
				"FCURR NVARCHAR(5) NOT NULL," +
				"TCURR NVARCHAR(5) NOT NULL," +
				"GDATU NVARCHAR(8) NOT NULL," +
				"FFACT DECIMAL(9,0) NOT NULL DEFAULT 0," +
				"TFACT DECIMAL(9,0) NOT NULL DEFAULT 0," +
				"ABWCT NVARCHAR(4) NOT NULL," +
				"ABWGA NVARCHAR(8) NOT NULL DEFAULT '00000000')")
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("CREATE COLUMN TABLE " + schemaName + "." + "TCURR(MANDT NVARCHAR(3) NOT NULL DEFAULT '000'," +
				"KURST NVARCHAR(4) NOT NULL," +
				"FCURR NVARCHAR(5) NOT NULL," +
				"TCURR NVARCHAR(5) NOT NULL," +
				"GDATU NVARCHAR(8) NOT NULL," +
				"UKURS DECIMAL(15,5) NOT NULL DEFAULT 0," +
				"FFACT DECIMAL(9,0) NOT NULL DEFAULT 0," +
				"TFACT DECIMAL(9,0) NOT NULL DEFAULT 0)")
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("CREATE COLUMN TABLE " + schemaName + "." + "TCURV(MANDT NVARCHAR(3) NOT NULL DEFAULT '000'," +
				"KURST NVARCHAR(4) NOT NULL," +
				"XINVR NVARCHAR(1) NOT NULL," +
				"BWAER NVARCHAR(5) NOT NULL," +
				"XBWRL NVARCHAR(1) NOT NULL," +
				"GKUZU NVARCHAR(4) NOT NULL," +
				"BKUZU NVARCHAR(4) NOT NULL," +
				"XFIXD NVARCHAR(1) NOT NULL," +
				"XEURO NVARCHAR(1) NOT NULL)")
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("INSERT INTO " + schemaName + "." + "TCURV VALUES ('000','PTV0','','EUR','','','','','')")
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("INSERT INTO " + schemaName + "." + "TCURF VALUES ('000','PTV0','EUR','USD','10000101','1','1','','00000000')")
	if err != nil {
		log.Fatal(err)
	}

	// Enter a invalid empty reference date in the rate table for raising warning
	_, err = db.Exec("INSERT INTO " + schemaName + "." + "TCURR VALUES ('000','PTV0','USD','EUR','','-7.777','0','0')")
	if err != nil {
		log.Fatal(err)
	}

	// Enter a rate for 2016-12-01
	_, err = db.Exec("INSERT INTO " + schemaName + "." + "TCURR VALUES ('000','PTV0','USD','EUR','79839288','-1.234','0','0')")
	if err != nil {
		log.Fatal(err)
	}

	var sql strings.Builder
	sql.WriteString("CREATE PROCEDURE " + schemaName + "." + procedureName + "() LANGUAGE SQLSCRIPT AS BEGIN " +
			"SELECT CONVERT_CURRENCY(" +
			"SCHEMA => '" + schemaName + "'," +
			"CLIENT => 000," +
			"AMOUNT => 1.0," +
			"SOURCE_UNIT => 'EUR'," +
			"TARGET_UNIT => 'USD'," +
			"REFERENCE_DATE => '2016-12-01'," +
			"CONVERSION_TYPE => 'PTV0') FROM DUMMY " +
			"WITH HINT(NO_USE_HEX_PLAN; END")
	_, err = db.Exec(sql.String())
	if err != nil {
		log.Fatal(err)
	}
}

func doWarningsTestForDB(connStr string, propertyValue string, schemaName string,
	procedureName string, shouldGiveWarnings bool) {
	var (
		db *sql.DB
		err error
	)

	if propertyValue == "" { // don't set
		db, err = sql.Open("hdb", connStr)

		if err != nil {
			log.Fatal(err)
		}
	} else {
		dsn := connStr + "?golangReportWarningsWithErrors=" + propertyValue
		db, err = sql.Open("hdb", dsn)

		if err != nil {
			log.Fatal(err)
		}
	}

	defer db.Close()
	_, err = db.Exec("call " + schemaName + "." + procedureName + "()")

	if shouldGiveWarnings {
		if err == nil {
			log.Fatal("Got no warning when a warning was expected")
		}

		validateError(err, driver.ErrorLevel_Warning, 1,
			"general warning: currency/unit conversion finished with warnings",
			"01000")
	} else if err != nil {
		log.Fatalf("Expected no error/warning but got: %v", err)
	}
}

func doWarningsTestForStmt(connStr string, propertyValue string, schemaName string,
	procedureName string, shouldGiveWarnings bool) {
	var (
		db *sql.DB
		err error
	)

	if propertyValue == "" { // don't set
		db, err = sql.Open("hdb", connStr)

		if err != nil {
			log.Fatal(err)
		}
	} else {
		dsn := connStr + "?golangReportWarningsWithErrors=" + propertyValue
		db, err = sql.Open("hdb", dsn)

		if err != nil {
			log.Fatal(err)
		}
	}

	defer db.Close()
	stmt, err := db.Prepare("call " + schemaName + "." + procedureName + "()")

	if err != nil {
		log.Fatalf("Got error on db.Prepare(): %v", err)
	}
	defer stmt.Close()

	_, err = stmt.Exec()

	if shouldGiveWarnings {
		if err == nil {
			log.Fatal("Got no warning when a warning was expected")
		}

		validateError(err, driver.ErrorLevel_Warning, 1,
			"general warning: currency/unit conversion finished with warnings",
			"01000")
	} else if err != nil {
		log.Fatalf("Expected no error/warning but got: %v", err)
	}
}

//To run this use: go run error_examples.go -dsn hdb://user:password@host:port
func main() {
	var connStr string
	//dsn is of the form: hdb://user:password@host:port?connectProp1=value&connectProp2=value
	flag.StringVar(&connStr, "dsn", "hdb://user:password@host:port", "database dsn")

	if !flag.Parsed() {
		flag.Parse()
	}

	//The name of the HANA driver is hdb
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}

	defer db.Close()
	// The general idea is to always check that you have a vendor specific error/warning coming back from API calls
	// that return errors. Assuming that err is not nil:
	// v := reflect.ValueOf(err)
	// hdbError, ok := v.Interface().(*driver.HdbError)
	// if ok {
	//     // Use the driver.Error and driver.ErrorCollection interface functions to get more information
	// } else {
	//     // Generic error (may be returned for sql package API reasons)
	// }
	// Notes:
	// 1) Both vendor errors and warnings are represented by the same error object returned, there are checker
	// API functions on the object to deferentiate between them (IsWarning(), IsError()).
	// 2) Warnings are not returned by default (for backward compatibility reasons + warnings are not fatal, while an error is believed to be fatal)
	// To enable warnings being returned, the golang-specific connect property, golangReportWarningsWithErrors, must be set to true
	testVendorErrorsFromDB(connStr)
	testVendorErrorsFromConn(connStr)
	testVendorErrorsFromTx(db)
	testVendorErrorsFromStmt(db)
	testVendorWarningsFromDB(connStr)
	testVendorWarningsFromStmt(connStr)
}
