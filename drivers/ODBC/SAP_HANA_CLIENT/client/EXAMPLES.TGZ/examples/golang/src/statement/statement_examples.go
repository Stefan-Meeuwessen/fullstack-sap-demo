package main

import (
	driver "SAP/go-hdb/driver"
	"context"
	"database/sql"
	"flag"
	"fmt"
	"log"
	"math"
	"reflect"
	"sync/atomic"
	"time"
)

//To run this use: go run statement_examples.go -dsn hdb://user:password@host:port
func testGeneral(db *sql.DB) {
	//Drop the table if it exists and ignore the errors
	_, _ = db.Exec("DROP TABLE TAB")

	//Create a table
	_, err := db.Exec("CREATE TABLE TAB (A DECIMAL(25, 4), B TIMESTAMP)")
	if err != nil {
		log.Fatal(err)
	}

	//Please look at transaction_examples.go for examples on using a statement
	//within a transaction.
	//Prepare a statement once and it can be used multiple times
	stmt, err := db.Prepare("INSERT INTO TAB VALUES(?, ?)")
	if err != nil {
		log.Fatal(err)
	}

	//Now use the prepared statement created above to insert multiple values in the table
	res, err := stmt.Exec(2311.12345, time.Now())
	if err != nil {
		log.Fatal(err)
	}
	rowsAffected, err := res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("%d rows affected ", rowsAffected)

	res, err = stmt.Exec(-332.2249, time.Date(2017, 11, 1, 18, 12, 22, 123456789, time.Local))
	if err != nil {
		log.Fatal(err)
	}
	rowsAffected, err = res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("%d rows affected ", rowsAffected)

	//Set a timeout of 5 seconds
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	res, err = stmt.ExecContext(ctx, 1.00129, time.Date(1998, 03, 01, 10, 03, 11, 0, time.Local))
	if err != nil {
		log.Fatal(err)
	}
	rowsAffected, err = res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("%d rows affected ", rowsAffected)

	//Once done with the prepared statement close it
	err = stmt.Close()
	if err != nil {
		log.Fatal(err)
	}

	//Set a timeout of 8 seconds
	ctx, cancel = context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	queryStmt, err := db.Prepare("SELECT * FROM TAB")

	if err != nil {
		log.Fatal(err)
	}

	rows, err := queryStmt.QueryContext(ctx)
	if err != nil {
		log.Fatal(err)
	}

	//Now iterate over the returned rows to get the returned values
	var retDec string
	var retTs time.Time
	for {
		if !rows.Next() {
			break
		}
		err = rows.Scan(&retDec, &retTs)
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("Value is: %s %s", retDec, retTs)
	}

	//Close the rows when done
	err = rows.Close()
	if err != nil {
		log.Fatal(err)
	}

	//Get the first row in the result set
	err = queryStmt.QueryRow().Scan(&retDec, &retTs)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Value is: %s %s", retDec, retTs)

	//Close the statement when done
	err = queryStmt.Close()
	if err != nil {
		log.Fatal(err)
	}
}

func testBulkInsert(db *sql.DB) {
	_, _ = db.Exec("DROP TABLE TAB")
	res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
		"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP, " +
		"COL10 NCLOB, COL11 BLOB)")
	_ = res

	if err != nil {
		log.Fatal(err)
		return
	}

	_ = doInsert(db)
	doFetch(db)
}

func testBulkUpdate(db *sql.DB) {
	_, _ = db.Exec("DROP TABLE TAB")
	res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
		"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP, " +
		"COL10 NCLOB, COL11 BLOB)")
	_ = res

	if err != nil {
		log.Fatal(err)
		return
	}

	batchValues := doInsert(db)
	_ = doUpdate(db, batchValues)
	doFetch(db)
}

func testBulkDelete(db *sql.DB) {
	_, _ = db.Exec("DROP TABLE TAB")
	res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
		"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP, " +
		"COL10 NCLOB, COL11 BLOB)")
	_ = res

	if err != nil {
		log.Fatal(err)
		return
	}

	batchValues := doInsert(db)
	doDelete(db, batchValues)
	doFetch(db) // Should show no values
}

func testBulkFetch(db *sql.DB) {
	_, _ = db.Exec("DROP TABLE TAB")
	res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
		"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP)")
	_ = res

	if err != nil {
		log.Fatal(err)
		return
	}

	_ = doInsertForBulkFetch(db)
	doBulkFetch(db)
}

func testCommunicationTimeout(connStr string) {
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	tableName := "TAB"
	_, _ = db.Exec("DROP TABLE TAB")
	_, err = db.Exec("CREATE TABLE TAB(A INT)")

	if err != nil {
		log.Fatal(err)
		return
	}
	defer db.Exec("DROP TABLE TAB")
	_, err = db.Exec("INSERT INTO TAB(A) VALUES(1009)")
	if err != nil {
		log.Fatal(err)
		return
	}

	tx1, err := db.Begin()
	if err != nil {
		log.Fatal(err)
		return
	}
	defer tx1.Rollback()
	tx2, err := db.Begin()
	if err != nil {
		log.Fatal(err)
		return
	}
	defer tx2.Rollback()

	if db.Stats().OpenConnections != 2 {
		log.Fatalf("Expected connection count: 2 but found: %d ", db.Stats().OpenConnections)
	}

	_, err = tx1.Exec("LOCK TABLE " + tableName + " IN EXCLUSIVE MODE")

	if err != nil {
		log.Fatal(err)
	}

	var isAlive int32
	isAlive = 1
	ch := make(chan any, 2)
	communicationTimeout := 3

	go runBulkAPIFuncWithCommunicationTimeoutAgainstTable(tx2, tableName,
		time.Duration(communicationTimeout) * time.Second, &isAlive, ch)
	// There is noticable delay in terms of actual time it takes stmt.ExecContext to
	// be aborted due to the communicationTimeout. We are actually using a range here that
	// should not be passed
	time.Sleep(time.Duration(4*communicationTimeout) * time.Second)

	if atomic.LoadInt32(&isAlive) == 1 {
		log.Fatalf("The goroutine is still alive after %d seconds", communicationTimeout * 4)
	}

	chanVal := <-ch
	v := reflect.ValueOf(chanVal)
	if !v.IsValid() {
		log.Fatalf("The goroutine did not send valid value for channel value 1")
	}

	err, ok :=  v.Interface().(error)

	if !ok {
		log.Fatalf("The goroutine did not send an error for channel value 1")
	}

	chanVal2 := <-ch
	v2 := reflect.ValueOf(chanVal2)

	if !v2.IsValid() {
		log.Fatalf("The goroutine did not send valid value for channel value 2")
	}

	duration, ok :=  v2.Interface().(time.Duration)

	if !ok {
		log.Fatalf("The goroutine did not send an time.Duration for channel value 2")
	}

	// driver.ErrBadConn should be the result
	if err == nil {
		log.Fatal("Expected error but found nil")
	} else if err.Error() != "driver: bad conneclog.on" {
		log.Fatalf("Expected communicationTimeout error but found: %v", err)
	}

	if duration.Seconds() < float64(communicationTimeout) ||
		duration.Seconds() > float64(4) * float64(communicationTimeout) {
		log.Fatalf("Unexpected timeout time: %f seconds, communicationTimeout set: %d seconds",
			duration.Seconds(), communicationTimeout)
	}
}

func testStmtExecContextPacketSize(connStr string) {
	// Currently the min for HANA
	minPacketSize := uint32(1*64*1024)
    // Switching off network compression as to see the actual results from the server
    // monitoring view
	db, err := sql.Open("hdb", fmt.Sprintf("%s?packetSize=%d&compress=0", connStr,
		minPacketSize))

	if err != nil {
		log.Fatal(err)
	}

	defer db.Close()

	_, _ = db.Exec("DROP TABLE TAB")

	//Create a table
	_, err = db.Exec("create table tab" +
		"(a bigint, b bigint, c bigint, d bigint, e bigint, f bigint, g bigint)")

	if err != nil {
		log.Fatal(err)
	}

	tx, err := db.Begin()

	if err != nil {
		log.Fatal(err)
	}

	defer tx.Rollback()
	transactionConnectionID := getCurrentConnectionIDForTx(tx)

	// Use a batchSize which would roughly fill a packelog.
	// This is purely approximate, and may need to be revisited if many
	// more parts are introduced on the EXECUTE message that could negatively
	// affect the PARAMETERS part size
	connectionPacketSize := uint32(minPacketSize)
	packetSize := uint32(minPacketSize*4)
	batchSize := int((0.8*float64(packetSize))/float64(8*7))
	data := make([][]interface{}, batchSize)

	for i := 0; i < batchSize; i++ {
		data[i] = []interface{}{int16(i), int16(i), int16(i), int16(i),
			int16(i), int16(i), int16(i)}
	}

	// A regular statement should use the packet size set from the connection
	// by default, unless a packet size is set in the context.
	regularTxStmt, err := tx.Prepare("insert into tab" +
		"(a, b, c, d, e, f, g) values (?, ?, ?, ?, ?, ?, ?)")

	if err != nil {
		log.Fatal(err)
	}
	defer regularTxStmt.Close()

	tolerance := 0.2
	iterations := 4
	expectedMessageCount := 4

	// Check that the statement reuses the packet size it was created with
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfo(
		db, regularTxStmt, data, transactionConnectionID, connectionPacketSize,
		expectedMessageCount, iterations, tolerance)

	ctx, err := driver.NewPacketSizeStmtContext(context.Background(), packetSize)

	if err != nil {
		log.Fatal(err)
	}
	// We want to check that this creates a statement that uses the specified packet size for
	// communications by default
	// A regular statement should use the packet size set from the connection
	// by default, unless a packet size is set in the context. Here we are using
	// a packet size set in the context, so it should always be used by the statement
	// unless modified by another context object in an Exec()/Query() call
	stmt, err := tx.PrepareContext(ctx, "insert into tab" +
		"(a, b, c, d, e, f, g) values (?, ?, ?, ?, ?, ?, ?)")

	if err != nil {
		log.Fatal(err)
	}
	defer stmt.Close()

	expectedMessageCount = 1
	// Check that the statement reuses the packet size it was created with
	// (iteration = 4 times)
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfo(db,
		stmt, data, transactionConnectionID, packetSize, expectedMessageCount,
		iterations, tolerance)

	// Original statement with connection set packet size should not be affected
	expectedMessageCount = 4
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfo(db,
		regularTxStmt, data, transactionConnectionID, connectionPacketSize, expectedMessageCount,
		iterations, tolerance)

    packetSize = uint32(minPacketSize*2)
	ctx, err = driver.NewPacketSizeStmtContext(context.Background(), packetSize)

	// Check that the statement now uses the packet size in the context
	expectedMessageCount = 2
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfoWithCtx(db,
		regularTxStmt, data, transactionConnectionID, packetSize, expectedMessageCount,
		iterations, tolerance, ctx)
}

func runBulkAPIFuncWithCommunicationTimeoutAgainstTable(tx *sql.Tx, tableName string,
	communicationTimeout time.Duration, isAlive *int32, ch chan<- any) {
	var err error
	var duration time.Duration
	stmt, err := tx.Prepare("INSERT INTO " + tableName + "(A) VALUES(?)")

	if err != nil {
		atomic.StoreInt32(isAlive, 0)
		ch <- err
		ch <- nil
		close(ch)
		return
	}

	defer stmt.Close()
	ctx, err := driver.NewCommunicationTimeoutStmtContext(context.Background(), communicationTimeout)

    if err != nil {
		atomic.StoreInt32(isAlive, 0)
		ch <- err
		ch <- nil
		close(ch)
		return
	}

	begin := time.Now()
    _, err = stmt.ExecContext(ctx, 2)
	end := time.Now()
	duration = end.Sub(begin)
	atomic.StoreInt32(isAlive, 0)
	ch <- err
	ch <- duration
	close(ch)
}

func doInsert(db *sql.DB) [][]interface{} {
	stmt, err := db.Prepare("INSERT INTO TAB VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

	if err != nil {
		log.Fatal(err)
		return nil
	}
	defer stmt.Close()

	batchSize := 50
	batchValues := createBatchValues(batchSize)

	_, err = stmt.Exec(batchValues)

	if err != nil {
		log.Fatal(err)
		return nil
	}

	return batchValues
}

func doInsertForBulkFetch(db *sql.DB) [][]interface{} {
	stmt, err := db.Prepare("INSERT INTO TAB VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)")

	if err != nil {
		log.Fatal(err)
		return nil
	}
	defer stmt.Close()

	batchSize := 50
	batchValues := createBatchValuesForBulkFetch(batchSize)

	_, err = stmt.Exec(batchValues)

	if err != nil {
		log.Fatal(err)
		return nil
	}

	return batchValues
}

func doUpdate(db *sql.DB, batchValues [][]interface{}) [][]interface{} {
	stmt, err := db.Prepare("UPDATE TAB SET COL2 = ? WHERE COL1 = ?")

	if err != nil {
		log.Fatal(err)
		return nil
	}
	defer stmt.Close()

	newColumnValues := getNewSingleColumnValues(batchValues, 2)
	newBatchValues := replaceColumnValues(batchValues, newColumnValues, 2)

	_, err = stmt.Exec(newColumnValues)

	if err != nil {
		log.Fatal(err)
		return nil
	}

	return newBatchValues
}

func doDelete(db *sql.DB, batchValues [][]interface{}) {
	stmt, err := db.Prepare("DELETE FROM TAB WHERE COL1 = ?")

	if err != nil {
		log.Fatal(err)
		return
	}
	defer stmt.Close()

	primaryKeyColumnValues := getSingleColumnValues(batchValues, 1)

	_, err = stmt.Exec(primaryKeyColumnValues)

	if err != nil {
		log.Fatal(err)
		return
	}
}

func createBatchValues(batchSize int) [][]interface{} {
	time := time.Now()
	testString := "abcdefg"
	testBytes := []byte(testString)
	data := make([][]interface{}, batchSize)

	for i := 0; i < batchSize; i++ {
		data[i] = []interface{}{int16(i), float64(i), true, math.MaxInt32, testString,
			testBytes, time, time, time, testString, testBytes}
	}
	return data
}

func createBatchValuesForBulkFetch(batchSize int) [][]interface{} {
	time := time.Now()
	testString := "abcdefg"
	testBytes := []byte(testString)
	data := make([][]interface{}, batchSize)

	for i := 0; i < batchSize; i++ {
		data[i] = []interface{}{i, float64(i), true, math.MaxInt32, testString,
			testBytes, time, time, time}
	}
	return data
}

func doFetch(db *sql.DB) {
	rows, err := db.Query("SELECT COL1, COL2, COL3, COL4 , COL5 , COL6 , COL7, COL8, " +
		"COL9, COL10, COL11 FROM TAB ORDER BY COL1 ASC")
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	columnValues := make([]sql.NullString, 11)
	rowCount := 0

	for rows.Next() {
		rowCount++
		err = rows.Scan(&columnValues[0], &columnValues[1], &columnValues[2], &columnValues[3],
			&columnValues[4], &columnValues[5], &columnValues[6], &columnValues[7],
			&columnValues[8], &columnValues[9], &columnValues[10])

		if err != nil {
			log.Fatal(err)
		}
		log.Println("Row ", rowCount, "Values are: ",
			"COL1 (", columnValues[0].String, ")",
			"COL2 (", columnValues[1].String, ")",
			"COL3 (", columnValues[2].String, ")",
			"COL4 (", columnValues[3].String, ")",
			"COL5 (", columnValues[4].String, ")",
			"COL6 (", columnValues[5].String, ")",
			"COL7 (", columnValues[6].String, ")",
			"COL8 (", columnValues[7].String, ")",
			"COL9 (", columnValues[8].String, ")",
			"COL10 (", columnValues[9].String, ")",
			"COL11 (", columnValues[10].String, ")")
	}

	log.Println("Number of rows received: ", rowCount)
}

func doBulkFetch(db *sql.DB) {
	// res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
	// 	"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP)")
	stmt, err := db.Prepare("SELECT COL1, COL2, COL3, COL4, COL5, COL6, COL7, COL8, " +
		"COL9 FROM TAB ORDER BY COL1 ASC")
	if err != nil {
		log.Fatal(err)
	}
	defer stmt.Close()

	rowsetFetchSize := 10
	ctx, err := driver.NewFetchSizeContext(context.Background(), uint(rowsetFetchSize))

	if err != nil {
		log.Fatal(err)
	}

	rows, err := stmt.QueryContext(ctx)

	if err != nil {
		log.Fatal(err)
	}

	var (
		col1         driver.BulkNullInt64
		col2         driver.BulkNullFloat64
		col3         driver.BulkNullBool
		col4         driver.BulkNullString
		col5         driver.BulkNullString
		col6         driver.BulkNullBytes
		col7         driver.BulkNullTime
		col8         driver.BulkNullTime
		col9         driver.BulkNullTime
		col1StrValue string
		col2StrValue string
		col3StrValue string
		col4StrValue string
		col5StrValue string
		col6StrValue string
		col7StrValue string
		col8StrValue string
		col9StrValue string
	)

	rowCount := 0

	for rows.Next() {
		err = rows.Scan(&col1, &col2, &col3, &col4, &col5, &col6, &col7, &col8, &col9)

		if err != nil {
			log.Fatal(err)
		}
		for i := 0; uint64(i) < col1.NumberOfRows; i++ {
			// res, err := db.Exec("CREATE TABLE TAB(COL1 INT, COL2 DOUBLE, COL3 BOOLEAN, COL4 DECIMAL(28), " +
			// 	"COL5 NVARCHAR(20), COL6 VARBINARY(20), COL7 TIME, COL8 DATE, COL9 TIMESTAMP)")
			if col1.Valids[i] {
				col1StrValue = fmt.Sprintf("%d", col1.Int64s[i])
			} else {
				col1StrValue = "<null>"
			}
			if col2.Valids[i] {
				col2StrValue = fmt.Sprintf("%E", col2.Float64s[i])
			} else {
				col2StrValue = "<null>"
			}
			if col3.Valids[i] {
				col3StrValue = fmt.Sprintf("%t", col3.Bools[i])
			} else {
				col3StrValue = "<null>"
			}
			if col4.Valids[i] {
				col4StrValue = fmt.Sprintf("%s", col4.Strings[i])
			} else {
				col4StrValue = "<null>"
			}
			if col5.Valids[i] {
				col5StrValue = fmt.Sprintf("%s", col5.Strings[i])
			} else {
				col5StrValue = "<null>"
			}
			if col6.Valids[i] {
				col6StrValue = fmt.Sprintf("%v", col6.Bytes[i])
			} else {
				col6StrValue = "<null>"
			}
			if col7.Valids[i] {
				col7StrValue = fmt.Sprintf("%v", col7.Times[i])
			} else {
				col7StrValue = "<null>"
			}
			if col8.Valids[i] {
				col8StrValue = fmt.Sprintf("%v", col8.Times[i])
			} else {
				col8StrValue = "<null>"
			}
			if col9.Valids[i] {
				col9StrValue = fmt.Sprintf("%v", col9.Times[i])
			} else {
				col9StrValue = "<null>"
			}
			log.Println("Row ", rowCount, "Values are: ",
				"COL1 (", col1StrValue, ")",
				"COL2 (", col2StrValue, ")",
				"COL3 (", col3StrValue, ")",
				"COL4 (", col4StrValue, ")",
				"COL5 (", col5StrValue, ")",
				"COL6 (", col6StrValue, ")",
				"COL7 (", col7StrValue, ")",
				"COL8 (", col8StrValue, ")",
				"COL9 (", col9StrValue, ")")
			rowCount++
		}

	}

	log.Println("Number of rows received: ", rowCount)
}

func getNewSingleColumnValues(allRows [][]interface{}, columnIndex int) [][]interface{} {
	// columns = col1 int, col2 double, col3 boolean, col4 decimal(28), col5 nvarchar(20),
	// col6 varbinary(20), col7 time, col8 date, col9 timestamp, col10 nclob, col11 blob
	batchSize := len(allRows)
	data := make([][]interface{}, batchSize)
	theTime := time.Now()
	theTime = time.Date(theTime.Year()-1, theTime.Month(), theTime.Day(), theTime.Hour(),
		theTime.Minute(), theTime.Second(), theTime.Nanosecond(), theTime.Location())
	theNewString := "xxxxxxx"
	theNewBinary := []byte(theNewString)

	for rowIndex := 0; rowIndex < batchSize; rowIndex++ {
		if columnIndex == 2 { // Boolean
			data[rowIndex] = []interface{}{false, int16(rowIndex)}
		} else if columnIndex == 5 { // Binary
			data[rowIndex] = []interface{}{theNewBinary, int16(rowIndex)}
		} else if columnIndex < 4 { // Numeric
			data[rowIndex] = []interface{}{int(-1), int16(rowIndex)}
		} else if (columnIndex == 4) || (columnIndex >= 9 && columnIndex < 11) { // String
			data[rowIndex] = []interface{}{"xxxxxxx", int16(rowIndex)}
		} else { // Date/Time/Timestamp
			data[rowIndex] = []interface{}{theTime, int16(rowIndex)}
		}
	}

	return data
}

func replaceColumnValues(batchValues [][]interface{}, newColumnValues [][]interface{},
	changedColumnIndex int) [][]interface{} {
	batchSize := len(batchValues)
	data := make([][]interface{}, batchSize)

	for rowIndex := 0; rowIndex < batchSize; rowIndex++ {
		data[rowIndex] = []interface{}{batchValues[rowIndex][0], batchValues[rowIndex][1],
			batchValues[rowIndex][2], batchValues[rowIndex][3], batchValues[rowIndex][4],
			batchValues[rowIndex][5], batchValues[rowIndex][6], batchValues[rowIndex][7],
			batchValues[rowIndex][8], batchValues[rowIndex][9], batchValues[rowIndex][10]}
		data[rowIndex][changedColumnIndex] = newColumnValues[rowIndex][0]
	}

	return data
}

func getSingleColumnValues(allRows [][]interface{}, columnIndex int) [][]interface{} {
	batchSize := len(allRows)
	data := make([][]interface{}, batchSize)

	for rowIndex := 0; rowIndex < batchSize; rowIndex++ {
		data[rowIndex] = []interface{}{allRows[rowIndex][columnIndex-1]}
	}
	return data
}

func getCurrentConnectionIDForTx(tx *sql.Tx) int32 {
    var currentConnectionID int32
	err := tx.QueryRow("select current_connection from dummy").Scan(&currentConnectionID)

	if err != nil {
		log.Fatalf("Got error when selecting the current_connection for the connection: %v\n", err)
	}

	return currentConnectionID
}

// Note: The stmt being using here should be created from the transaction
// that has an associate connection of txConnectionID. It is also expected
// to NOT be a split batch/routed execution
func testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfo(db *sql.DB,
	stmt * sql.Stmt, data [][]interface{}, txConnectionID int32, expectedPacketSize uint32,
	expectedMessageCount int, iterations int, tolerance float64) {
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfoInternal(
		db, stmt, data, txConnectionID, expectedPacketSize, expectedMessageCount, iterations,
		tolerance, nil)
}

func testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfoWithCtx(db *sql.DB,
	stmt * sql.Stmt, data [][]interface{}, txConnectionID int32, expectedPacketSize uint32,
	expectedMessageCount int, iterations int, tolerance float64, ctx context.Context) {
	testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfoInternal(
		db, stmt, data, txConnectionID, expectedPacketSize, expectedMessageCount, iterations,
		tolerance, &ctx)
}

func testStmtPacktSizeDbContextWithPermanentStmtPacketSizeCheckReceivedMessageInfoInternal(db *sql.DB,
	stmt * sql.Stmt, data [][]interface{}, txConnectionID int32, expectedPacketSize uint32,
	expectedMessageCount int, iterations int, tolerance float64, ctx *context.Context) {
	// Discard the initial round as it may include additional messsages associated with reprepare
	iterations = iterations + 1
	for i := 0; i < iterations; i++ {
		var err error
		beforeReceivedMessageCount := getReceivedMessageCountFromMConnections(db, txConnectionID)
		beforeReceivedMessageSize := getReceivedMessageSizeFromMConnections(db, txConnectionID)

		// Using Query() here is an abuse of the API, but it is allowed
		if ctx != nil {
			_, err = stmt.ExecContext(*ctx, data)
		} else {
			_, err = stmt.Exec(data)
		}

		if err != nil {
			log.Fatal(err)
		}

		afterReceivedMessageCount := getReceivedMessageCountFromMConnections(db, txConnectionID)
		afterReceivedMessageSize := getReceivedMessageSizeFromMConnections(db, txConnectionID)

		if i == 0 {
			// Discard the initial round as it may include additional messsages associated with reprepare
			continue
		}

		receivedMessageCount := afterReceivedMessageCount - beforeReceivedMessageCount

		if receivedMessageCount != int64(expectedMessageCount) {
			log.Fatalf("Expected receivedMessageCount to be %d but found %d\n",
				expectedMessageCount, receivedMessageCount)
		}
		receivedMessageSize := (afterReceivedMessageSize - beforeReceivedMessageSize) / receivedMessageCount

		// Note, this is a rough check, as the number of server messages can/will change over time
		if !intValueInRangeOf(receivedMessageSize, int64(expectedPacketSize), tolerance) {
			log.Fatalf("Expected receivedMessageSizeUncompressed (%d) to be within " +
				"%f of the packetSize (%d) but it was not\n",
				receivedMessageSize, tolerance, expectedPacketSize)
		}
	}
}

func getReceivedMessageSizeFromMConnections(db *sql.DB, connectionID int32) int64 {
	stmt, err:= db.Prepare("select received_message_size from m_connections where connection_id = ? ")

	if err != nil {
		log.Fatalf("Got error when preparing the select the total received_message_size from current connection: %v", err)
	}

    var receivedMessageSize int64
	err = stmt.QueryRow(connectionID).Scan(&receivedMessageSize)


	if err != nil {
		log.Fatalf("Got error when selecting the total received_message_size from current connection: %v", err)
	}

	return receivedMessageSize
}

func getReceivedMessageCountFromMConnections(db *sql.DB, connectionID int32) int64 {
	// stmt, err:= db.Prepare("select received_message_count from m_connections where connection_id = ? ")
	stmt, err:= db.Prepare("select received_message_count from m_connections where connection_id = ? ")

	if err != nil {
		log.Fatalf("Got error when preparing the select the total received_message_size from current connection: %v", err)
	}

    var receivedMessageCount int64
	err = stmt.QueryRow(connectionID).Scan(&receivedMessageCount)

	if err != nil {
		log.Fatalf("Got error when selecting the total received_message_size from current connection: %v", err)
	}

	return receivedMessageCount
}

func intValueInRangeOf(value int64, expectedValue int64, tolerance float64) bool {
	return math.Abs(float64(value - expectedValue)) <=
		math.Abs(float64(expectedValue) * tolerance)
}

func main() {
	var connStr string
	//dsn is of the form: hdb://user:password@host:port?connectProp1=value&connectProp2=value
	flag.StringVar(&connStr, "dsn", "hdb://user:password@host:port", "database dsn")

	if !flag.Parsed() {
		flag.Parse()
	}

	//The name of the HANA driver is hdb
	db, err := sql.Open("hdb", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	testGeneral(db)
	testBulkInsert(db)
	testBulkUpdate(db)
	testBulkDelete(db)
	testBulkFetch(db)
    testCommunicationTimeout(connStr)
    testStmtExecContextPacketSize(connStr)
}
