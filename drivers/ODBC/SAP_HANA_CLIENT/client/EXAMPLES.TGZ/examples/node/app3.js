// ***************************************************************************
// Copyright (c) 2017 SAP AG or an SAP affiliate company. All rights reserved.
// ***************************************************************************
// This sample code is provided AS IS, without warranty or liability of any kind.
//
// You may use, reproduce, modify and distribute this sample code without limitation,
// on the condition that you retain the foregoing copyright notice and disclaimer
// as to the original code.
// ***************************************************************************

// This example uses waterfall.
// npm install async-waterfall

'use strict';

var util = require('util');
var waterfall = require('async-waterfall');
var hana = require('@sap/hana-client');

// // HANA Cloud Example
// // DigiCert Global Root CA: https://cacerts.digicert.com/DigiCertGlobalRootCA.crt.pem
// // DigiCert TLS RSA4096 Root G5: https://cacerts.digicert.com/DigiCertTLSRSA4096RootG5.crt.pem
//
// var connOptions = {
//     serverNode: '12345678-abcd-12ab-34cd-1234abcd.hana.hanacloud.ondemand.com:443',
//     uid: 'User1',
//     pwd: 'Password123',
//     encrypt: 'true',
// };

// HANA Platform Example
var connOptions = {
    serverNode: 'myserver:30015',
    uid: 'User1',
    pwd: 'Password123'
};

var poolOptions = {
    poolCapacity : 10, // the max number of pooled connections are allowed in the pool.
    maxConnectedOrPooled : 10, // the max number of open connections created by this pool.
    maxPooledIdleTime : 360, // the max time, in sec, that connections are allowed to remain in the pool before being marked for eviction.
    pingCheck: true // determine if the pooled connection should be tested for viability before being reused.
}

var pool = hana.createPool(connOptions, poolOptions);

var tasks = [changePoolProperties,
             getConnectionFromPool,
             doSomethingWithConnection,
             disconnectConnection,
             clearPool];

waterfall(tasks, done);
console.log("Async calls underway\n");

function changePoolProperties(cb) {
    // update poolCapacity and maxConnectedOrPool
    var poolPropOptions = { poolCapacity : 5, maxConnectedOrPooled : 6 };
    pool.setProperties(poolPropOptions);

    // update maxPooledIdleTime and pingCheck
    var poolPropOptionStr = "maxPooledIdleTime=0;pingCheck=false";
    pool.setProperties(poolPropOptionStr);

    cb(null);
}

function getConnectionFromPool(cb) {
    var conn = pool.getConnection();

    cb(null, conn);
}

function doSomethingWithConnection(conn, cb) {
    var err = null;

    // drop table if exists
    try{
        conn.exec("DROP TABLE Employees");
    } catch (error) {
        // do nothing
    }

    // create a table
    try {
        conn.exec("CREATE TABLE Employees(EmployeeID integer primary key, GivenName varchar(64), Surname varchar(64) )");
        conn.exec("INSERT INTO Employees VALUES(102, 'Fran',    'Whitney')");
        conn.exec("INSERT INTO Employees VALUES(105, 'Matthew', 'Cobb')");
        conn.exec("INSERT INTO Employees VALUES(129, 'Philip',  'Chin')");
        conn.exec("INSERT INTO Employees VALUES(207, 'Julie',   'Jordan')");
        conn.exec("INSERT INTO Employees VALUES(243, 'Robert',  'Breault')");
        conn.exec("INSERT INTO Employees VALUES(247, 'Melissa', 'Espinoza')");
    } catch (error) {
        console.log(error);
        console.log("");
    }

    // create a sql query
    var fields = ['EmployeeID', 'GivenName', 'Surname'];
    var range = [100, 199];
    var sql = util.format(
        'SELECT %s FROM Employees ' +
        'WHERE EmployeeID BETWEEN %s',
        fields.join(','), range.join(' AND '));
    console.log("SQL statement: " + sql);

    // execute
    var rows = conn.exec(sql);

    // check results
    console.log(util.inspect(rows, { colors: true }));
    console.log("");

    cb(null, conn);
}

function disconnectConnection(conn, cb) {
    conn.disconnect();

    cb(null);
}

function clearPool(cb) {
    var pooledCount = pool.clear();
    console.log("Number of pooled connections: ", pooledCount);
    console.log("");

    cb(null);
}

function done(err) {
    console.log("Async done");
    if (err) {
        return console.error(err);
    }
}
