'use strict';

var db = null;
var path = require('path');

const debug = require('debug')('@sap/hana-client:checkbuild');
debug.log = console.info.bind(console);

const name = 'checkbuild.js';

debug('Starting %s', name);

var installPlatforms = process.env['HDB_NODEJS_INSTALL_PLATFORMS'];
var skipCheck = false;
if (installPlatforms) {
    skipCheck = installPlatforms.indexOf('skipInstallCheck') >= 0;
}
try {
    if (skipCheck) {
        debug("Found 'skipInstallCheck' in HDB_NODEJS_INSTALL_PLATFORMS - skipping check for successful install.");
    } else {
        debug('Checking requirements...');
        db = require(path.join(__dirname, 'lib', 'index'));
        db.createConnection(); // If this step succeeds binaries can be found
    }
    debug('Install Complete.');
} catch (err) {
    console.error('FATAL ERROR: A fatal error occurred during install.');
    console.error(err.message);
    process.exit(-1);
}
