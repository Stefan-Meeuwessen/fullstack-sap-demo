﻿'use strict'

module.exports =
{
    // Connection
    abort: function(obj, ...args) {
        return promisify(obj, obj.abort, args);
    },
    clearPool: function(obj, ...args) {
        return promisify(obj, obj.clearPool, args);
    },
    clean: function(obj, ...args) {
        return promisify(obj, obj.clean, args);
    },
    commit: function(obj, ...args) {
        return promisify(obj, obj.commit, args);
    },
    connect: function(obj, ...args) {
        return promisify(obj, obj.connect, args);
    },
    disconnect: function(obj, ...args) {
        return promisify(obj, obj.disconnect, args);
    },
    close: function(obj, ...args) { // Connection or ResultSet
        return promisify(obj, obj.close, args);
    },
    end: function(obj, ...args) {
        return promisify(obj, obj.end, args);
    },
    exec: function(obj, ...args) { // Connection or Statement
        return promisify(obj, obj.exec, args);
    },
    execute: function(obj, ...args) { // Connection or Statement
        return promisify(obj, obj.execute, args);
    },
    prepare: function(obj, ...args) {
        return promisify(obj, obj.prepare, args);
    },
    rollback: function(obj, ...args) {
        return promisify(obj, obj.rollback, args);
    },
    switchUser: function(obj, ...args) {
        return promisify(obj, obj.switchUser, args);
    },

    // ResultSet
    getData: function(obj, ...args) { // ResultSet or Statement
        return promisify(obj, obj.getData, args);
    },
    getValue: function(obj, ...args) {
        return promisify(obj, obj.getValue, args);
    },
    getValues: function(obj, ...args) {
        return promisify(obj, obj.getValues, args);
    },
    next: function(obj, ...args) {
        return promisify(obj, obj.next, args);
    },
    nextResult: function(obj, ...args) {
        return promisify(obj, obj.nextResult, args);
    },

    // Statement
    drop: function(obj, ...args) {
        return promisify(obj, obj.drop, args);
    },
    execBatch: function(obj, ...args) {
        return promisify(obj, obj.execBatch, args);
    },
    executeBatch: function(obj, ...args) {
        return promisify(obj, obj.executeBatch, args);
    },
    execQuery: function(obj, ...args) {
        return promisify(obj, obj.execQuery, args);
    },
    executeQuery: function(obj, ...args) {
        return promisify(obj, obj.executeQuery, args);
    },
    getParameterValue: function(obj, ...args) {
        return promisify(obj, obj.getParameterValue, args);
    },
    sendParameterData: function(obj, ...args) {
        return promisify(obj, obj.sendParameterData, args);
    }

};

function promisify(obj, fn, args) {
    return new Promise((resolve, reject) => {
        fn.call(obj, ...args, (err, ret) => {
            if (err) {
                return reject(err);
            }
            if(typeof ret !== 'undefined') {
                resolve(ret);
            } else {
                resolve();
            }
        });
    });
}
