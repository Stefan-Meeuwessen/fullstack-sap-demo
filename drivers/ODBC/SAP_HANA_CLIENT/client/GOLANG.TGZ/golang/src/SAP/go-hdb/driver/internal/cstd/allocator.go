package cstd

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"
)

type defaultAllocator struct {
}

func newDefaultAllocator() *defaultAllocator {
	return &defaultAllocator{}
}

func (alloc *defaultAllocator) Malloc(dataSize Size_t) unsafe.Pointer {
	// C.malloc() is already a wrapper around the C standard libary malloc()
	// but it cannot return a NULL pointer (a panic will happen instead)
	return C.malloc(dataSize)
}

func (alloc *defaultAllocator) Calloc(dataSize Size_t, elementCount Size_t) unsafe.Pointer {
	// C.calloc() is already a wrapper around the C standard libary calloc()
	// but it cannot return a NULL pointer (a panic will happen instead)
	return C.calloc(dataSize, elementCount)
}

func (alloc *defaultAllocator) Free(memoryData unsafe.Pointer) {
	C.free(memoryData)
}

var (
	_ allocator			 = (*defaultAllocator)(nil)
)
