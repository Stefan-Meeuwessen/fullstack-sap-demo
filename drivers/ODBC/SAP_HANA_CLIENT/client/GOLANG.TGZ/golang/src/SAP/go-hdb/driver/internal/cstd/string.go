package cstd

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <string.h>
*/
import "C"
import (
	"unsafe"
)

func Memset(destination unsafe.Pointer, character Int, count Size_t) unsafe.Pointer {
	// C.malloc() is already a wrapper around the C standard libary malloc()
	// but it cannot return a NULL pointer (a panic will happen instead)
	return C.memset(destination, character, count)
}

func Memcpy(destination unsafe.Pointer, source unsafe.Pointer, count Size_t) unsafe.Pointer {
	return C.memcpy(destination, source, count)
}


func Strncpy(destination *Char, source *Char, count Size_t) *Char {
	// C.malloc() is already a wrapper around the C standard libary malloc()
	// but it cannot return a NULL pointer (a panic will happen instead)
	return C.strncpy(destination, source, count)
}


// Golang-specific converter function Go Strings <-> *C.char
// This provides memory that the caller has to free with cstd.Free()
func CString(goString string) *Char {
	return C.CString(goString)
}

// Note: The string provided here should be NULL-terminated!
func GoString(cString *Char) string {
	return C.GoString((*C.char)(cString))
}

// Note: The string provided here should be <= stringLength in length!
func GoStringN(cString *Char, stringLength Int) string {
	return C.GoStringN((*C.char)(cString), C.int(stringLength))
}
