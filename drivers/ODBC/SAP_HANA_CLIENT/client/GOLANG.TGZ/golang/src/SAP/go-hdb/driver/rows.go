package driver

import (
	"database/sql/driver"
    "encoding/binary"
	"fmt"
	"io"
	"math"
	"reflect"
	"time"
	"unsafe"
	a "SAP/go-hdb/driver/internal/api"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

//result set
type rows struct {
	stmt              a.Statement
	conn              *connection
	rowsetFetchSize   uint
	boundColumns      []a.DataValue
	boundColumnInfo   []a.ColumnInfo
	boundColumnsCount uint
	isFromStatement   bool
	isClosed          bool
	err               error
	fetchUsingReadLob bool
}

// Rows interface (https://pkg.go.dev/database/sql/driver@go1.23.3#Rows)
func (rows *rows) Close() error {
	if !rows.isClosed {
		defer rows.cleanup()

		if !rows.isFromStatement {
            rows.stmt.Free()
		} else {
			closeRowsRes := rows.stmt.Reset()

			if !closeRowsRes {
				rows.err = rows.conn.getError()
			}
		}
		rows.isClosed = true
	}
	return rows.err
}

func (rows *rows) Columns() []string {
	colCount, ok := rows.stmt.NumColumns()

	if !ok {
		return nil
	}

	columnNames := make([]string, colCount)

	for i := 0; i < colCount; i++ {
		columnNames[i] = rows.getColumnString(i)
	}

	return columnNames
}

func (rows *rows) getColumnString(index int) string {
	colInfo, ok := rows.stmt.GetColumnInfo(index)

	if ok {
		defer colInfo.Free()
		return colInfo.Name()
	}

	return ""
}

//^^Rows interface (https://pkg.go.dev/database/sql/driver@go1.23.3#Rows)
// Various ColumnType interfaces
// https://pkg.go.dev/database/sql/driver@go1.23.3#RowsColumnTypeDatabaseTypeName
// https://pkg.go.dev/database/sql/driver@go1.23.3#RowsColumnTypeLength
// https://pkg.go.dev/database/sql/driver@go1.23.3#RowsColumnTypeNullable
// https://pkg.go.dev/database/sql/driver@go1.23.3#RowsColumnTypePrecisionScale
// https://pkg.go.dev/database/sql/driver@go1.23.3#RowsColumnTypeScanType
func (rows *rows) ColumnTypeDatabaseTypeName(index int) string {
	dbTypeName := ""
	colInfo, ok := rows.stmt.GetColumnInfo(index)

	if ok {
		defer colInfo.Free()
		dbTypeName = getNativeType(colInfo.NativeType())
	}

	return dbTypeName
}

func (rows *rows) ColumnTypeNullable(index int) (bool, bool) {
	colInfo, ok := rows.stmt.GetColumnInfo(index)

	if ok {
		defer colInfo.Free()
		return colInfo.Nullable(), true
	}

	return false, false
}

func (rows *rows) ColumnTypePrecisionScale(index int) (int64, int64, bool) {
	colInfo, ok := rows.stmt.GetColumnInfo(index)
	precision := int64(0)
	scale := int64(0)

	if ok {
		defer colInfo.Free()
		if colInfo.NativeType() == a.DT_DECIMAL || colInfo.NativeType() == a.DT_REAL_VECTOR ||
            colInfo.NativeType() == a.DT_HALF_VECTOR {
			precision = int64(colInfo.Precision())
			scale = int64(colInfo.Scale())
		} else {
			ok = false
		}
	}

	return precision, scale, ok
}

func (rows *rows) ColumnTypeLength(index int) (int64, bool) {
	colInfo, ok := rows.stmt.GetColumnInfo(index)
	length := int64(0)
	if ok {
		defer colInfo.Free()
		ok = false
		dbcapiType := colInfo.DataType()
		if dbcapiType == a.A_BINARY {
			length = int64(colInfo.MaxSize())
			ok = true
		} else if dbcapiType == a.A_STRING {
			//date, time, timestamp and decimal types are represented using string since:
			//1. dbcapi does not support date, time and timestamp types.
			//2. Go 1.8 does not have any decimal types
			hanaType := colInfo.NativeType()
			if hanaType != a.DT_DATE && hanaType != a.DT_TIME && hanaType != a.DT_TIMESTAMP && hanaType != a.DT_DECIMAL &&
				hanaType != a.DT_DAYDATE && hanaType != a.DT_SECONDTIME &&
				hanaType != a.DT_LONGDATE && hanaType != a.DT_SECONDDATE {
				length = int64(colInfo.MaxSize())
				ok = true
			}
		}
	}

	return length, ok
}

func (rows *rows) ColumnTypeScanType(index int) reflect.Type {
	colInfo, ok := rows.stmt.GetColumnInfo(index)

	if !ok {
		//This function does not allow you to return an error. Return string since
		//most types can be converted to/from string.
		return reflect.TypeOf(string(""))
	}
    defer colInfo.Free()

	dbcapiType := colInfo.DataType()
	switch dbcapiType {
	case a.A_BINARY:
		return reflect.TypeOf([]byte{0})
	case a.A_STRING:
		hanaType := colInfo.NativeType()
		//date, time, timestamp and decimal types are represented using string since dbcapi
		//does not support date, time and timestamp types.
		if hanaType == a.DT_DATE || hanaType == a.DT_TIME || hanaType == a.DT_TIMESTAMP ||
			hanaType == a.DT_DAYDATE || hanaType == a.DT_SECONDTIME ||
			hanaType == a.DT_LONGDATE || hanaType == a.DT_SECONDDATE {
			return reflect.TypeOf(time.Time(time.Time{}))
		}
		return reflect.TypeOf(string(""))
	case a.A_DOUBLE:
		return reflect.TypeOf(float64(0.0))
	case a.A_VAL64:
		return reflect.TypeOf(int64(0))
	case a.A_UVAL64:
		return reflect.TypeOf(uint64(0))
	case a.A_VAL32:
		return reflect.TypeOf(int32(0))
	case a.A_UVAL32:
		return reflect.TypeOf(uint32(0))
	case a.A_VAL16:
		return reflect.TypeOf(int16(0))
	case a.A_UVAL16:
		return reflect.TypeOf(uint16(0))
	case a.A_VAL8:
		return reflect.TypeOf(int8(0))
	case a.A_UVAL8:
		return reflect.TypeOf(uint8(0))
	case a.A_FLOAT:
		return reflect.TypeOf(float32(0.0))
	default:
		return reflect.TypeOf(string(""))
	}
}

func getNativeType(nativeTypeCode int) string {
	switch nativeTypeCode {
	case a.DT_DATE:
		return "DATE"
	case a.DT_TIME:
		return "TIME"
	case a.DT_TIMESTAMP:
		return "TIMESTAMP"
	case a.DT_DAYDATE:
		return "DATE"
	case a.DT_SECONDTIME:
		return "TIME"
	case a.DT_LONGDATE:
		return "TIMESTAMP"
	case a.DT_SECONDDATE:
		return "TIMESTAMP"
	case a.DT_VARCHAR1:
		return "VARCHAR"
	case a.DT_VARCHAR2:
		return "VARCHAR"
	case a.DT_ALPHANUM:
		return "ALPHANUM"
	case a.DT_CLOB:
		return "CLOB"
	case a.DT_CHAR:
		return "CHAR"
	case a.DT_STRING:
		return "STRING"
	case a.DT_DOUBLE:
		return "DOUBLE"
	case a.DT_REAL:
		return "REAL"
	case a.DT_DECIMAL:
		return "DECIMAL"
	case a.DT_INT:
		return "INT"
	case a.DT_SMALLINT:
		return "SMALLINT"
	case a.DT_BINARY:
		return "BINARY"
	case a.DT_VARBINARY:
		return "VARBINARY"
	case a.DT_BSTRING:
		return "BSTRING"
	case a.DT_BLOB:
		return "BLOB"
	case a.DT_ST_GEOMETRY:
		return "ST_GEOMETRY"
	case a.DT_ST_POINT:
		return "ST_POINT"
	case a.DT_REAL_VECTOR:
		return "REAL_VECTOR"
	case a.DT_HALF_VECTOR:
		return "HALF_VECTOR"
	case a.DT_TINYINT:
		return "TINYINT"
	case a.DT_BIGINT:
		return "BIGINT"
	case a.DT_BOOLEAN:
		return "BOOLEAN"
	case a.DT_NSTRING:
		return "NSTRING"
	case a.DT_SHORTTEXT:
		return "SHORTTEXT"
	case a.DT_NCHAR:
		return "NCHAR"
	case a.DT_NVARCHAR:
		return "NVARCHAR"
	case a.DT_NCLOB:
		return "NCLOB"
	case a.DT_TEXT:
		return "TEXT"
	case a.DT_BINTEXT:
		return "BINTEXT"
	default:
		return "UNKNOWN"
	}
}
//^^ Various ColumnType interfaces
// RowsNextResultSet (https://pkg.go.dev/database/sql/driver@go1.23.3#RowsNextResultSet)
func (rows *rows) Next(dest []driver.Value) error {
	ok := rows.stmt.FetchNext()

	if !ok {
		if rows.conn.isBadConnection() {
			return driver.ErrBadConn
		}
		return io.EOF
	}

	if rows.rowsetFetchSize >= 1 {
		return rows.getNextRowDataBulk(dest)
	} else {
		return rows.getNextRowData(dest)
	}
}

func (rows *rows) HasNextResultSet() bool {
	return rows.stmt.HasNextResult()
}

func (rows *rows) NextResultSet() error {
	ok := rows.stmt.GetNextResult()

	if !ok {
		return io.EOF
	}

	// Cleanup and rebind using the new set of metadata
	rows.cleanup()
	return rows.doSetupForFetching(rows.rowsetFetchSize >= 1)
}

func checkBulkFetchSupported(native_type a.NativeType) error {
	if native_type == a.DT_CLOB ||
		native_type == a.DT_NCLOB ||
		native_type == a.DT_BLOB {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			"LOB types are not support for Bulk Fetching"))
	} else if native_type == a.DT_ST_GEOMETRY ||
		native_type == a.DT_ST_POINT {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			"Spatial types are not support for Bulk Fetching"))
	}
	return nil
}

func getColumnSize(columnInfo a.ColumnInfo) uint64 {
	// Fixed columns (Integer and Float have specific sizes)
	// Decimal/Time columns have fixed sizes, but are pulled as ASCII
	// Non-fixed columns (NVARCHAR and [VAR]BINARY) have sizes dependent on the precision.
	// We will be fetching NVARCHAR data as CESU-8/UTF-8 data, so we need to account for
	// worse-case character expansion (multibyte chacters up to 4 bytes in length)
	if columnInfo.NativeType() == a.DT_NCHAR ||
		columnInfo.NativeType() == a.DT_NVARCHAR {
		return 4*(uint64(columnInfo.Precision())) + 1 // UTF-8 worse case characters can be up to 4 bytes in representation
	}

	return uint64(columnInfo.Precision())
}

// This needs to be called before processing the initial and subsequent resultset(s)
// (to rebind new buffers to contain the fetched data).
// When subsequent resultset(s) need to be processed (i.e. HasNextResulSet() is true)
// this needs to be called again before processing the new resultset, but in that case,
// cleanup() should be called before calling this, otherwise there will be native memory leakage
// from the processing of the previous resultset.
func (rows *rows) doSetupForFetching(isBulkFetch bool) error {
	columnCount, ok := rows.stmt.NumColumns()

	if !ok {
		err := rows.conn.getError()

		if err != nil {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNKNOWN_NUMBER_OF_COLUMNS_S, err))
		}

		// It is possible to execute a statement that can produce no rows
		// In the regular Query[Context]() cases, this is ignored (no processing results)
		// In the QueryRow[Context]() setting, sql.ErrNoRows is returned on the call to Scan
		return nil
	}

	rows.boundColumnsCount = uint(columnCount)

	if isBulkFetch {
        rows.boundColumns = make([]a.DataValue, columnCount)
	}

    rows.boundColumnInfo = make([]a.ColumnInfo, columnCount)

	var finalError error

	// We do not short-circuit the loop here on error to make the logic of
	// rows.cleanup() easier
	for i := 0; i < columnCount; i++ {
        columnInfo, ok := rows.stmt.GetColumnInfo(i)
        rows.boundColumnInfo[i] = columnInfo
		var err error

		if !ok {
			return rows.conn.getError()
		} else if isBulkFetch {
			err = checkBulkFetchSupported(columnInfo.NativeType())

			if err != nil && finalError == nil {
				finalError = err
			}

			dataValue, err := getDataValueForColumnInfo(columnInfo, rows.rowsetFetchSize, i)

			if err != nil && finalError == nil {
				finalError = err
			}
			ok = rows.stmt.BindColumn(i, dataValue)
			rows.boundColumns[i] = dataValue
		}
	}

	return finalError
}

// TODO: We have to change this to
// 1) Return an a.DataValue (using a.NewDataValue)
// 2) Initalize everything inside of it with dataValue.InitializeBuffers()
// This includes buffer (the array), is_null, length and type
func getDataValueForColumnInfo(columnInfo a.ColumnInfo, rowsetFetchSize uint,
	columnIndex int) (a.DataValue, error) {
	// Fixed columns (Integer and Float have specific sizes)
	// Decimal/Time columns have fixed sizes, but are pulled as ASCII
	// Non-fixed columns (NVARCHAR and [VAR]BINARY) have sizes dependent on the precision.
	// We will be fetching NVARCHAR data as CESU-8/UTF-8 data, so we need to account for
	// worse-case character expansion (multibyte chacters up to 4 bytes in length)
	var err error
    dataValue := a.NewDataValue()

	if columnInfo.NativeType() == a.DT_TINYINT ||
		columnInfo.NativeType() == a.DT_SMALLINT ||
		columnInfo.NativeType() == a.DT_INT ||
		columnInfo.NativeType() == a.DT_BIGINT {
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_VAL64,
								uintptr(cstd.SizeofInt64), false)
	} else if columnInfo.NativeType() == a.DT_DOUBLE ||
		columnInfo.NativeType() == a.DT_REAL {
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_DOUBLE,
								uintptr(cstd.SizeofDouble), false)
	} else if columnInfo.NativeType() == a.DT_BOOLEAN {
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_UVAL8,
								uintptr(cstd.SizeofUInt8), false)
	} else if columnInfo.NativeType() == a.DT_TIMESTAMP || columnInfo.NativeType() == a.DT_LONGDATE ||
		columnInfo.NativeType() == a.DT_SECONDDATE {
		// HANA defines the precision of TIMESTAMP columns as 27, due to the fractional part
		// being considered to be 7 digits long. However, the string itself contains the full
		// 9 digits, so we add 2 here, and consider the NULL
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_STRING,
								uintptr(cstd.SizeofChar * cstd.Size_t(30)), false)
	} else if columnInfo.NativeType() == a.DT_TIME || columnInfo.NativeType() == a.DT_SECONDTIME ||
		columnInfo.NativeType() == a.DT_DATE || columnInfo.NativeType() == a.DT_DAYDATE {
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_STRING,
			uintptr(cstd.SizeofChar * cstd.Size_t(columnInfo.Precision() + 1)), false) // Include NULL
	} else if columnInfo.NativeType() == a.DT_NVARCHAR ||
		columnInfo.NativeType() == a.DT_VARCHAR1 ||
		columnInfo.NativeType() == a.DT_VARCHAR2 ||
		columnInfo.NativeType() == a.DT_NCHAR ||
		columnInfo.NativeType() == a.DT_CHAR {
		// We will be fetching NVARCHAR data as CESU-8/UTF-8 data, so we need to account for
		// worse-case character expansion (multibyte chacters up to 4 bytes in length)
		// UTF-8 worse case characters can be up to 4 bytes in representation + NULL
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_STRING,
			uintptr(cstd.SizeofChar * cstd.Size_t(4*columnInfo.Precision() + 1)), false) // Include NULL
	} else if columnInfo.NativeType() == a.DT_BINARY ||
		columnInfo.NativeType() == a.DT_VARBINARY {
		size := cstd.Size_t(columnInfo.Precision())
		// We are not allowing BLOB bindings here currently.
		// However this description may come back for SPATIAL data
		if columnInfo.Precision() == 0 {
			size = cstd.Size_t(MAX_BINARY_SIZE)
		}
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_BINARY,
			uintptr(cstd.SizeofChar * size), false)
	} else if columnInfo.NativeType() == a.DT_REAL_VECTOR ||
		columnInfo.NativeType() == a.DT_HALF_VECTOR {
		size := cstd.Size_t(columnInfo.MaxSize())
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_BINARY,
					uintptr(cstd.SizeofChar * size), false)
	} else if columnInfo.NativeType() == a.DT_DECIMAL ||
		columnInfo.NativeType() == a.DT_FIXED16 {
		// Max Sizes
		// Fixed16 = [opt sign][38 digits with optional decimal point] + NULL = 41 characters
		// DecFloat =
		// [opt sign][34 digits of significand with decimal point ]E[opt sign][4 digit exponent] + NULL
		// = 43 characters
		// Using the larger of the two
		dataValue.InitializeBuffers(uintptr(rowsetFetchSize), a.A_STRING,
			uintptr(cstd.SizeofChar * 43), false)
	} else {
		dataValue.Free()
		err = newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
					fmt.Sprintf("Column %d: Unsupported Native Type %d", columnIndex,
						int(columnInfo.NativeType()))))
	}

	return dataValue, err
}

func (rows *rows) getNextRowDataBulk(dest []driver.Value) error {
	fetchedRows, ok := rows.stmt.FetchedRows()

	if !ok {
		return rows.conn.getError()
	}

	for i := 0; i < len(dest); i++ {
		err := rows.getDataBulk(&dest[i], i, fetchedRows)
		if err != nil {
			return err
		}
	}

	return nil
}

// This is a temporary struct used to pass bound pointer data to
// This is an internal type only meant to be use for bulk fetching
// and is used to pass bound pointer data to Scanner() custom types.
// The C memory for the bound pointer types are cleaned up in
// rows.cleanup()
// If regular values are used to fetch data when in bulk fetch mode, this will result in an error
type bulkValue struct {
	dataValues a.DataValue
	columnInfo a.ColumnInfo
	rowsetFetchSize uint
	numberOfRows    uint
	isInteger       bool
	isFloat         bool
	isBoolean       bool
	isDecimal       bool
	isString        bool
	isBinary        bool
	isTime          bool
	isDate          bool
	isSecondDate    bool
	isTimestamp     bool
	isRealVector	bool
	isHalfVector	bool
}

// This is a internally-used struct used to pass extra information for ReadLOB
// handling.
// Any C memory for the bound pointer types are cleaned up in
// rows.cleanup()
type readLobValue struct {
	rows *rows // The actual rows object it refers to (needed for the C layer statement usage)
	columnIndex uint
}

func (readLobValue *readLobValue) isNull() (bool, error) {
	dataInfo, ok := readLobValue.rows.stmt.GetDataInfo(readLobValue.columnIndex)

	if !ok {
		return false, readLobValue.rows.conn.getError()
	}

	defer dataInfo.Free()
	return dataInfo.IsNull(), nil
}

func (rows *rows) getDataBulk(val *driver.Value, index int, fetchedRows int) error {
    col := rows.boundColumns[index]
    colInfo := rows.boundColumnInfo[index]

	if colInfo == nil {
        return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_COLUMN_INFO_I, index+1))
	}

	colType := col.DataType()
	values := new(bulkValue)
	values.dataValues = col
	values.columnInfo = colInfo
	values.rowsetFetchSize = rows.rowsetFetchSize
	values.numberOfRows = uint(fetchedRows)

	switch colType {
	case a.A_BINARY:
		values.isBinary = (colInfo.NativeType() == a.DT_BINARY ||
			colInfo.NativeType() == a.DT_VARBINARY)
		values.isRealVector = (colInfo.NativeType() == a.DT_REAL_VECTOR)
		values.isHalfVector = (colInfo.NativeType() == a.DT_HALF_VECTOR)
	case a.A_STRING:
		hanaType := colInfo.NativeType()
		if hanaType == a.DT_TIMESTAMP || hanaType == a.DT_LONGDATE ||
			hanaType == a.DT_SECONDDATE {
			values.isTimestamp = true
			values.isSecondDate = hanaType == a.DT_SECONDDATE
		} else if hanaType == a.DT_DATE || hanaType == a.DT_DAYDATE {
			values.isDate = true
		} else if hanaType == a.DT_TIME || hanaType == a.DT_SECONDTIME {
			values.isTime = true
		} else if colInfo.NativeType() == a.DT_DECIMAL ||
			colInfo.NativeType() == a.DT_FIXED16 {
			values.isDecimal = true
		} else { // Regular STRING column
			values.isString = true
		}
	case a.A_UVAL8:
		values.isBoolean = (colInfo.NativeType() == a.DT_BOOLEAN)
	case a.A_VAL8:
		fallthrough
	case a.A_VAL16:
		fallthrough
	case a.A_VAL32:
		fallthrough
	case a.A_UVAL16:
		fallthrough
	case a.A_UVAL32:
		fallthrough
	case a.A_VAL64:
		values.isInteger = (colInfo.NativeType() == a.DT_TINYINT ||
			colInfo.NativeType() == a.DT_SMALLINT || colInfo.NativeType() == a.DT_INT ||
			colInfo.NativeType() == a.DT_BIGINT)
		// HANA 1 SP12 servers still use DT_TINYINT as the identificatin of boolean columns
		values.isBoolean = (colInfo.NativeType() == a.DT_TINYINT) &&
            (colInfo.Precision() == uint16(cstd.SizeofInt64)) // the type we bound as (for all integer types)
	case a.A_DOUBLE:
		fallthrough
	case a.A_FLOAT:
		values.isFloat = (colInfo.NativeType() == a.DT_DOUBLE || colInfo.NativeType() == a.DT_REAL)
	default:
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNKNOWN_COLUMN_TYPE_I,
			colType))
	}

	*val = values
	return nil
}

func (rows *rows) getNextRowData(dest []driver.Value) error {
	for i := 0; i < len(dest); i++ {
		if rows.metadataReportsColumnIsLOB(uint(i)) && rows.getFetchUsingReadLOB() {
			rows.setupInternalDataForReadLOBHandling(&dest[i], i)
		} else {
			col, ok := rows.stmt.GetColumn(i)

			if !ok {
				return rows.conn.getError()
			}

			err := getData(col, &dest[i], i, rows)
			col.Free()

			if err != nil {
				return err
			}
		}
	}

	return nil
}

	func (rows *rows) metadataReportsColumnIsLOB(index uint) bool {
	if rows.boundColumnInfo == nil || uint(rows.boundColumnsCount) < index  {
		return false
	}

	columnInfo := rows.boundColumnInfo[index]
	return (columnInfo.NativeType() == a.DT_CLOB) ||
		(columnInfo.NativeType() == a.DT_NCLOB) ||
		(columnInfo.NativeType() == a.DT_BLOB)
}

func (rows *rows) getFetchUsingReadLOB() bool {
	return rows.fetchUsingReadLob
}

func (row *rows) driverValueIsReadLOB(val *driver.Value) bool {
	v := reflect.ValueOf(val)
		_, ok := v.Interface().(*ReadLOB)
	return ok
}

func (rows *rows) setupInternalDataForReadLOBHandling(val *driver.Value, index int) {
	*val = &readLobValue{rows: rows, columnIndex: uint(index)}
}

func (rows *rows) returnBinaryValueDirectly(val *driver.Value,
    col a.DataValue) {
    colLength, _ := col.Length(0)
    value, _ := col.Value(0)
	//Go 1.8 dostreamingInsertAndVerifyLobColumnses not have any lob types so we need to fetch the entire lob in memory
	bArr := make([]byte, int(colLength))
	//Varbinary data in HANA can have a max size of 5000. If the size is greater than
	//5000, then we must be dealing with lobs.
	if colLength <= MAX_BINARY_SIZE {
		copy(bArr, (*[MAX_BINARY_SIZE]byte)(value)[:])
		*val = bArr
	} else {
		*val = convertToLargeByteArray(value, uint(colLength))
	}
}

func (rows *rows) returnStringValueDirectly(val *driver.Value,
	col a.DataValue, index int) error {
	value, _ := col.Value(0)
	strPtr := (*cstd.Char)(value)
	strVal := cstd.GoString(strPtr)
	colInfo, ok := rows.stmt.GetColumnInfo(index)

	if !ok {
        return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_COLUMN_TYPE_I, index+1))
	}
    defer colInfo.Free()

	hanaType := colInfo.NativeType()
	if hanaType == a.DT_TIMESTAMP || hanaType == a.DT_LONGDATE {
		tsVal, err := time.Parse(TS_LAYOUT_STRING, strVal)
		if err != nil {
			return err
		}
		*val = tsVal
	} else if hanaType == a.DT_SECONDDATE {
		sdVal, err := time.Parse(SECONDDATE_LAYOUT_STRING, strVal)
		if err != nil {
			return err
		}
		*val = sdVal
	} else if hanaType == a.DT_TIME || hanaType == a.DT_SECONDTIME {
		tVal, err := time.Parse(TIME_LAYOUT_STRING, strVal)
		if err != nil {
			return err
		}
		*val = tVal
	} else if hanaType == a.DT_DATE || hanaType == a.DT_DAYDATE {
		dVal, err := time.Parse(DATE_LAYOUT_STRING, strVal)
		if err != nil {
			return err
		}
		*val = dVal
	} else {
		*val = strVal
	}

	return nil
}

func getData(col a.DataValue, val *driver.Value, index int, rows *rows) error {
	isNull, _ := col.IsNull(0)

	if isNull {
		*val = nil
		return nil
	}

	colType := col.DataType()
	value, _ := col.Value(0)
	switch colType {
	case a.A_BINARY:
		rows.returnBinaryValueDirectly(val, col)
	case a.A_STRING:
		return rows.returnStringValueDirectly(val, col, index)
	case a.A_DOUBLE:
		doublePtr := (*float64)(value)
		*val = *doublePtr
	case a.A_VAL64:
		longPtr := (*int64)(value)
		*val = *longPtr
	case a.A_UVAL64:
		longPtr := (*uint64)(value)
		*val = *longPtr
	case a.A_VAL32:
		intPtr := (*int32)(value)
		*val = *intPtr
	case a.A_UVAL32:
		intPtr := (*uint32)(value)
		*val = *intPtr
	case a.A_VAL16:
		shortPtr := (*int16)(value)
		*val = *shortPtr
	case a.A_UVAL16:
		shortPtr := (*uint16)(value)
		*val = *shortPtr
	case a.A_VAL8:
		bytePtr := (*int8)(value)
		*val = *bytePtr
	case a.A_UVAL8:
		bytePtr := (*uint8)(value)
		*val = *bytePtr
	case a.A_FLOAT:
		floatPtr := (*float32)(value)
		*val = *floatPtr
	default:
		return newError(newGoDriverError(DRIVER_ERROR_UNKNOWN_TYPE))
	}

	return nil
}

func convertToLargeByteArray(buffer unsafe.Pointer, size uint) []byte {
	res := make([]byte, size)
	s := res[:]
	ptr := uintptr(unsafe.Pointer(buffer))
	for size > MAX_BINARY_SIZE {
		copy(s, (*[MAX_BINARY_SIZE]byte)(unsafe.Pointer(ptr))[:])
		s = s[MAX_BINARY_SIZE:]
		size -= MAX_BINARY_SIZE
		ptr += MAX_BINARY_SIZE
	}
	if size > 0 {
		copy(s, (*[MAX_BINARY_SIZE]byte)(unsafe.Pointer(ptr))[:size])
	}
	return res
}


// Bulk Fetching
//needed to handle nil time values
type NullTime struct {
	Time  time.Time
	Valid bool
}

//needed to handle nil binary values
type NullBytes struct {
	Bytes []byte
	Valid bool
}

type BulkNullInt64 struct {
	Int64s       []int64
	Valids       []bool
	NumberOfRows uint64
}

type BulkNullFloat64 struct {
	Float64s     []float64
	Valids       []bool
	NumberOfRows uint64
}

type NullFloat64Slice struct {
	Float64Slice []float64
	Valid		 bool
}

type BulkNullFloat64Slice struct {
	Float64Slices [][]float64
	Valids		  []bool
	NumberOfRows  uint64
}

type BulkNullBool struct {
	Bools        []bool
	Valids       []bool
	NumberOfRows uint64
}

type BulkNullString struct {
	Strings      []string
	Valids       []bool
	NumberOfRows uint64
}

type BulkNullBytes struct {
	Bytes        [][]byte
	Valids       []bool
	NumberOfRows uint64
}

type BulkNullTime struct {
	Times        []time.Time
	Valids       []bool
	NumberOfRows uint64
}

func (nullTime *NullTime) Scan(value interface{}) error {
	nullTime.Time, nullTime.Valid = value.(time.Time)
	return nil
}

func (nullTime NullTime) Value() (driver.Value, error) {
	if !nullTime.Valid {
		return nil, nil
	}
	return nullTime.Time, nil
}

func (nullBytes *NullBytes) Scan(value interface{}) error {
	nullBytes.Bytes, nullBytes.Valid = value.([]byte)
	return nil
}

func (nullBytes NullBytes) Value() (driver.Value, error) {
	if !nullBytes.Valid {
		return nil, nil
	}
	return nullBytes.Bytes, nil
}

func (bulkInt64 *BulkNullInt64) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)

	if !valid || !theValue.isInteger {
		bulkInt64.Int64s = nil
		bulkInt64.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Int64s"))
	}

	bulkInt64.convertRawCArrayToInt64Array(theValue)
	return nil
}

func (bulkInt64 *BulkNullInt64) convertRawCArrayToInt64Array(bulkValues *bulkValue) {
	if bulkInt64.Int64s == nil || len(bulkInt64.Int64s) < int(bulkValues.rowsetFetchSize) {
		bulkInt64.Int64s = make([]int64, bulkValues.rowsetFetchSize)
		bulkInt64.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}
	bulkInt64.NumberOfRows = uint64(bulkValues.numberOfRows)
	int64Size := uint64(bulkValues.dataValues.BufferSize())
	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		value, _ := bulkValues.dataValues.Value(i)
		var theValue cstd.Int64
		cstd.Memcpy(unsafe.Pointer(&theValue), value, cstd.Size_t(int64Size))
		null, _ := bulkValues.dataValues.IsNull(i)
		valid := !null
		bulkInt64.Int64s[i] = int64(theValue)
		bulkInt64.Valids[i] = valid
	}
}

func (bulkInt64 *BulkNullInt64) Value() (driver.Value, error) {
	// There is no concept of single validity anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkInt64.Int64s, nil
}

func (bulkFloat64 *BulkNullFloat64) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)

	if !valid || !theValue.isFloat {
		bulkFloat64.Float64s = nil
		bulkFloat64.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Float64s"))
	}

	bulkFloat64.convertRawCArrayToFloat64Array(theValue)
	return nil
}

func (bulkFloat64 *BulkNullFloat64) convertRawCArrayToFloat64Array(bulkValues *bulkValue) {
	if bulkFloat64.Float64s == nil || len(bulkFloat64.Float64s) < int(bulkValues.rowsetFetchSize) {
		bulkFloat64.Float64s = make([]float64, bulkValues.rowsetFetchSize)
		bulkFloat64.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}
	bulkFloat64.NumberOfRows = uint64(bulkValues.numberOfRows)
	doubleSize := uint64(bulkValues.dataValues.BufferSize())
	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		value, _ := bulkValues.dataValues.Value(i)
		var theValue cstd.Double
		cstd.Memcpy(unsafe.Pointer(&theValue), value, cstd.Size_t(doubleSize))
		null, _ := bulkValues.dataValues.IsNull(i)
		valid := !null
		bulkFloat64.Float64s[i] = float64(theValue)
		bulkFloat64.Valids[i] = valid
	}
}

func (bulkFloat64 *BulkNullFloat64) Value() (driver.Value, error) {
	// There is no concept of single validity anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkFloat64.Float64s, nil
}

func (nullFloat64Slice *NullFloat64Slice) Value() (driver.Value, error) {
	if !nullFloat64Slice.Valid {
		return nil, nil
	}
	return nullFloat64Slice.Float64Slice, nil
}

func (nullFloat64Slice *NullFloat64Slice) Scan(value interface{}) error {
	bytes, valid := value.([]byte)

	if valid {
		nullFloat64Slice.Valid = valid
		// Based on how Scan is implemented here curently, we cannot determin the column type
		// directly (to do so, we need to do something similar to what is done in the bulkValue/bulk
		// fetch case).
		// For now, we just assume that the data has to at least 1 entry of half vector entry size
		// in length to be valid, and switch on the the dataSize determined from the dimension
		// provided. If the dataSize does not match anything we expect = error
		lengthSize := int(unsafe.Sizeof(uint32(0)))
		realVectorDataSize := int(unsafe.Sizeof(uint32(0)))
		halfVectorDataSize := int(unsafe.Sizeof(uint16(0)))
		theBytesValueLen := len(bytes)

		if theBytesValueLen < lengthSize + halfVectorDataSize {
			return newError(newGoDriverError(DRIVER_ERROR_INVALID_HALFVECTOR_IN_FETCH))
		}

		dimension := binary.LittleEndian.Uint32(bytes)

		dataSize := int(int64(theBytesValueLen - lengthSize)/int64(dimension))
		var (
			float64Slice []float64
			ok bool
		)
		switch dataSize {
		case realVectorDataSize:
			float64Slice, ok = getFloat64SliceFromRealVectorByteBuffer(bytes)

			if !ok {
				return newError(newGoDriverError(DRIVER_ERROR_INVALID_HALFVECTOR_IN_FETCH))
			}
		case halfVectorDataSize:
			float64Slice, ok = getFloat64SliceFromHalfVectorByteBuffer(bytes)
		}

		if !ok {
			return newError(newGoDriverError(DRIVER_ERROR_INVALID_HALFVECTOR_IN_FETCH))
		}

		nullFloat64Slice.Float64Slice = float64Slice
	}

	return nil
}

func getFloat64SliceFromRealVectorByteBuffer(
	theBytesValues []byte) ([]float64, bool) {
	// FVecs format = 1*sizeof(int32) [for dimension] + dimension*sizeof(float32) [for vector values]
	lengthSize := int(unsafe.Sizeof(uint32(0)))
	dataSize := int(unsafe.Sizeof(uint32(0)))
	theBytesValueLen := len(theBytesValues)

	// In theory, the server could send an invalid set of bytes.
	// We handle that here.
	if theBytesValueLen < lengthSize + dataSize {
		return nil, false
	}

	dimension := binary.LittleEndian.Uint32(theBytesValues[0:])

	if int64(dimension) != int64((theBytesValueLen - lengthSize) / dataSize) {
		return nil, false
	}

	float64Slice := make([]float64, dimension)

	index := 0

	for i := dataSize; i < len(theBytesValues); i += dataSize {
		rawIntValue := binary.LittleEndian.Uint32(theBytesValues[i:])
		float32Value := *(*float32)(unsafe.Pointer(&rawIntValue))
		float64Slice[index] = float64(float32Value)
		index++
	}

	return float64Slice, true
}

func getFloat64SliceFromHalfVectorByteBuffer(theBytesValues []byte) ([]float64, bool) {
	// FVecs format = 1*sizeof(int32) [for dimension] + dimension*sizeof(float16) [for vector values]
	// NOTE: In theory, it is possible that the the bytes received may have
	// an invalid dimension relative to the the number of entries
	// (the dimension != the number of entries)
	// However, the server should be blocking this on insert,
	// so we should not have a panic
	theBytesValuesLen := len(theBytesValues)
	dataSize := int(unsafe.Sizeof(uint16(0)))
	lengthSize := int(unsafe.Sizeof(uint32(0)))

	if theBytesValuesLen <	lengthSize + dataSize {
		return nil, false
	}

	dimension := binary.LittleEndian.Uint32(theBytesValues[0:])

	if int64(dimension) != int64((theBytesValuesLen - lengthSize) / dataSize) {
		return nil, false
	}

	float64Slice := make([]float64, dimension)

	index := 0

	for i := lengthSize; i < len(theBytesValues); i += dataSize {
		rawIntValue := binary.LittleEndian.Uint16(theBytesValues[i:])
		float64Slice[index] = convertBinary16ValueToFloat64(rawIntValue)
		index++
	}

	return float64Slice, true
}

func convertBinary16ValueToFloat64(binary16 uint16) float64 {
	sign := int((binary16 >> 15) & 0x0001)
	exponent := int((binary16 >> 10) & 0x001F)
	mantissa := int(binary16 & 0x03FF)
	var result float64

	if exponent == 0 {
		result = math.Pow(float64(mantissa), float64(-24))
	} else if (exponent == 31) {
		if mantissa == 0 { // Infinity
			if sign > 0 { // negative
				result = math.Inf(-1)
			} else {
				result = math.Inf(1)
			}
		} else { // NaN
			result = math.NaN()
		}
	} else {
		result = float64(mantissa + 1024)*math.Exp2(float64(exponent-25))
	}

	if sign > 0 { // negative
		result = -1 * result
	}

	return result
}

func (bulkNullFloat64Slice *BulkNullFloat64Slice) Value() (driver.Value, error) {
	// There is no concept of single validity (NULL) anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkNullFloat64Slice.Float64Slices, nil
}

func (bulkNullFloat64Slice *BulkNullFloat64Slice) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)
	if !valid || (!theValue.isRealVector && !theValue.isHalfVector) {
		bulkNullFloat64Slice.Float64Slices = nil
		bulkNullFloat64Slice.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Float64Slice"))
	}

	return bulkNullFloat64Slice.convertRawCArrayToFloat64Slice(theValue)
}

func (bulkNullFloat64Slice *BulkNullFloat64Slice) convertRawCArrayToFloat64Slice(
	bulkValues *bulkValue) error {
	if bulkNullFloat64Slice.Float64Slices == nil ||
		len(bulkNullFloat64Slice.Float64Slices) < int(bulkValues.rowsetFetchSize) {
		bulkNullFloat64Slice.Float64Slices = make([][]float64, bulkValues.rowsetFetchSize)
		bulkNullFloat64Slice.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}
	bulkNullFloat64Slice.NumberOfRows = uint64(bulkValues.numberOfRows)
	var size uint64

	// Data is sent as binary (and this is checked earlier), but columns are reported with a
	// dimension, and have a size of (1*sizeof(int32) + dimension*sizeof(float64)), as reported
	// by colInfo.MaxSize().
	// It is expected that the length always gives the right value of the length of bytes sent
	// for a particular entry, especially in the case of an unconstrained REAL_VECTOR value,
	// (MaxSize() != length)
	size = uint64(bulkValues.columnInfo.MaxSize())

	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		null, _ := bulkValues.dataValues.IsNull(i)
		length, _ := bulkValues.dataValues.Length(i)
		_ = length

		valid := !null
		bulkNullFloat64Slice.Valids[i] = valid

		if valid {
			value, _ := bulkValues.dataValues.Value(i)
			theValue := convertToLargeByteArray(value, uint(math.Min(float64(length),
				float64(size))))

			var (
				float64Slice []float64
				ok bool
			)

			if bulkValues.isRealVector {
				float64Slice, ok = getFloat64SliceFromRealVectorByteBuffer(theValue)

				if !ok {
					return newError(newGoDriverErrorWithArgs(
													DRIVER_ERROR_INVALID_REALVECTOR_IN_BULK_FETCH_I,
													i+1))
				}
			} else { // isHalfVector
				float64Slice, ok = getFloat64SliceFromHalfVectorByteBuffer(theValue)

				if !ok {
					return newError(newGoDriverErrorWithArgs(
													DRIVER_ERROR_INVALID_HALFVECTOR_IN_BULK_FETCH_I,
													i+1))
				}
			}

			bulkNullFloat64Slice.Float64Slices[i] = float64Slice
		}
	}

	return nil
}

func (bulkBool *BulkNullBool) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)
	if !valid || !theValue.isBoolean {
		bulkBool.Bools = nil
		bulkBool.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Bools"))
	}

	bulkBool.convertRawCArrayToBoolArray(theValue)
	return nil
}

func (bulkBool *BulkNullBool) convertRawCArrayToBoolArray(bulkValues *bulkValue) {
	if bulkBool.Bools == nil || len(bulkBool.Bools) < int(bulkValues.rowsetFetchSize) {
		bulkBool.Bools = make([]bool, bulkValues.rowsetFetchSize)
		bulkBool.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}
	bulkBool.NumberOfRows = uint64(bulkValues.numberOfRows)
	boolSize := uint64(bulkValues.dataValues.BufferSize())
	// Because HANA 1 servers report BOOLEAN columns as TINYINT, and we bind all
	// Integer types with cstd.Int64, here we want to use cstd.Int64 as the pointer type
	if boolSize == uint64(cstd.SizeofInt64) {
		for i := 0; i < int(bulkValues.numberOfRows); i++ {
			value, _ := bulkValues.dataValues.Value(i)
			var theValue cstd.Int64
			cstd.Memcpy(unsafe.Pointer(&theValue), value, cstd.Size_t(boolSize))
			null, _ := bulkValues.dataValues.IsNull(i)
			bulkBool.Bools[i] = bool(theValue == 1)
			bulkBool.Valids[i] = null
		}
	} else { // It was bound as dbcapi_bool
		for i := 0; i < int(bulkValues.numberOfRows); i++ {
			value, _ := bulkValues.dataValues.Value(i)
			var theValue a.CApiBool
			cstd.Memcpy(unsafe.Pointer(&theValue), value, cstd.Size_t(boolSize))
			null, _ := bulkValues.dataValues.IsNull(i)
			valid := !null
			bulkBool.Bools[i] = bool(theValue == 1)
			bulkBool.Valids[i] = valid
		}
	}
}

func (bulkBool *BulkNullBool) Value() (driver.Value, error) {
	// There is no concept of single validity anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkBool.Bools, nil
}

// TODO: Continue the changing to use bulkValues.dataValues directly
func (bulkTime *BulkNullTime) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)

	if !valid || (!theValue.isDate && !theValue.isTime && !theValue.isTimestamp) {
		bulkTime.Times = nil
		bulkTime.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Times"))
	}

	var err error

	if theValue.isTimestamp {
		if theValue.isSecondDate {
			err = bulkTime.convertRawCArrayToTimeArray(theValue, SECONDDATE_LAYOUT_STRING)
		} else {
			err = bulkTime.convertRawCArrayToTimeArray(theValue, TS_LAYOUT_STRING)
		}
	} else if theValue.isDate {
		err = bulkTime.convertRawCArrayToTimeArray(theValue, DATE_LAYOUT_STRING)
	} else if theValue.isTime {
		err = bulkTime.convertRawCArrayToTimeArray(theValue, TIME_LAYOUT_STRING)
	}

	return err
}

func (bulkTime *BulkNullTime) Value() (driver.Value, error) {
	// There is no concept of single validity (NULL) anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkTime.Times, nil
}

func (bulkTime *BulkNullTime) convertRawCArrayToTimeArray(bulkValues *bulkValue,
	layoutFormat string) error {
	if bulkTime.Times == nil || len(bulkTime.Times) < int(bulkValues.rowsetFetchSize) {
		bulkTime.Times = make([]time.Time, bulkValues.rowsetFetchSize)
		bulkTime.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}

	bulkTime.NumberOfRows = uint64(bulkValues.numberOfRows)
	stringSize := uint64(bulkValues.dataValues.BufferSize())
	var err error

	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		null, _ := bulkValues.dataValues.IsNull(i)
		valid := !null
		bulkTime.Valids[i] = valid

		if valid {
            value, _ := bulkValues.dataValues.Value(i)
			// It is expected that each string should be Null terminated, coming from dbcapi
			// Just in case it isn't, we take the safe route and NULL terminate the provided buffer
			// always, so that cstd.GoString() does not run off the end of the buffer
			theValuePtrEnd := (*cstd.Char)(unsafe.Pointer(uintptr(value) +
				uintptr(cstd.Size_t(stringSize-1))))
			*theValuePtrEnd = 0
			theValue := cstd.GoString((*cstd.Char)(value))
			bulkTime.Times[i], err = time.Parse(layoutFormat, theValue)

			if err != nil {
				break
			}
		}
	}

	return err
}

func (bulkString *BulkNullString) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)

	if !valid || (!theValue.isString && !theValue.isDecimal) {
		bulkString.Strings = nil
		bulkString.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Strings"))
	}

	bulkString.convertRawCArrayToStringArray(theValue)
	return nil
}

func (bulkString *BulkNullString) Value() (driver.Value, error) {
	// There is no concept of single validity (NULL) anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkString.Strings, nil
}

func (bulkString *BulkNullString) convertRawCArrayToStringArray(bulkValues *bulkValue) {
	if bulkString.Strings == nil || len(bulkString.Strings) < int(bulkValues.rowsetFetchSize) {
		bulkString.Strings = make([]string, bulkValues.rowsetFetchSize)
		bulkString.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}

	bulkString.NumberOfRows = uint64(bulkValues.numberOfRows)
	stringSize := uint64(bulkValues.dataValues.BufferSize())

	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		null, _ := bulkValues.dataValues.IsNull(i)
		valid := !null
		bulkString.Valids[i] = valid

		if valid {
            value, _ := bulkValues.dataValues.Value(i)
			// It is expected that each string should be Null terminated, coming from dbcapi
			// However, there are cases were buffers may not be NULL terminated, for example in
			// these cases:
			// - The server underrepresents the length of the data in the metadata
			// - The buffer is not large enough to hold an entire ending character
			//   (data may be uninitialized there)
			// We can consider doing a continuous loop to get the string data in cases
			// of strings with length > max and then ultimately creating the string from that
			// For now, we take the safe route and NULL terminate the provided buffer always,
			// so that cstd.GoString() does not run off the end of the buffer
			// Unfortunate side effect: The cases described above could result in a truncated
			// string being created, and there is currently no way to know if a specific value
			// was truncated
			theValuePtrEnd := (*cstd.Char)(unsafe.Pointer(uintptr(value) +
				uintptr(cstd.Size_t(stringSize-1))))
			*theValuePtrEnd = 0
			theValue := cstd.GoString((*cstd.Char)(value))
			bulkString.Strings[i] = theValue
		}
	}
}

func (bulkBytes *BulkNullBytes) Scan(value interface{}) error {
	theValue, valid := value.(*bulkValue)

	if !valid || (!theValue.isBinary && !theValue.isRealVector && !theValue.isHalfVector) {
		bulkBytes.Bytes = nil
		bulkBytes.Valids = nil
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_BULK_FETCH_TYPE_S, "Bytes"))
	}

	bulkBytes.convertRawCArrayToByteArray(theValue)
	return nil
}

func (bulkBytes *BulkNullBytes) Value() (driver.Value, error) {
	// There is no concept of single validity (NULL) anymore.
	// If Scan() failed, then both of these will be nil, and
	// the application should depend on the Error from Scan() to tell it
	// what happened
	return bulkBytes.Bytes, nil
}

func (bulkBytes *BulkNullBytes) convertRawCArrayToByteArray(bulkValues *bulkValue) {
	if bulkBytes.Bytes == nil || len(bulkBytes.Bytes) < int(bulkValues.rowsetFetchSize) {
		bulkBytes.Bytes = make([][]byte, bulkValues.rowsetFetchSize)
		bulkBytes.Valids = make([]bool, bulkValues.rowsetFetchSize)
	}
	bulkBytes.NumberOfRows = uint64(bulkValues.numberOfRows)
	var size uint64

	if bulkValues.isBinary {
		size = uint64(bulkValues.dataValues.BufferSize())
	} else if bulkValues.isRealVector || bulkValues.isHalfVector {
		// We want to use colInfo.MaxSize() from columnInfo here instead of Precision() or
		// BufferSize() which report the dimension only).
		// It is expected that the length always gives the right value, especially in the case
		// of an unconstrained REAL_VECTOR value
		size = uint64(bulkValues.columnInfo.MaxSize())
	}

	for i := 0; i < int(bulkValues.numberOfRows); i++ {
		null, _ := bulkValues.dataValues.IsNull(i)
		length, _ := bulkValues.dataValues.Length(i)
		valid := !null
		bulkBytes.Valids[i] = valid

		if valid {
            value, _ := bulkValues.dataValues.Value(i)
			theValue := convertToLargeByteArray(value, uint(math.Min(float64(length), float64(size))))
			bulkBytes.Bytes[i] = theValue
		}
	}
}
//^^ Bulk Fetching
//^^ RowsNextResultSet

// Cleanup helper functions
func (rows *rows) cleanup() {
	// Remaining pointers are set to nil here for the case of
	// usage in Multiple Result Sets
	if rows.boundColumns != nil || rows.boundColumnInfo != nil {
		for i := 0; uint(i) < rows.boundColumnsCount; i++ {
			if rows.boundColumns != nil && rows.boundColumns[i] != nil {
				rows.boundColumns[i].Free()
				rows.boundColumns[i] = nil
			}
			if rows.boundColumnInfo != nil && rows.boundColumnInfo[i] != nil {
				rows.boundColumnInfo[i].Free()
				rows.boundColumnInfo[i] = nil
			}
		}
		rows.boundColumns = rows.boundColumns[:0]
		rows.boundColumnInfo = rows.boundColumnInfo[:0]
	}

	rows.boundColumnsCount = 0
}
//^^ Cleanup helper functions

//keep track of rows affected after inserts and updates
type result struct {
	rowsAffected int64
	err          error
}

func (result *result) LastInsertId() (int64, error) {
	return -1, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
		"Feature not supported"))
}

func (result *result) RowsAffected() (int64, error) {
	if result.err != nil {
		return 0, result.err
	}
	return result.rowsAffected, nil
}
