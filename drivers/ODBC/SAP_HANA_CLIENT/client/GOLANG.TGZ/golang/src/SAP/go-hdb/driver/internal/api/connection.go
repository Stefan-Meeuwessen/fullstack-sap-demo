package api

/*
#cgo CFLAGS: -I${SRCDIR}/includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"

extern void warningCallback(char*, dbcapi_i32, char*, void*);

typedef void (*warning_callback_t)(dbcapi_stmt *,
								const char *,
								dbcapi_i32,
								const char *,
								void *);

void connection_warning_callback(dbcapi_stmt * stmt, // Not used
										const char *  warning_message,
										dbcapi_i32    warning_code,
										const char *  sql_state,
										void *        user_data ) {
	warningCallback((char*)warning_message, warning_code, (char*)sql_state,
					user_data);
}

void statement_warning_callback(dbcapi_stmt * stmt, // Not used
										const char *  warning_message,
										dbcapi_i32    warning_code,
										const char *  sql_state,
										void *        user_data ) {
	warningCallback((char*)warning_message, warning_code, (char*)sql_state, user_data);
}
*/
import "C"
import (
	"time"
	"runtime/cgo"
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

type WarningCallback = C.warning_callback_t

// Note: This is just meant to be an API object to wrap the C layer API
// So conventional Go idioms for error handling are NOT followed here.
// It is expected that a Go object will wrap/contain/use this object's
// API within a more Go idiomatic API.
// This allows for API testing to be done as well, through the interface provide
// here
type Connection interface {
	Free()
	Connect() bool
	Disconnect() bool
	SetConnectProperty(key string, value string) bool
	CheckConnection(communicationTimeout time.Duration) bool
	Commit() bool
	Rollback() bool
	SetAutoCommit(autoCommit bool) bool
	ExecuteDirect(sql string) (Statement, bool)
	ExecuteDirectWithTimeout(sql string, communicationTimeout time.Duration) (Statement, bool)
	ExecuteImmediate(sql string) bool
	Prepare(sql string) (PreparedStatement, bool)
	SetTransactionIsolation(isolationLevel int) bool
	ErrorLength() uintptr
	Error() (int, string)
	GetDiagnosticRecord(recNumber int) DiagnosticRecord
	GetClientInfoRaw(clientInfoKey string) unsafe.Pointer
	SetupStatementWarningCallback(h *cgo.Handle)
	SetupConnectionWarningCallback(h *cgo.Handle)
	RemoveWarningCallback()
}

type APIConnection struct {
	apiConnection *CApiConnection
}

type SeverityLevel int

const (
	ErrorLevel_None SeverityLevel = iota
	ErrorLevel_Warning
	ErrorLevel_Error
	ErrorLevel_Fatal
)

func NewConnection() Connection {
	conn := C.dbcapi_new_connection()

	if conn == nil {
		return nil
	}

	return &APIConnection{apiConnection: conn}
}

func (connection *APIConnection) Free() {
	C.dbcapi_free_connection(connection.apiConnection)
	connection.apiConnection = nil
}

func (connection *APIConnection) Connect() bool {
	disconn := C.dbcapi_connect2(connection.apiConnection)
	return disconn == 1
}

func (connection *APIConnection) Disconnect() bool {
	disconn := C.dbcapi_disconnect(connection.apiConnection)
	return disconn == 1
}

func (connection *APIConnection) SetConnectProperty(key string, value string) bool {
	cKey := (*C.char)(cstd.CString(key))
	defer cstd.Free(unsafe.Pointer(cKey))
	cValue := (*C.char)(cstd.CString(value))
	defer cstd.Free(unsafe.Pointer(cValue))
	return C.dbcapi_set_connect_property(connection.apiConnection, cKey, cValue) == 1
}

func (connection *APIConnection) Commit() bool {
	commitRes := C.dbcapi_commit(connection.apiConnection)

	return commitRes == 1
}

func (connection *APIConnection) CheckConnection(communicationTimeout time.Duration) bool {
	result := C.dbcapi_check_connection(connection.apiConnection,
		C.dbcapi_u32(communicationTimeout.Milliseconds()));
	return (result == 1)
}

func (connection *APIConnection) Rollback() bool {
	rollbackRes := C.dbcapi_rollback(connection.apiConnection)

	return rollbackRes == 1
}


func (connection *APIConnection) SetAutoCommit(autoCommit bool) bool {
	var autoCommRes C.dbcapi_bool

	if autoCommit {
		autoCommRes = C.dbcapi_set_autocommit(connection.apiConnection, 1)
	} else {
		autoCommRes = C.dbcapi_set_autocommit(connection.apiConnection, 0)
	}

	return autoCommRes == 1
}

func (connection *APIConnection) ExecuteDirect(sql string) (Statement, bool) {
	cSqlStr := (*C.char)(cstd.CString(sql))
	defer cstd.Free(unsafe.Pointer(cSqlStr))
	api_stmt := C.dbcapi_execute_direct(connection.apiConnection, cSqlStr)
	if api_stmt == nil {
		return nil, false
	}
	return newAPIStatement(api_stmt), true
}

func (connection *APIConnection) ExecuteDirectWithTimeout(sql string, communicationTimeout time.Duration) (Statement, bool) {
	cSqlStr := (*C.char)(cstd.CString(sql))
	defer cstd.Free(unsafe.Pointer(cSqlStr))
	api_stmt := C.dbcapi_execute2_direct(connection.apiConnection, cSqlStr,
		C.dbcapi_u32(communicationTimeout.Milliseconds()))
	if api_stmt == nil {
		return nil, false
	}
	return newAPIStatement(api_stmt), true
}

func (connection *APIConnection) ExecuteImmediate(sql string) bool {
	cSqlStr := (*C.char)(cstd.CString(sql))
	defer cstd.Free(unsafe.Pointer(cSqlStr))
	return C.dbcapi_execute_immediate(connection.apiConnection, cSqlStr) == (CApiBool)(1)
}

func (connection *APIConnection) Prepare(sql string) (PreparedStatement, bool) {
	cSqlStr := (*C.char)(cstd.CString(sql))
	defer cstd.Free(unsafe.Pointer(cSqlStr))
	apiStatement := C.dbcapi_prepare(connection.apiConnection, cSqlStr)
	if apiStatement == nil {
		return nil, false
	}

	return newAPIPreparedStatement(apiStatement), true
}

func (connection *APIConnection) SetTransactionIsolation(isolationLevel int) bool {
	isolationLevelRes := C.dbcapi_set_transaction_isolation(connection.apiConnection, C.dbcapi_u32(isolationLevel))
	return (isolationLevelRes == 1)
}


func (connection *APIConnection) ErrorLength() uintptr {
	return (uintptr)(C.dbcapi_error_length(connection.apiConnection))
}

func (connection *APIConnection) Error() (int, string) {
	errorLen := connection.ErrorLength()
	if errorLen == 0 {
		errorLen = 1
	}
	err := make([]byte, errorLen)
	errCode := C.dbcapi_error(connection.apiConnection, (*C.char)(unsafe.Pointer(&err[0])), (C.size_t)(errorLen))

	if errCode == 0 {
		return 0, ""
	}

	return int(errCode), string(err[:errorLen - 1])
}

func (connection *APIConnection) GetDiagnosticRecord(recNumber int) DiagnosticRecord {
	var (
		errorCode  C.int
		errorText  *C.char
		textLength C.int
		isError    C.bool
		errorLevel SeverityLevel
	)
	theSqlState := make([]byte, int(C.DBCAPI_SQLSTATE_SIZE))
	res := C.dbcapi_get_diagnostic_record(connection.apiConnection, C.int(recNumber),
											&errorCode,
											(*C.char)(unsafe.Pointer(&theSqlState[0])),
											(**C.char)(unsafe.Pointer(&errorText)),
											&textLength,
											&isError)

	if res == 1 { // has error
		if isError == C.bool(true) {
			errorLevel = ErrorLevel_Error
		} else {
			errorLevel = ErrorLevel_Warning
		}
		return newDiagnosticRecord(int(errorCode),
					cstd.GoStringN((*cstd.Char)(errorText), cstd.Int(textLength)),
					cstd.GoStringN((*cstd.Char)(unsafe.Pointer(&theSqlState[0])),
					cstd.Int(C.DBCAPI_SQLSTATE_SIZE - 1)), errorLevel)
	} else {
		return nil // No error
	}
}

func (connection *APIConnection) GetClientInfoRaw(clientInfoKey string) unsafe.Pointer {
	clientInfoKeyC := (*C.char)(cstd.CString(clientInfoKey))
	defer cstd.Free(unsafe.Pointer(clientInfoKeyC))
	return unsafe.Pointer(C.dbcapi_get_clientinfo(connection.apiConnection, clientInfoKeyC))
}

func (connection *APIConnection) SetupConnectionWarningCallback(h *cgo.Handle) {
	connection.setupWarningCallback((WarningCallback)(C.connection_warning_callback), unsafe.Pointer(h))
}

func (connection *APIConnection) SetupStatementWarningCallback(h *cgo.Handle) {
	connection.setupWarningCallback((WarningCallback)(C.statement_warning_callback), unsafe.Pointer(h))
}

func (connection *APIConnection) RemoveWarningCallback() {
	connection.setupWarningCallback(nil, nil)
}

func (connection *APIConnection) setupWarningCallback(callback WarningCallback,
	context unsafe.Pointer) {
	C.dbcapi_register_warning_callback(connection.apiConnection,
		(C.DBCAPI_CALLBACK_PARM)(callback),
		context)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ Connection			 = (*APIConnection)(nil)
)
