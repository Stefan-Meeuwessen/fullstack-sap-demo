package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

// This is a wrapper for the struct we normally used to provide bound input
// parameter information to the API
// It is normally used in describ_param call to get information filled in by the API
// about the destination column, and then buffers are provided for the data
// and NULL information
type BindData interface {
	Free()
	ParamName() string
	DataDirection() ParamDataDirection
	DataType() NativeType
	InitializeBuffers(numberOfValues uintptr, isAddress bool, isForDataAtExecute bool)
	SetNull(index int, isNull bool) bool // 0 based
	SetValue(index int, value unsafe.Pointer, dataTypeSize uintptr) bool // 0 based
    SetLength(index int, length uintptr) bool // 0 based
	SetType(dataType DataType)
	BoundData() *CApiBindData
}

type APIBindData struct {
	apiBindData *CApiBindData
	dataTypeSize uintptr
	numberOfValues uintptr
}

func newAPIBindData(apiBindData *CApiBindData) *APIBindData {
	return &APIBindData{apiBindData: apiBindData}
}

func (bindData *APIBindData) BoundData() *CApiBindData {
    return bindData.apiBindData
}

func (bindData *APIBindData) Free() {
	// 1)Free input_value entry (dbcapi_data_value)
	// - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
	// This shouldn't really be used becasue it isn't sending/fetching any value data
	// it is only getting information for the type (dbcapi_data_type), but just in case
	// 2)Free output_value entry (dbcapi_data_value)
	// - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
	// This shouldn't really be used becasue it isn't sending/fetching any value data
	// it is only getting information for the type (dbcapi_data_type), but just in case
	// This is an internal type, it should be known that use after calling cstd.Free() is an erro
	// and can cause a panic
	if bindData.apiBindData != nil {
		// NOTE: If is address, we should be looping through based
		// on size of a pointer and deallocating each location!
		if bindData.apiBindData.value.buffer != nil {
			if bindData.apiBindData.value.is_address == CApiBool(1) {
				for i := 0; i < int(bindData.numberOfValues); i++ {
					bufferLocation := (**cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(bindData.apiBindData.value.buffer)) +
						uintptr(cstd.Size_t(unsafe.Sizeof(uintptr(0)))*cstd.Size_t(i))))
					if *bufferLocation != nil {
						cstd.Free(unsafe.Pointer(*bufferLocation))
					}
				}
			}
			cstd.Free(unsafe.Pointer(bindData.apiBindData.value.buffer))
			bindData.apiBindData.value.buffer = nil
		}
		if bindData.apiBindData.value.length != nil {
			cstd.Free(unsafe.Pointer(bindData.apiBindData.value.length))
			bindData.apiBindData.value.length = nil
		}
		if bindData.apiBindData.value.is_null != nil {
			cstd.Free(unsafe.Pointer(bindData.apiBindData.value.is_null))
			bindData.apiBindData.value.is_null = nil
		}

		cstd.Free(unsafe.Pointer(bindData.apiBindData))
		bindData.apiBindData = nil
		bindData.numberOfValues = 0
	}
}

func (bindData *APIBindData) ParamName() string {
	return cstd.GoString((*cstd.Char)(bindData.apiBindData.name))
}

func (bindData *APIBindData) DataDirection() ParamDataDirection {
	return (ParamDataDirection)(bindData.apiBindData.direction)
}

func (bindData *APIBindData) DataType() DataType {
	return (NativeType)(bindData.apiBindData.value._type)
}

func (bindData *APIBindData) InitializeBuffers(numberOfValues uintptr, isAddress bool,
	isForDataAtExecute bool) {
	bindData.numberOfValues = numberOfValues

	if isAddress {
        var value uintptr
		bindData.apiBindData.value.is_address = CApiBool(1)
		if !isForDataAtExecute {
			bindData.apiBindData.value.buffer = (*C.char)(cstd.Calloc(cstd.Size_t(numberOfValues),
				cstd.Size_t(unsafe.Sizeof(value))))
		}
		bindData.apiBindData.value.length = (*C.size_t)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(cstd.SizeofSize_t)))
		bindData.apiBindData.value.is_null = (*CApiBool)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(unsafe.Sizeof(CApiBool(0)))))
	} else {
		if numberOfValues > 1 {
			panic("Bulk binding using non-address binding is not supported")
		}
		// We do not bulk bink using non-address binding currently, so numberOfValues should = 1
		bindData.apiBindData.value.is_address = CApiBool(0)
		bindData.apiBindData.value.length = (*C.size_t)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.SizeofSize_t))
		bindData.apiBindData.value.buffer_size = C.size_t(numberOfValues)

		if isForDataAtExecute {
			*bindData.apiBindData.value.length = C.size_t(2147483647)
		} else {
			bindData.apiBindData.value.is_null = (*CApiBool)(cstd.Calloc(cstd.Size_t(numberOfValues),
				cstd.Size_t(unsafe.Sizeof(CApiBool(0)))))
		}
	}
}

func (bindData *APIBindData) SetNull(index int, isNull bool) bool {// 0 based
	if bindData.apiBindData == nil || bindData.apiBindData.value.is_null == nil || index < 0 ||
		index >= int(bindData.numberOfValues) {
		return false
	}
	if bindData.apiBindData.value.is_address == CApiBool(1) {
		var nullValue CApiBool
		_ = nullValue
		nullLocation := (*CApiBool)(unsafe.Pointer(uintptr(unsafe.Pointer(bindData.apiBindData.value.is_null)) +
			uintptr(cstd.Size_t(unsafe.Sizeof(nullValue))*cstd.Size_t(index))))
		if isNull {
			*nullLocation = CApiBool(1)
		} else {
			*nullLocation = CApiBool(0)
		}
	} else {
		_ = index
		if bindData.numberOfValues > 1 {
			panic("Bulk null setting using non-address binding is not supported")
		}
		nullLocation := bindData.apiBindData.value.is_null

		if isNull {
			*nullLocation = CApiBool(1)
		} else {
			*nullLocation = CApiBool(0)
		}
	}

	return true
}

func (bindData *APIBindData) SetLength(index int, length uintptr) bool { // 0 based
	if bindData.apiBindData == nil || bindData.apiBindData.value.length == nil || index < 0 ||
		index >= int(bindData.numberOfValues) {
		return false
	}
	if bindData.apiBindData.value.is_address == CApiBool(1) {
		lengthLocation := (*cstd.Size_t)(unsafe.Pointer(uintptr(unsafe.Pointer(bindData.apiBindData.value.length)) +
			uintptr(cstd.SizeofSize_t*cstd.Size_t(index))))
		*lengthLocation = cstd.Size_t(length)
	} else {
		_ = index
		if bindData.numberOfValues > 1 {
			panic("Bulk length setting using non-address binding is not supported")
		}
		lengthLocation := (*cstd.Size_t)(bindData.apiBindData.value.length)
		*lengthLocation = cstd.Size_t(length)
	}
	return true
}

func (bindData *APIBindData) SetValue(index int, value unsafe.Pointer, dataTypeSize uintptr) bool { // 0 based
	if bindData.apiBindData == nil || index < 0 ||
		index >= int(bindData.numberOfValues) {
		return false
	}

	if bindData.apiBindData.value.is_address == CApiBool(1) {
		var valueSize uintptr
		_ = valueSize
		bufferLocation := (**cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(bindData.apiBindData.value.buffer)) +
			uintptr(unsafe.Sizeof(valueSize)*uintptr(index))))
		*bufferLocation = (*cstd.Char)(value)
		lengthLocation := (*cstd.Size_t)(unsafe.Pointer(uintptr(unsafe.Pointer(bindData.apiBindData.value.length)) +
			uintptr(cstd.SizeofSize_t*cstd.Size_t(index))))
		*lengthLocation = cstd.Size_t(dataTypeSize)
	} else {
		_ = index
		// We don't bulk bind using non-address binding currently
		bindData.apiBindData.value.buffer = (*C.char)(value)
		lengthLocation := (*cstd.Size_t)(bindData.apiBindData.value.length)
		*lengthLocation = cstd.Size_t(dataTypeSize)
		bindData.apiBindData.value.buffer_size = C.size_t(dataTypeSize)
	}

	return true
}

func (bindData *APIBindData) SetType(dataType DataType) {
	bindData.apiBindData.value._type = CApiDataType(dataType)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ BindData             = (*APIBindData)(nil)
)
