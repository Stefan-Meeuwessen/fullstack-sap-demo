package api

type ParamDataDirection = int

const (
    /// Invalid data direction.
    DD_INVALID	ParamDataDirection = iota
    /// Input-only host variables.
    DD_INPUT                       = 0x1
    /// Output-only host variables.
    DD_OUTPUT                      = 0x2
    /// Input and output host variables.
    DD_INPUT_OUTPUT                = 0x3
)
