package driver

import (
	"container/list"
	"context"
	"database/sql"
	"database/sql/driver"
	"fmt"
	"math"
	"reflect"
	"runtime/cgo"
	"time"
	api "SAP/go-hdb/driver/internal/api"
)

//For conversion between string and timestamp
const TS_LAYOUT_STRING = "2006-01-02 15:04:05.000000000"

//For conversion between string and timestamp without without seconds
const SECONDDATE_LAYOUT_STRING = "2006-01-02 15:04:05"

//For conversion between string and date
const DATE_LAYOUT_STRING = "2006-01-02"

//For conversion between string and time
const TIME_LAYOUT_STRING = "15:04:05"

//database connection
type connection struct {
	apiConnection api.Connection
	dsnInfo *DsnInfo
	theErrors *HdbError // Holds errors/warnings
	handle *cgo.Handle // Holds the pointer to the connection itself for C callback usage
}

func newConnection() (*connection, error) {
	apiConnection := api.NewConnection()

	if apiConnection == nil {
		return nil, newError(newGoDriverError(DRIVER_ERROR_CONNECTION_ALLOC_FAILED))
	}
	return &connection{apiConnection: apiConnection}, nil
}

func (connection *connection) connectWithDSNString(dsn string) error {
	dsnInfo, err := parseDSN(dsn)
	if err != nil {
		return err
	}
	connection.dsnInfo = dsnInfo

	// TODO can a warning occur here?
	err = connection.setPropertiesAndConnect()

	if err != nil {
		connection.apiConnection.Free()
		return err
	}

	autoCommRes := connection.apiConnection.SetAutoCommit(true)

	if !autoCommRes {
		connection.apiConnection.Free()
		return connection.getError()
	}

	if connection.dsnInfo.ReportWarningsWithErrors() {
		h := cgo.NewHandle(connection)
		connection.handle = &h
		connection.apiConnection.SetupConnectionWarningCallback(&h)
	}

	return nil
}

// driver.Pinger interface
func (connection *connection) Ping(ctx context.Context) error {
	var duration time.Duration
	deadline, ok := ctx.Deadline()

	if ok {
		duration = deadline.Sub(time.Now())

		if duration.Milliseconds() < 0 ||
			duration.Milliseconds() > int64(math.MaxUint32) {
			return newError(newGoDriverError(DRIVER_ERROR_INVALID_COMMUNICATION_TIMEOUT))
		}
	}

	valid := connection.apiConnection.CheckConnection(duration)
	detailedErrors := getPingDetailedErrorFromContext(ctx)

	if detailedErrors {
		err := connection.getError()

		if err != nil {
			// Could occur if a more detailed error occurs
			// e.g. Password policy change
			return err
		} else if !valid {
			return driver.ErrBadConn
		}
	} else if !valid {
		return driver.ErrBadConn
	}

	return nil
}

// driver.Conn inteface
func (connection *connection) Close() error {
	defer connection.apiConnection.Free()
	disconn := connection.apiConnection.Disconnect()

	if connection.dsnInfo.ReportWarningsWithErrors() {
		connection.apiConnection.RemoveWarningCallback()
	}

	var err error
	if !disconn {
		connection.resetErrors() // Already returned from Query[Context]/Exec[Context]
		err =  connection.getError()

		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				connection.addError(hanaError)
				return connection.errors()
			}
		}
	}
	return err
}

// driver.Conn interface
func (connection *connection) Prepare(query string) (driver.Stmt, error) {
	return connection.prepareInternal(context.Background(), query)
}

// driver.ConnPrepareContext inteface
func (connection *connection) PrepareContext(ctx context.Context, query string) (driver.Stmt, error) {
	return connection.prepareInternal(ctx, query)
}

func (connection *connection) prepareInternal(ctx context.Context, query string) (driver.Stmt, error) {
	connection.resetErrors()
	ps, valid := connection.apiConnection.Prepare(query)

	if !valid {
		err :=  connection.getError()
		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				connection.addError(hanaError)
				return nil, connection.errors()
			}

			// Error is nil or required for upper layer - return directly
			return nil, err
		}
		return nil, connection.errors()
	}

	return connection.newPreparedStatement(ctx, ps, query)
}

func (connection *connection) newPreparedStatement(ctx context.Context,
	ps api.PreparedStatement, query string) (driver.Stmt, error) {
	stmt := statement{query: query, apiStatement: ps, conn: connection,
		storedWriteLobs: make(map[uint]*list.List)}

	stmt.setPermanentPacketSize(ctx)

	if connection.dsnInfo.ReportWarningsWithErrors() {
		h := cgo.NewHandle(&stmt)
		stmt.handle = &h
		connection.apiConnection.SetupStatementWarningCallback(&h)
	}

	return &stmt, connection.errors()
}

// driver.Conn interface
func (connection *connection) Begin() (driver.Tx, error) {
	autoCommRes := connection.apiConnection.SetAutoCommit(false)

	if !autoCommRes {
		return nil, connection.getError()
	}

	return &transaction{connection}, nil
}

// driver.ConnBeginTx interfaces
func (connection *connection) BeginTx(ctx context.Context, opts driver.TxOptions) (driver.Tx, error) {
	if opts.ReadOnly {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			"Setting of read only option is currently unsupported"))
	}

	isolationLevel := sql.IsolationLevel(opts.Isolation)
	if isolationLevel == sql.LevelDefault {
		return connection.Begin()
	}
	cLibIsolationLevel := 0

	switch isolationLevel {
	case sql.LevelSerializable:
		cLibIsolationLevel = 3
	case sql.LevelRepeatableRead:
		cLibIsolationLevel = 2
	case sql.LevelReadCommitted:
		cLibIsolationLevel = 1
	case sql.LevelReadUncommitted:
        fallthrough
	case sql.LevelDefault:
		cLibIsolationLevel = 0
	default:
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			fmt.Sprintf("Unsupported isolation level requested: %s ", isolationLevel.String())))
	}

	isolationLevelResult := connection.apiConnection.SetTransactionIsolation(cLibIsolationLevel)

	if !isolationLevelResult {
		return nil, connection.getError()
	}

	return connection.Begin()
}

// driver.Execer interface
func (connection *connection) Exec(query string, args []driver.Value) (driver.Result, error) {
	return connection.execInternal(context.Background(), query, args)
}

// driver.ExecerContext interface
func (connection *connection) ExecContext(ctx context.Context, query string, nvargs []driver.NamedValue) (driver.Result, error) {
	value := make([]driver.Value, len(nvargs))

	for i := 0; i < len(nvargs); i++ {
		value[i] = nvargs[i].Value
	}

	return connection.execInternal(ctx, query, value)
}

func (connection *connection) execInternal(ctx context.Context, query string, args []driver.Value) (driver.Result, error) {
	connection.resetErrors()
	if args != nil && len(args) != 0 {
		return nil, driver.ErrSkip
	}

	stmt, err := connection.execute(ctx, query)

	if err != nil {
		return nil, err
	}

	defer stmt.Free()
	funcCode := stmt.GetFunctionCode()

	if funcCode == api.FunctionCode_DDL {
		return driver.ResultNoRows, nil
	}

	rowsAffected := stmt.RowsAffected()

	if rowsAffected == -1 {
		err :=  connection.getError()
		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				connection.addError(hanaError)
				return &result{rowsAffected: -1, err: connection.errors()}, connection.errors()
			}
			// Error required for upper layer - return directly
			return &result{rowsAffected: -1, err: err}, err
		}
		return &result{rowsAffected: -1, err: nil}, connection.errors()
	} else {
		return &result{rowsAffected: int64(rowsAffected), err: connection.errors()},
			connection.errors()
	}
}

// driver.Queryer interface
func (connection *connection) Query(query string, args []driver.Value) (driver.Rows, error) {
	return connection.queryInternal(context.Background(), query, args)
}

// driver.QueryerContext interface
func (connection *connection) QueryContext(ctx context.Context, query string, nvargs []driver.NamedValue) (driver.Rows, error) {
	value := make([]driver.Value, len(nvargs))

	for i := 0; i < len(nvargs); i++ {
		value[i] = nvargs[i].Value
	}

	return connection.queryInternal(ctx, query, value)
}

func (connection *connection) queryInternal(ctx context.Context, query string, args []driver.Value) (driver.Rows, error) {
	connection.resetErrors()
	if args != nil && len(args) != 0 {
		return nil, driver.ErrSkip
	}

	stmt, err := connection.execute(ctx, query)

	if err != nil {
		return nil, err
	}

	return &rows{stmt: stmt, conn: connection, isFromStatement: false,
		isClosed: false, err: connection.errors()}, connection.errors()
}

func (connection *connection) execute(ctx context.Context, query string) (api.Statement, error) {
	var stmt api.Statement
	var valid bool
	communicationTimeout, ok := getStmtCommunicationTimeoutFromContext(ctx)

	if ok {
		stmt, valid = connection.apiConnection.ExecuteDirectWithTimeout(query, communicationTimeout)
	} else {
		stmt, valid = connection.apiConnection.ExecuteDirect(query)
	}

	if !valid {
		err :=  connection.getError()
		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				connection.addError(hanaError)
				return nil, connection.errors()
			}

			// Error required for upper layer - return directly
			return nil, err
		}

		return nil, connection.errors()
	}

	return stmt, nil
}

// TODO: This can directly be changed to IsValid() to satisfy the driver.Validator interface
func (connection *connection) isBadConnection() bool {
	errCode, _ := connection.apiConnection.Error()
	//-10806: connection lost and transaction rolled back and -10807: connection lost and -10108: reconnect error and -10821 session not connected
	return errCode == -10806 || errCode == -10807 || errCode == -10108 || errCode == -10821
}

func (connection *connection) setPropertiesAndConnect() error {
	err := connection.setDefaultConnectProperties()
	if err != nil {
		return err
	}

	err = connection.setAdditionalConnectProperties()
	if err != nil {
		return err
	}

	connRes := connection.apiConnection.Connect()

	if !connRes {
		return connection.getError()
	}
	return nil
}

func (connection *connection) setDefaultConnectProperties() error {
	if !connection.apiConnection.SetConnectProperty("SERVERNODE", connection.dsnInfo.Host) {
		return connection.getError()
	}
	if !connection.apiConnection.SetConnectProperty("UID", connection.dsnInfo.Username) {
		return connection.getError()
	}
	if !connection.apiConnection.SetConnectProperty("PWD", connection.dsnInfo.Password) {
		return connection.getError()
	}
	if !connection.apiConnection.SetConnectProperty("CHARSET", "UTF-8") {
		return connection.getError()
	}
	return nil
}

func (connection *connection) setAdditionalConnectProperties() error {
	connProps := connection.dsnInfo.ConnectProps
	for key := range connProps {
		values := connProps[key]
		if !connection.apiConnection.SetConnectProperty(key, values[0]) {
			return connection.getError()
		}
	}
	return nil
}

func (connection *connection) getError() error {
	var (
		theError *HdbError
	)

	hasErrors := true

	for recNumber := 1; hasErrors; recNumber++ {
		diagRecord := connection.apiConnection.GetDiagnosticRecord(recNumber)

		if (diagRecord != nil) && (len(diagRecord.ErrorText()) > 0) {
			if !connection.dsnInfo.ReportWarningsWithErrors() &&
				(diagRecord.Severity() == api.ErrorLevel_Warning) {
				continue
			}

			if theError == nil {
				theError = newError(newDriverError(diagRecord.ErrorCode(),  diagRecord.ErrorText(),
							diagRecord.Severity(), diagRecord.SQLState()))
			} else {
				theError.add(newDriverError(diagRecord.ErrorCode(),  diagRecord.ErrorText(),
							diagRecord.Severity(), diagRecord.SQLState()))
			}
		} else {
			hasErrors = false
		}
	}
	if theError != nil {
		// One connection related error = return driver.ErrBadConn for sql package upstream handling
		// -10806: connection lost and transaction rolled back
		// -10807: connection lost
		// -10108: reconnect error and -10821 session not connected
		if theError.NumberOfErrors() == uint(1) {
			if theError.ErrorCode() == -10806 || theError.ErrorCode() == -10807 ||
				theError.ErrorCode() == -10108 || theError.ErrorCode() == -10821 {
				return driver.ErrBadConn
			}
		}
		return theError
	}

	return nil
}

// Helper functions for ErrorHolder type interface
func (connection *connection) resetErrors() {
	connection.theErrors = nil
}

func (connection *connection) errors() error {
	if connection.theErrors != nil && connection.theErrors.NumberOfErrors() > 0 {
		return connection.theErrors
	}

	return nil
}

// NOTE: 1) This needs to be exported (capitalized for use by the internal api connection.go)
func (connection *connection) addError(theError Error) {
	if connection.theErrors == nil {
		connection.theErrors = newError(theError)
	} else {
		connection.theErrors.add(theError)
	}
}
//^^ErrorHolder type interface

// api.WarningHolder type interface
func (connection *connection) AddWarning(warningCode int, warningMessage string,
	sqlState string) {
	newWarning := newDriverError(warningCode, warningMessage, ErrorLevel_Warning,
		sqlState)
	connection.addError(newWarning)
}
//^^ api.WarningHolder type interface

// Transaction
type transaction struct {
	connection *connection
}

// driver.Tx interface
func (transaction *transaction) Commit() error {
	commitRes := transaction.connection.apiConnection.Commit()

	if !commitRes {
		return transaction.connection.getError()
	}

	autoCommRes := transaction.connection.apiConnection.SetAutoCommit(true)

	if !autoCommRes {
		return transaction.connection.getError()
	}

	res := transaction.connection.apiConnection.SetTransactionIsolation(DEFAULT_ISOLATION_LEVEL)

	if !res {
		return transaction.connection.getError()
	}

	return nil
}

// driver.Tx interface
func (transaction *transaction) Rollback() error {
	rollbackRes := transaction.connection.apiConnection.Rollback()

	if !rollbackRes {
		return transaction.connection.getError()
	}

	autoCommRes := transaction.connection.apiConnection.SetAutoCommit(true)

	if !autoCommRes {
		return transaction.connection.getError()
	}

	res := transaction.connection.apiConnection.SetTransactionIsolation(DEFAULT_ISOLATION_LEVEL)

	if !res {
		return transaction.connection.getError()
	}

	return nil
}

// Vendor specific extensions
const (
	pingDetailedError = driverKey("pingDetailedError")
)

func NewPingDetailedErrorContext(ctx context.Context) (context.Context) {
	return context.WithValue(ctx, pingDetailedError, true)
}

func getPingDetailedErrorFromContext(ctx context.Context) bool {
	pingDetailedError, ok := ctx.Value(pingDetailedError).(bool)

	if !ok {
		pingDetailedError = false
	}

	return pingDetailedError
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ api.WarningHolder = (*connection)(nil)
)
