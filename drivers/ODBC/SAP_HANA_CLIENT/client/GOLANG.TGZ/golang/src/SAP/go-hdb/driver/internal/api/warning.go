package api

/*
#cgo CFLAGS: -I${SRCDIR}/includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"

typedef void (*warning_callback_t)(dbcapi_stmt *,
								const char *,
								dbcapi_i32,
								const char *,
								void *);

*/
import "C"
import (
    "runtime/cgo"
    "unsafe"
)

type WarningHolder interface {
	AddWarning(warningCode int, warningMessage string,
		sqlState string) // Addeds new error to the error collection
}

//export warningCallback
func warningCallback(warning_message *C.char,
	warning_code C.dbcapi_i32, sql_state *C.char, user_data unsafe.Pointer) {
	// NOTE: This may need to be wrapped by a function
	h := *(*cgo.Handle)(user_data)
	warningHolder := h.Value().(WarningHolder)
	warningHolder.AddWarning(int(warning_code),
			C.GoString(warning_message),
			C.GoStringN(sql_state, C.DBCAPI_SQLSTATE_SIZE - 1))
	//^^
}
