package driver

import (
	"bytes"
	"io"
	"unsafe"
	driver "database/sql/driver"
)

// WriteLOB
type WriteLOB struct {
	reader io.ReadCloser
	paramIndex uint
	paramIndexSet bool
}

func NewWriteLOB(r io.ReadCloser) *WriteLOB {
	return &WriteLOB{reader: r}
}

func (writeLOB *WriteLOB) SetReader(reader io.ReadCloser) error {
	// Note: SQLDBC doesn't seem to have control over the LOB chunk size on insert - it seems to be controlled
	// by the packet size
	// If a reader has already been set and is not closed, then this should be an error
	if writeLOB.reader == nil {
		return newError(newGoDriverError(DRIVER_ERROR_LOB_READER_STILL_IN_USE))
	}

	writeLOB.reader = reader
	return nil
}


func (writeLOB *WriteLOB) setParameterIndex(paramIndex uint) {
	writeLOB.paramIndex = paramIndex
	writeLOB.paramIndexSet = true
}

func (writeLOB *WriteLOB) sendInputParameterData(stmt *statement) error {
	if !writeLOB.paramIndexSet {
		return newError(newGoDriverError(DRIVER_ERROR_LOB_READER_NO_PARAM_INDEX))
	}
	bufferChunk := make([]byte, stmt.conn.dsnInfo.LobChunkSize())

	var (
		err            error
		readBytes      int
		totalSentBytes int
	)

	for err == nil {
		readBytes, err = writeLOB.reader.Read(bufferChunk)

		if readBytes > 0 {
			if(!stmt.apiStatement.SendParamData(writeLOB.paramIndex, unsafe.Pointer(&bufferChunk[0]), readBytes)) {
				err = stmt.conn.getError()
			} else {
				totalSentBytes += readBytes
			}
			// Do send
		} else {
			break
		}
	}

	defer writeLOB.close()

	if (err != nil) && (err != io.EOF) {
		return err
	}

	if totalSentBytes == 0 {
		// The binding of a reader to the WriteLOB (done in its constructor)
		// guarantees that data is to be provided. Sometimes the data has length
		// zero - in that case the previous loop would do nothing, but
		// something still needs to be sent
		// This will be added when chunking support is added to SQLA sacapi
		if(!stmt.apiStatement.SendParamData(writeLOB.paramIndex, nil, 0)) {
			err = stmt.conn.getError()
		}
	}
	// Just in case the error value condition isn't met yet (and no fatal error occured),
	// check again to confirm end of data condition
	if err == nil || err == io.EOF {
		readBytes, err = writeLOB.reader.Read(bufferChunk)
	}

	if readBytes != 0 || err != io.EOF {
		return err
	}

	err = nil // no actual error, the reader has been exhausted and sending is done

	if(!stmt.apiStatement.FinishParamData(int(writeLOB.paramIndex))) {
		err = stmt.conn.getError()
	}

	return err
}

func (writeLOB *WriteLOB) close() {
	if writeLOB.reader != nil {
		writeLOB.reader.Close()
		writeLOB.reader = nil
		writeLOB.paramIndexSet = false
	}
}
//^^WriteLOB

// ReadLOB
type ReadLOB struct {
	writer io.WriteCloser
	writerSet bool
	offset uint64
	// Scanner interface
	Valid bool
	Bytes []byte
	err error
}

func NewReadLOB(w io.WriteCloser) *ReadLOB {
	return &ReadLOB{writer: w, writerSet: true}
}

// Scanner interface
func (readLOB *ReadLOB) Scan(value interface{}) error {
	theValue, valid := value.(*readLobValue)
	var err error

	if valid {
		isNull, err := theValue.isNull()

		if err != nil {
			readLOB.closeWriter(err)
			return err
		}

		if isNull {
			err = newError(newGoDriverError(DRIVER_ERROR_LOB_READER_STILL_IN_USE))
			readLOB.closeWriter(err)
			return err
		}

		readLOB.err = readLOB.sendLOBOutputDataToWriter(theValue.rows,
			theValue.columnIndex)

		return readLOB.err
	}

	err = newError(newGoDriverError(DRIVER_ERROR_LOB_READER_LOB_READER_NOT_LOB_DATA))
	readLOB.closeWriter(err)
	return err
}

// Need to re-evaluate - The open-source go driver returns the reader
func (readLOB *ReadLOB) Value() (driver.Value, error) {
	// NOTE: This really should not be called directly. It is expected that the user will use the
	// io.Reader to access the data in chunks
	if readLOB.err != nil {
		return nil, readLOB.err
	}

	return readLOB.writer, nil
}

// TODO: LOB Chunk size too great check?
// This will be called from rows.Scan() - the application is expected to call Scan() in a goroutine
func (readLOB *ReadLOB) sendLOBOutputDataToWriter(row *rows, colIndex uint) error {
	var (
		err       error
		bufferSize = row.conn.dsnInfo.LobChunkSize()
		readBytesCount int
	)


	readLOB.offset = 0 // In case the LOB is being reused
	bufferChunk := bytes.NewBuffer(make([]byte, bufferSize))

	for err == nil {
		readBytesCount = row.stmt.GetData((uint)(colIndex), (uintptr)(readLOB.offset),
			unsafe.Pointer(&bufferChunk.Bytes()[0]), (uintptr)(bufferChunk.Len()))

		if readBytesCount == -1 { // error
			err = row.conn.getError()
		} else if readBytesCount > 0 {
			readLOB.offset = readLOB.offset + uint64(readBytesCount)

			// bytes.WriteTo uses the size of its internal buffer to determine how much to
			// write, but the buffer may have less valid bytes retrieved than its size.
			// Because of this, we resize the buffer here. This should only happens on the last
			// chunk fetch
			if readBytesCount < int(bufferSize) {
				bufferChunk.Truncate(int(readBytesCount))
			}

			_, err = readLOB.writer.Write(bufferChunk.Bytes())
		} else {
			break
		}
	}

	readLOB.closeWriter(err)
	return err
}

func (readLOB *ReadLOB) closeWriter(closeWithError error) {
	if pw, ok := readLOB.writer.(*io.PipeWriter); ok {
		if closeWithError != nil {
			pw.CloseWithError(closeWithError)
		} else {
			pw.Close()
		}
	} else {
		readLOB.writer.Close()
	}
	readLOB.writerSet = false
}
//^^ReadLOB

// NullReadLOB
type NullReadLOB struct {
	ReadLOB ReadLOB
	// Null types convention
	Valid bool
}

func NewNullReadLOB(w io.WriteCloser) *NullReadLOB {
	return &NullReadLOB{ReadLOB: ReadLOB{writer: w, writerSet: true}}
}

// Scanner Interface
func (readLOB *NullReadLOB) Scan(value interface{}) error {
	theValue, valid := value.(*readLobValue)
	var err error

	if valid {
		isNull, err := theValue.isNull()

		if err != nil {
			readLOB.Valid = false
			readLOB.ReadLOB.closeWriter(err)
			return err
		}

		if isNull {
			readLOB.Valid = false
			readLOB.ReadLOB.closeWriter(nil)
			return nil
		}

		err = readLOB.ReadLOB.sendLOBOutputDataToWriter(theValue.rows,
			theValue.columnIndex)

		readLOB.ReadLOB.err = err

		if err != nil {
			readLOB.Valid = false
		} else {
			readLOB.Valid = true
		}

		return err
	}

	err = newError(newGoDriverError(DRIVER_ERROR_LOB_READER_LOB_READER_NOT_LOB_DATA))
	readLOB.Valid = false
	readLOB.ReadLOB.closeWriter(err)
	return err
}

// Valuer Interface
func (readLOB *NullReadLOB) Value() (driver.Value, error) {
	// NOTE: This really should not be called directly. It is expected that the user will use the
	// io.Reader to access the data in chunks
	if readLOB.ReadLOB.err != nil {
		return nil, readLOB.ReadLOB.err
	}

	return readLOB.ReadLOB.writer, nil
}
//^^NullReadLOB
