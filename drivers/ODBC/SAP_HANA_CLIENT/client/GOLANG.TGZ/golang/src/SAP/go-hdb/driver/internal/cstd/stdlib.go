package cstd

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"
)

type allocator interface {
	Calloc(dataSize Size_t, elementCount Size_t) unsafe.Pointer
	Malloc(dataSize Size_t) unsafe.Pointer
	Free(memoryData unsafe.Pointer)
}

var memoryAllocator = allocator(newDefaultAllocator())

func Malloc(dataSize Size_t) unsafe.Pointer {
	return memoryAllocator.Malloc(dataSize)
}

func Calloc(dataSize Size_t, elementCount Size_t) unsafe.Pointer {
	return memoryAllocator.Calloc(dataSize, elementCount)
}

func Free(memoryData unsafe.Pointer) {
	memoryAllocator.Free(memoryData)
}
