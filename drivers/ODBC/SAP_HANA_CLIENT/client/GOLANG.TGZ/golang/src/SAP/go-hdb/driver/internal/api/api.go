package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

const cDriverName = "hdbGolangDriver"
type CApiConnection = C.dbcapi_connection
type CApiStmt = C.dbcapi_stmt
type CApiBool = C.dbcapi_bool
type CApiNativeType = C.dbcapi_native_type
type CApiDataType = C.dbcapi_data_type
type CApiBindData = C.dbcapi_bind_data
type CApiParamInfo = C.dbcapi_bind_param_info
type CApiColumnInfo = C.struct_dbcapi_column_info
type CApiDataValue = C.struct_dbcapi_data_value
type CApiDataInfo = C.struct_dbcapi_data_info

func Init() bool {
	cName := (*C.char)(cstd.CString(cDriverName))
	defer cstd.Free(unsafe.Pointer(cName))
	api := C.dbcapi_init2(cName, C.DBCAPI_API_VERSION_1, nil, C.CT_GO)
	return api == 1
}

func ClientVersion() (string, bool) {
	buffer := (*C.char)(cstd.Malloc(cstd.Size_t(256)))
	defer cstd.Free(unsafe.Pointer(buffer))
	ok := C.dbcapi_client_version(buffer, 256)
	return cstd.GoString((*cstd.Char)(buffer)), (ok == 1)
}

func GetSuggestedUnconstrainedRealVectorDimension() int {
	// NOTE: This expects that Init() was called properly
	return int(C.dbcapi_get_suggested_unconstrained_real_vector_dimension())
}

func GetSuggestedUnconstrainedHalfVectorDimension() int {
	// NOTE: This expects that Init() was called properly
	return int(C.dbcapi_get_suggested_unconstrained_half_vector_dimension())
}
