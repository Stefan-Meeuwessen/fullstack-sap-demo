package cstd

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
*/
import "C"

// Boolean type
type Bool = C.bool

// Char type
type Char = C.char

// Integer Types
type Int = C.int
type Int8 = C.int8_t
type UInt8 = C.uint8_t
type Int64 = C.int64_t
type UInt64 = C.uint64_t
type Size_t = C.size_t

// Floating-point Types
type Float = C.float
type Double = C.double

// Required sizes
const SizeofChar = Size_t(C.sizeof_char)
const SizeofBool = Size_t(C.sizeof_bool)
const SizeofInt = Size_t(C.sizeof_int)
const SizeofInt8 = Size_t(C.sizeof_int8_t)
const SizeofUInt8 = Size_t(C.sizeof_uint8_t)
const SizeofInt64 = Size_t(C.sizeof_int64_t)
const SizeofUInt64 = Size_t(C.sizeof_uint64_t)
const SizeofFloat = Size_t(C.sizeof_float)
const SizeofDouble = Size_t(C.sizeof_double)
const SizeofSize_t = Size_t(C.sizeof_size_t)
