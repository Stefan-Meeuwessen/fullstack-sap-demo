package driver

import (
	"math"
)

const DEFAULT_ISOLATION_LEVEL = 1

const (
	EXPECTED_DBCAPI_VERSION = "libdbcapiHDB 2.27.024.1772569942"
	DEFAULT_PACKETSIZE      = math.MaxInt32
	DriverName              = "hdb"                                             // DriverName is the driver name to use with sql.Open for hdb databases.
	MIN_PACKETSIZE          = 1*64*1024
	MAX_BINARY_SIZE         = 5000                                              // Max length of varbinary column
	MAX_PACKETSIZE          = math.MaxInt32
)
