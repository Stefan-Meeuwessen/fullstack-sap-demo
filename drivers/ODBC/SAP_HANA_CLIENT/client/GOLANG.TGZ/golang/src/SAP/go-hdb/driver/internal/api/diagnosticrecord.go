package api

type DiagnosticRecord interface {
	ErrorCode() int
	ErrorText() string
	SQLState() string
	Severity() SeverityLevel
}

type APIDiagnosticRecord struct {
	errorCode int
	errorText string
	sqlState string
	severity SeverityLevel
    rowNumber int
}

func newDiagnosticRecord(errorCode int, errorText string, sqlState string,
    severity SeverityLevel) DiagnosticRecord {
	return &APIDiagnosticRecord{errorCode: errorCode, errorText: errorText, sqlState: sqlState, severity: severity}
}

func newDiagnosticRecordWithRowNumber(errorCode int, errorText string, sqlState string,
    severity SeverityLevel, rowNumber int) DiagnosticRecord {
	return &APIDiagnosticRecord{errorCode: errorCode, errorText: errorText, sqlState: sqlState, severity: severity, rowNumber: rowNumber}
}

func (diagRecord *APIDiagnosticRecord) ErrorCode() int {
	return diagRecord.errorCode
}

func (diagRecord *APIDiagnosticRecord) ErrorText() string {
	return diagRecord.errorText
}

func (diagRecord *APIDiagnosticRecord) SQLState() string {
	return diagRecord.sqlState
}

func (diagRecord *APIDiagnosticRecord) Severity() SeverityLevel {
	return diagRecord.severity
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ DiagnosticRecord             = (*APIDiagnosticRecord)(nil)
)
