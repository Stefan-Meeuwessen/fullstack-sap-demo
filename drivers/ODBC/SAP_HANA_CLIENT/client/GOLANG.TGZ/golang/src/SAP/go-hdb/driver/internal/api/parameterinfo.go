package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
    "unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)


// This is the interface that will be used to free the bound parameter information
// This is (normaly) used to get parameter information
// - Data Direction (IN/OUT/INOUT)
// - Precision
// - Scale
// - Max Size
type ParameterInfo interface {
	Free()
    ParamName() string
    DataDirection() ParamDataDirection
    NativeType() NativeType
    Precision() uint16
    Scale() uint16
    MaxSize() uintptr
// TODO: Not sure if these are needed. The aren't accessed currently by the driver
    // InputValue() *DataValue
    // OutputValue() *DataValue
// ^^
}

type APIParameterInfo struct {
    apiParamInfo *CApiParamInfo
}

func newAPIParameterInfo(apiParamInfo *CApiParamInfo) *APIParameterInfo {
    return &APIParameterInfo{apiParamInfo: apiParamInfo}
}

func (bpi *APIParameterInfo) Free() {
    // 1) Free input_value entry (dbcapi_data_value)
    // - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
    // This shouldn't really be used becasue it isn't sending/fetching any value data
    // it is only getting information for the type (dbcapi_data_type), but just in case
    // 2) Free output_value entry (dbcapi_data_value)
    // - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
    // This shouldn't really be used becasue it isn't sending/fetching any value data
    // it is only getting information for the type (dbcapi_data_type), but just in case
    // This is an internal type, it should be known that use after calling cstd.Free() is an erro
    // and can cause a panic
    if bpi.apiParamInfo != nil {
        // None of these are handled by the driver - their allocation/deallocation are handled by the C layer
        // if bpi.apiParamInfo.input_value.buffer != nil {
        //     cstd.Free(unsafe.Pointer(bpi.apiParamInfo.input_value.buffer))
        //     bpi.apiParamInfo.input_value.buffer = nil
        // }
        // if bpi.apiParamInfo.input_value.length != nil {
        //     cstd.Free(unsafe.Pointer(bpi.apiParamInfo.input_value.length))
        //     bpi.apiParamInfo.input_value.length = nil
        // }
        // if bpi.apiParamInfo.input_value.is_null != nil {
        //     cstd.Free(unsafe.Pointer(bpi.apiParamInfo.input_value.is_null))
        //     bpi.apiParamInfo.input_value.is_null = nil
        // }
        cstd.Free(unsafe.Pointer(bpi.apiParamInfo))
        bpi.apiParamInfo = nil
    }
}
func (bpi *APIParameterInfo) ParamName() string {
	return cstd.GoString((*cstd.Char)(bpi.apiParamInfo.name))
}

func (bpi *APIParameterInfo) DataDirection() ParamDataDirection {
	return (ParamDataDirection)(bpi.apiParamInfo.direction)
}

func (bpi *APIParameterInfo) NativeType() NativeType {
	return (NativeType)(bpi.apiParamInfo.native_type)
}

func (bpi *APIParameterInfo) Precision() uint16 {
	return uint16(bpi.apiParamInfo.precision)
}

func (bpi *APIParameterInfo) Scale() uint16 {
    return uint16(bpi.apiParamInfo.scale)
}
func (bpi *APIParameterInfo) MaxSize() uintptr {
    return uintptr(bpi.apiParamInfo.max_size)
}

// // TODO: Not sure if these are needed. The aren't accessed currently by the driver
// func (bpi *APIParameterInfo) InputValue() *DataValue { return nil }
// func (bpi *APIParameterInfo) OutputValue() *DataValue { return nil }
// //^^
// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ ParameterInfo             = (*APIParameterInfo)(nil)
)
