package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"

type DataType = int

// See dbcapi_data_type in DBCAPI.h
const (
    _ DataType = iota
    /// Invalid data type.
    A_INVALID_TYPE = C.A_INVALID_TYPE
    /// Binary data.  Binary data is treated as-is and no character set conversion is performed.
    A_BINARY = C.A_BINARY
    /// String data.  The data where character set conversion is performed.
    /// Sometimes null terminated, sometimes not
    A_STRING = C.A_STRING
    /// Double data.  Includes float values.
    A_DOUBLE = C.A_DOUBLE
    /// 64-bit integer.
    A_VAL64 = C.A_VAL64
    /// 64-bit unsigned integer.
    A_UVAL64 = C.A_UVAL64
    /// 32-bit integer.
    A_VAL32 = C.A_VAL32
    /// 32-bit unsigned integer.
    A_UVAL32 = C.A_UVAL32
    /// 16-bit integer.
    A_VAL16 = C.A_VAL16
    /// 16-bit unsigned integer.
    A_UVAL16 = C.A_UVAL16
    /// 8-bit integer.
    A_VAL8 = C.A_VAL8
    /// 8-bit unsigned integer.
    A_UVAL8 = C.A_UVAL8
    //// Float precision data.
    A_FLOAT = C.A_FLOAT
)
