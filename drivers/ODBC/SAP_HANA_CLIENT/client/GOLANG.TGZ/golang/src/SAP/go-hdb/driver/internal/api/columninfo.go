package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)


// This is the interface that will be used the bound column information for a ResultSet
// This is (normaly) used to get parameter information
// - Precision
// - Scale
// - Max Size
type ColumnInfo interface {
	Free()
	Name() string
	ColumnName() string // Only can be used if the owning ResultSet isn't freed
	TableName() string // Only can be used if the owning ResultSet isn't freed
	OwnerName() string // Only can be used if the owning ResultSet isn't freed
	DataType() DataType
	NativeType() NativeType
	Precision() uint16
	Scale() uint16
	MaxSize() uintptr
	Nullable() bool
	IsBound() bool
}

type APIColumnInfo struct {
	apiColumnInfo *CApiColumnInfo
}

func newAPIColumnInfo(apiColumnInfo *CApiColumnInfo) *APIColumnInfo {
	return &APIColumnInfo{apiColumnInfo: apiColumnInfo}
}

func (columnInfo *APIColumnInfo) Free() {
	if columnInfo.apiColumnInfo != nil {
		cstd.Free(unsafe.Pointer(columnInfo.apiColumnInfo))
		columnInfo.apiColumnInfo = nil
	}
}

func (columnInfo *APIColumnInfo) Name() string {
	return cstd.GoString((*cstd.Char)(columnInfo.apiColumnInfo.name))
}

func (columnInfo *APIColumnInfo) ColumnName() string {
	return cstd.GoString((*cstd.Char)(columnInfo.apiColumnInfo.column_name))
}

func (columnInfo *APIColumnInfo) TableName() string {
	panic("Not implemented")
}

func (columnInfo *APIColumnInfo) OwnerName() string {
	return cstd.GoString((*cstd.Char)(columnInfo.apiColumnInfo.owner_name))
}

func (columnInfo *APIColumnInfo) DataType() DataType {
	return (DataType)(columnInfo.apiColumnInfo._type)
}

func (columnInfo *APIColumnInfo) NativeType() NativeType {
	return (NativeType)(columnInfo.apiColumnInfo.native_type)
}

func (columnInfo *APIColumnInfo) Precision() uint16 {
	return uint16(columnInfo.apiColumnInfo.precision)
}

func (columnInfo *APIColumnInfo) Scale() uint16 {
	return uint16(columnInfo.apiColumnInfo.scale)
}

func (columnInfo *APIColumnInfo) MaxSize() uintptr {
	return uintptr(columnInfo.apiColumnInfo.max_size)
}

func (columnInfo *APIColumnInfo) Nullable() bool {
	return columnInfo.apiColumnInfo.nullable == CApiBool(1)
}

func (columnInfo *APIColumnInfo) IsBound() bool {
	return columnInfo.apiColumnInfo.is_bound == CApiBool(1)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ ColumnInfo             = (*APIColumnInfo)(nil)
)
