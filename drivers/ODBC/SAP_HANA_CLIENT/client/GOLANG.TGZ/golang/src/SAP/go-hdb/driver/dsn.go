package driver

import (
	"fmt"
	"net/url"
	"strings"
	"strconv"
)

//Connect to HANA
//-dsn "hdb://myuser:mypassword@localhost:30015?DISTRIBUTION=all&RECONNECT=false

type DsnInfo struct {
	Host, Username, Password string
	// SQLDBC/dbcapi Connection Properties
	ConnectProps             url.Values
	// Golang-specific Connection Properties
	convertTimestampToUTC    bool
	lobChunkSize             int
	reportWarningsWithErrors bool
	//^^Golang-specific Connection Properties
}

func NewDsnInfo() *DsnInfo {
	dsnInfo := DsnInfo{}
	dsnInfo.setGolangPropertiesDefaults()
	return &dsnInfo
}


// Golang specific connection properties
func (dsnInfo *DsnInfo) setGolangPropertiesDefaults() {
	//This will be overriden by the url parsing logic for each custom
	// Golang-specific connect Property specified
    dsnInfo.convertTimestampToUTC = true
	dsnInfo.lobChunkSize = 1024*1024
}

func (dsnInfo* DsnInfo) processDSN(dsn string) (*url.URL, error) {
	url, err := url.Parse(dsn)

	if err != nil {
		return nil, err
	}

	if url.User != nil {
		dsnInfo.Username = url.User.Username()
		dsnInfo.Password, _ = url.User.Password()
	}

	return url, nil
}

func (dsnInfo* DsnInfo) processGolangConnectProperties(url *url.URL) error {
	golangConnectProperties := make([]string, 0)
	var err error

	for queryKey, queryValue := range url.Query() {
		golangConnectProperty := queryKey
		if stringEqualsIgnoreCase(queryKey, "utcTimeConversion") {
			dsnInfo.processUTCTimestampConversion(queryValue[0])
			golangConnectProperties = append(golangConnectProperties, golangConnectProperty)
		} else if stringEqualsIgnoreCase(queryKey, "lobChunkSize") {
			err = dsnInfo.processLobChunkSize(queryValue[0])
			golangConnectProperties = append(golangConnectProperties, golangConnectProperty)
		} else if stringEqualsIgnoreCase(queryKey, "golangReportWarningsWithErrors") {
			dsnInfo.processGolangReportWarningsWithErrors(queryValue[0])
			golangConnectProperties = append(golangConnectProperties, golangConnectProperty)
		}

		if err != nil {
			return err
		}
	}
	query := url.Query()
	for _, golangConnectProperty := range golangConnectProperties {
		query.Del(golangConnectProperty)
	}
	url.RawQuery = query.Encode()
	dsnInfo.Host = url.Host
	dsnInfo.ConnectProps = url.Query()
	return nil
}

// Helper functions for Connect Properties
func (dsnInfo *DsnInfo) ConvertTimestampToUTC() bool {
	return dsnInfo.convertTimestampToUTC
}

func (dsnInfo *DsnInfo) LobChunkSize() int {
	return dsnInfo.lobChunkSize
}

func (dsnInfo *DsnInfo) ReportWarningsWithErrors() bool {
	return dsnInfo.reportWarningsWithErrors
}
//^^ Golang specific connection properties

func parseDSN(dsn string) (*DsnInfo, error) {
	dsnInfo := NewDsnInfo()
	url, err := dsnInfo.processDSN(dsn)

	if err != nil {
		return nil, err
	}

	err = dsnInfo.processGolangConnectProperties(url)
	return dsnInfo, err
}

func (dsnInfo *DsnInfo) processUTCTimestampConversion(queryValue string) {
	dsnInfo.convertTimestampToUTC = getBooleanPropertyValue(queryValue)
}

func (dsnInfo *DsnInfo) processLobChunkSize(queryValue string) error {
	propertyValue, err := strconv.ParseInt(queryValue, 10, 32)

	if err != nil {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_CONNECT_PROPERTY_S,
            fmt.Sprintf("Invalid lobChunkSize specified: %s", queryValue)))
	}


	minValue := 8192
	maxValue := 2147483647

	if (propertyValue < int64(minValue)) || (propertyValue > int64(maxValue)) {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_CONNECT_PROPERTY_S,
			fmt.Sprintf("Invalid lobChunkSize specified: %s, lobChunkSize must be >= %d and <= %d",
				queryValue, minValue, maxValue)))
	}

	dsnInfo.lobChunkSize = int(propertyValue)
	return nil
}

func (dsnInfo *DsnInfo) processGolangReportWarningsWithErrors(queryValue string) {
	dsnInfo.reportWarningsWithErrors = getBooleanPropertyValue(queryValue)
}

func stringEqualsIgnoreCase(string1, string2 string) bool {
	return strings.EqualFold(string1, string2)
}

func getBooleanPropertyValue(queryValue string) bool {
	if stringEqualsIgnoreCase(queryValue, "no") ||
		stringEqualsIgnoreCase(queryValue, "false") || stringEqualsIgnoreCase(queryValue, "0") ||
		stringEqualsIgnoreCase(queryValue, "off") {
		return false
	}

	return true
}
