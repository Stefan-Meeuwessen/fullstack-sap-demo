package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

// This is a wrapper for the struct we normally used to provide bound input
// parameter information to the API
// It is normally used in describ_param call to get information filled in by the API
// about the destination column, and then buffers are provided for the data
// and NULL information
type DataValue interface {
	Free()
	BufferSize() uintptr
	DataType() DataType
	InitializeBuffers(numberOfValues uintptr, theType DataType, dataTypeSize uintptr, isAddress bool)
	IsNull(index int) (bool, bool) // 0 based
	Value(index int) (unsafe.Pointer, bool) // 0 based
	Length(index int) (uintptr, bool) // 0 based
	BoundData() *CApiDataValue
}

type APIDataValue struct {
	apiDataValue *CApiDataValue
    freeDataBuffers bool
	dataTypeSize uintptr
	numberOfValues uintptr
}

func NewDataValue() *APIDataValue {
    apiDataValue := (*CApiDataValue)(cstd.Calloc(cstd.Size_t(C.sizeof_struct_dbcapi_data_value), 1))
	return &APIDataValue{apiDataValue: apiDataValue, freeDataBuffers: true}
}

func newDataValueInternal(apiDataValue *CApiDataValue,
	numberOfValues uintptr) *APIDataValue {
	return &APIDataValue{apiDataValue: apiDataValue, numberOfValues: numberOfValues, freeDataBuffers: false}
}

func (dataValue *APIDataValue) BoundData() *CApiDataValue {
    return dataValue.apiDataValue
}

func (dataValue *APIDataValue) Free() {
	// 1) Free input_value entry (dbcapi_data_value)
	// - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
	// This shouldn't really be used becasue it isn't sending/fetching any value data
	// it is only getting information for the type (dbcapi_data_type), but just in case
	// 2) Free output_value entry (dbcapi_data_value)
	// - Free buffer (char*), length (size_t*), is_null (dbcapi_bool*)
	// This shouldn't really be used becasue it isn't sending/fetching any value data
	// it is only getting information for the type (dbcapi_data_type), but just in case
	// This is an internal type, it should be known that use after calling cstd.Free() is an erro
	// and can cause a panic
	if dataValue.apiDataValue != nil {
		if dataValue.freeDataBuffers {
			if dataValue.apiDataValue.buffer != nil {
				if dataValue.apiDataValue.is_address == CApiBool(1) {
					for i := 0; i < int(dataValue.numberOfValues); i++ {
						var pointerSize uintptr
						_ = pointerSize
						bufferLocation := (**cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.buffer)) +
							uintptr(cstd.Size_t(unsafe.Sizeof(pointerSize))*cstd.Size_t(i))))
						if bufferLocation != nil {
							cstd.Free(unsafe.Pointer(*bufferLocation))
						}
					}
				}
				cstd.Free(unsafe.Pointer(dataValue.apiDataValue.buffer))
			}
			if dataValue.apiDataValue.length != nil {
				cstd.Free(unsafe.Pointer(dataValue.apiDataValue.length))
			}
			if dataValue.apiDataValue.is_null != nil {
				cstd.Free(unsafe.Pointer(dataValue.apiDataValue.is_null))
			}
		}
		cstd.Free(unsafe.Pointer(dataValue.apiDataValue))
		dataValue.apiDataValue = nil
		dataValue.numberOfValues = 0
	}
}

func (dataValue *APIDataValue) DataType() DataType {
	return (NativeType)(dataValue.apiDataValue._type)
}

func (dataValue *APIDataValue) InitializeBuffers(numberOfValues uintptr, theType DataType,
	dataTypeSize uintptr, isAddress bool) {
	dataValue.numberOfValues = numberOfValues
	dataValue.dataTypeSize = dataTypeSize
	dataValue.apiDataValue._type = CApiDataType(theType)
	dataValue.apiDataValue.buffer_size = (C.size_t)(dataTypeSize)

	if isAddress {
        var value uintptr
		dataValue.apiDataValue.is_address = CApiBool(1)
		dataValue.apiDataValue.buffer = (*C.char)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(unsafe.Sizeof(value))))
		dataValue.apiDataValue.length = (*C.size_t)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(cstd.SizeofSize_t)))
		dataValue.apiDataValue.is_null = (*CApiBool)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(unsafe.Sizeof(CApiBool(0)))))
		for i := 0; i < int(numberOfValues); i++ {
			lengthLocation := (*cstd.Size_t)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.length)) +
				uintptr(cstd.Size_t(unsafe.Sizeof(CApiBool(0)))*cstd.Size_t(i))))
			*lengthLocation = cstd.Size_t(dataTypeSize)
		}
	} else {
		dataValue.apiDataValue.is_address = CApiBool(0)
		dataValue.apiDataValue.buffer = (*C.char)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(dataTypeSize)))
		dataValue.apiDataValue.length = (*C.size_t)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(cstd.SizeofSize_t)))
		dataValue.apiDataValue.is_null = (*CApiBool)(cstd.Calloc(cstd.Size_t(numberOfValues),
			cstd.Size_t(unsafe.Sizeof(CApiBool(0)))))
	}
}

func (dataValue *APIDataValue) IsNull(index int) (bool, bool) {// 0 based
	if dataValue.apiDataValue == nil || dataValue.apiDataValue.is_null == nil || index < 0 ||
		index >= int(dataValue.numberOfValues) {
		return false, false
	}

    var isNull bool
	var nullValue CApiBool
	_ = nullValue
	nullLocation := (*CApiBool)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.is_null)) +
		uintptr(cstd.Size_t(unsafe.Sizeof(nullValue))*cstd.Size_t(index))))
	isNull = (*nullLocation == CApiBool(1))

	return isNull, true
}

func (dataValue *APIDataValue) Value(index int) (unsafe.Pointer, bool) { // 0 based
	if dataValue.apiDataValue == nil || dataValue.apiDataValue.buffer == nil || index < 0 ||
		index >= int(dataValue.numberOfValues) {
		return nil, false
	}

	if dataValue.apiDataValue.is_address == CApiBool(1) {
		var valueSize uintptr
		_ = valueSize
		bufferLocation := (**cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.buffer)) +
			unsafe.Sizeof(valueSize)*uintptr(index)))
		return unsafe.Pointer(*bufferLocation), true
	} else {
		bufferLocation := (*cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.buffer)) +
			uintptr(cstd.Size_t(dataValue.dataTypeSize)*cstd.Size_t(index))))
		return unsafe.Pointer(bufferLocation), true
	}
}

func (dataValue *APIDataValue) Length(index int) (uintptr, bool) {
	if dataValue.apiDataValue == nil || dataValue.apiDataValue.length == nil || index < 0 ||
		index >= int(dataValue.numberOfValues) {
		return 0, false
	}
	lengthLocation := (*cstd.Size_t)(unsafe.Pointer(uintptr(unsafe.Pointer(dataValue.apiDataValue.length)) +
		uintptr(cstd.SizeofSize_t*cstd.Size_t(index))))
	return uintptr(*lengthLocation), true
}

func (dataValue *APIDataValue) BufferSize() uintptr {
	return uintptr(dataValue.apiDataValue.buffer_size)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ DataValue             = (*APIDataValue)(nil)
)
