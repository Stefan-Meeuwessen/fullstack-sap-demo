package driver

import (
	"bytes"
	"fmt"
	"reflect"
	api "SAP/go-hdb/driver/internal/api"
)

// Enum representing the type of info the error is (Error or HdbWarning)
type HdbSeverityLevel = api.SeverityLevel

const (
	ErrorLevel_None = api.ErrorLevel_None
	ErrorLevel_Warning = api.ErrorLevel_Warning
	ErrorLevel_Error = api.ErrorLevel_Error
	ErrorLevel_Fatal = api.ErrorLevel_Fatal
)

type Error interface {
	Error() string // Standard Library Error Interface
	String() string // Standard Library Stringer Interface (included for compatibility)
	ErrorCode() int       // Code return the database error code.
	ErrorLevel() HdbSeverityLevel // Level return one of the database server predefined error levels.
	ErrorText() string    // Text return the error description sent from database server.
	SqlState() string    // Text return the error description sent from database server.
	IsWarning() bool // IsWarning returns true if the HDB error level equals 0.
	IsError() bool   // IsError returns true if the HDB error level equals 1.
	RowNumber() int // Number of the row that is responsible for the error (only valid for batch insert/update/delete of parameters 1 based, 0 for no row)
}

// Error collection
type ErrorCollection interface {
	NumberOfErrors() uint // Number of errors in the list (regardless of position)
	NextError() bool // Go to the next error (update the index internally) and return whether or not there is another error
	SetErrorPosition(index uint) error
	Reset() // Reset the index to the beginning
	RowNumber() int // Number of the row that is responsible for the error (only valid for batch insert/update/delete of parameters 1 based, 0 for no row)
}

// Internal representation of the error
type driverError struct {
	rowNumber int
	errorCode int
	errorText string
	sqlState string
	errorLevel HdbSeverityLevel // Determined from the const values
}

func newGoDriverError(driverErrorCode DriverErrorCode) *driverError {
	//  Here we assume that all driver-level errors will have Error Level = Error and SQL State = HY000
	driverErrorInfo, err := getDriverErrorInfo(driverErrorCode)

	if err != nil {
		// This should never happen in theory, but if a cast to DriverErrorCode from
		// int occurs successfully occurs with unknown data, this will be handled
		return &driverError{errorCode: 0, errorText: "",
			errorLevel: ErrorLevel_Error, sqlState: "HY000", rowNumber: 0}
	}
	return &driverError{errorCode: driverErrorInfo.errorCode, errorText: driverErrorInfo.errorText,
		errorLevel: ErrorLevel_Error, sqlState: "HY000", rowNumber: 0}
}

func newGoDriverErrorWithArgs(driverErrorCode DriverErrorCode,
	args ...interface{}) *driverError {
	//  Here we assume that all driver-level errors will have Error Level = Error and SQL State = HY000
	driverErrorInfo, err := getDriverErrorInfo(driverErrorCode)

	if err != nil {
		// This should never happen in theory, but if a cast to DriverErrorCode from
		// int occurs successfully occurs with unknown data, this will be handled
		return &driverError{errorCode: 0, errorText: "",
			errorLevel: ErrorLevel_Error, sqlState: "HY000", rowNumber: 0}
	}
	return &driverError{errorCode: driverErrorInfo.errorCode,
		errorText: fmt.Sprintf(driverErrorInfo.errorText, args...),
		errorLevel: ErrorLevel_Error, sqlState: "HY000", rowNumber: 0}
}

func newDriverError(errorCode int, errorText string,
	errorLevel HdbSeverityLevel, sqlState string) *driverError {
	return &driverError{errorCode: errorCode, errorText: errorText, errorLevel: errorLevel,
		sqlState: sqlState, rowNumber: 0}
}

func newDriverBatchError(errorCode int, errorText string,
	errorLevel HdbSeverityLevel, sqlState string, rowNumber int) *driverError {
	return &driverError{errorCode: errorCode, errorText: errorText, errorLevel: errorLevel,
		sqlState: sqlState, rowNumber: rowNumber}
}

// Maintained like this for compatibility reasons
func (e *driverError) Error() string {
	return fmt.Sprintf("%d: %s", e.errorCode, e.errorText)
}

func (e *driverError) String() string {
	switch(e.errorLevel) {
	case ErrorLevel_Warning:
		return fmt.Sprintf("Warning (%d: %s)", e.errorCode, e.errorText)
	case ErrorLevel_Fatal:
		return fmt.Sprintf("Fatal Error (%d: %s)", e.errorCode, e.errorText)
	case ErrorLevel_Error:
		fallthrough
	default:
		return fmt.Sprintf("Error (%d: %s)", e.errorCode, e.errorText)
	}
}

func (e *driverError) ErrorCode() int {
	return e.errorCode
}

func (e *driverError) ErrorLevel() HdbSeverityLevel {
	return e.errorLevel
}

func (e *driverError) ErrorText() string {
	return e.errorText
}

func (e *driverError) SqlState() string {
	return e.sqlState
}

func (e *driverError) IsWarning() bool {
	return e.errorLevel == ErrorLevel_Warning
}

func (e *driverError) IsError() bool {
	return e.errorLevel == ErrorLevel_Error
}

func (e *driverError) RowNumber() int {
	return e.rowNumber
}

type HdbError struct {
	errs []*driverError
	errorCount uint
	currentIndex uint
}

// func newError(e *driverError) *HdbError {
func newError(e error) *HdbError {
	errors := &HdbError{errs: make([]*driverError, 1), errorCount: 0, currentIndex: 0}
	v := reflect.ValueOf(e)
	theError, ok := v.Interface().(*HdbError)

	if ok { // Potentially a collection
		errors.errs[0] = theError.currentError()
		errors.errorCount++

		for theError.hasNext() {
			theError.NextError()
			errors.errs = append(errors.errs, theError.currentError())
			errors.errorCount++
		}
	} else {
		driverError, ok := v.Interface().(*driverError)

		if ok {
			errors.errs[0] = driverError
			errors.errorCount++
		}
	}

	return errors
}

func (e *HdbError) add(newError error) {
	v := reflect.ValueOf(newError)
	theError, ok := v.Interface().(*HdbError)

	if ok { // Potentially a collection
		e.errs = append(e.errs, theError.currentError())
		e.errorCount++

		for theError.hasNext() {
			theError.NextError()
			e.errs = append(e.errs, theError.currentError())
			e.errorCount++
		}
	} else {
		driverError, ok := v.Interface().(*driverError)

		if ok {
			e.errs = append(e.errs, driverError)
			e.errorCount++
		}
	}
}

func (e *HdbError) currentError() *driverError {
	if e.currentIndex >= e.errorCount {
		return nil
	}

	return e.errs[e.currentIndex]
}

func (e *HdbError) Error() string {
	err := e.currentError()

	if err == nil {
		return ""
	}

	return err.Error()
}

func (e *HdbError) String() string {
	// HdbError must have at least 1 error (guaranteed by construction)
	// This prints all of the error strings combined
	sb := new(bytes.Buffer)

	index := 0
	err := e.errs[index]
	index++
	sb.WriteString(fmt.Sprintf("%s", err.String()))

	for index = 1; uint(index) < e.errorCount; index++ {
		err = e.errs[index]
		sb.WriteString(fmt.Sprintf("\n%s", err.String()))
	}

	return sb.String()
}

func (e *HdbError) ErrorCode() int {
	err := e.currentError()

	if err == nil {
		return 0 // No error
	}
	return err.ErrorCode()
}

func (e *HdbError) ErrorLevel() HdbSeverityLevel {
	err := e.currentError()

	if err == nil {
		return ErrorLevel_None
	}

	return err.ErrorLevel()
}

func (e *HdbError) ErrorText() string {
	err := e.currentError()

	if err == nil {
		return ""
	}

	return err.ErrorText()
}

func (e *HdbError) SqlState() string {
	err := e.currentError()

	if err == nil {
		return ""
	}

	return err.SqlState()
}

func (e *HdbError) IsWarning() bool {
	err := e.currentError()

	if err == nil {
		return false
	}

	return err.IsWarning()
}

func (e *HdbError) IsError() bool {
	err := e.currentError()

	if err == nil {
		return false
	}

	return err.IsError()
}

// ErrorCollection interface
func (e *HdbError) hasNext() bool {
	return e.currentIndex + 1 < e.errorCount
}

func (e *HdbError) NumberOfErrors() uint {
	return e.errorCount
}

func (e *HdbError) NextError() bool {
	if e.currentIndex >= e.errorCount {
		return false
	}

	e.currentIndex++
	return e.currentIndex < e.errorCount
}

// 0-based
func (e *HdbError) SetErrorPosition(index uint) error {
	if index >= e.errorCount {
		return fmt.Errorf("Index out of range of the total number of errors: %d", int(index))
	}

	e.currentIndex = index
	return nil
}

func (e *HdbError) Reset() {
	e.currentIndex = 0
}

func (e *HdbError) RowNumber() int {
	err := e.currentError()

	if err == nil {
		return 0
	}

	return err.RowNumber()
}
// ^^Concrete error types

// NOTE: 1) This needs to be moved to the internal packaging
// 2) We need to force connection struct (in connection.go) to depend on this
// Error Holder Interface for different structs that hold references to HdbError objects
// NOTE: due to the way the cgo compilation process is handled, complete warning implementation
// cannot be provided in the same file (a duplicate symbols error would result).
// This will be implemented by all structs that can cause an error/warning through their
// API methods
type ErrorHolder interface {
	resetErrors() // Clears the stored error collection
	addError(newError Error) // Addeds new error to the error collection
	errors() error // Gets the error collection (or nil if no errors)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ error             = (*driverError)(nil)
	_ Error             = (*driverError)(nil)
	_ error             = (*HdbError)(nil)
	_ Error             = (*HdbError)(nil)
	_ ErrorCollection   = (*HdbError)(nil)
)
