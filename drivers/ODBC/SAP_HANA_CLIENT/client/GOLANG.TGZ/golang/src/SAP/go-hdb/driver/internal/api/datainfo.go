package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
    "unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)


// This is the interface that will be used to free the bound parameter information
// This is (normaly) used to get parameter information
// - Data Type
// - Is Null
// - Data Size
type DataInfo interface {
	Free()
    DataType() DataType
    IsNull() bool
    DataSize() uintptr
}

type APIDataInfo struct {
    apiColumnInfo *CApiDataInfo
}

func newAPIDataInfo(apiColumnInfo *CApiDataInfo) *APIDataInfo {
    return &APIDataInfo{apiColumnInfo: apiColumnInfo}
}

func (di *APIDataInfo) Free() {
    if di.apiColumnInfo != nil {
		cstd.Free(unsafe.Pointer(di.apiColumnInfo))
        di.apiColumnInfo = nil
    }
}
func (di *APIDataInfo) DataType() DataType {
	return (DataType)(di.apiColumnInfo._type)
}

func (di *APIDataInfo) IsNull() bool {
	return di.apiColumnInfo.is_null == CApiBool(1)
}

func (di *APIDataInfo) DataSize() uintptr {
	return (uintptr)(di.apiColumnInfo.data_size)
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ DataInfo             = (*APIDataInfo)(nil)
)
