package driver

import (
    "fmt"
)

// All golang driver-level errors will have a SQL State of HY000, so we don't include that here
// All we include are the error codes
// Please note, this map is expected to be a constant and NOT to be modified (currently golang doesn't allow
// for complex types to be declared as constant)
//
type ErrorDefinition struct {
    errorCode int
    errorText string
}

type DriverErrorCode int

const (
    DRIVER_ERROR_UNKNOWN_TYPE = iota
    DRIVER_ERROR_UNKNOWN_TYPE_S
    DRIVER_ERROR_UNKNOWN_COLUMN_TYPE_I
    DRIVER_ERROR_BULK_FETCH_TYPE_S
    DRIVER_ERROR_INVALID_NUMBER_OF_PARAM_II
    DRIVER_ERROR_NO_COLUMN_INFO_I
    DRIVER_ERROR_INVALID_COLUMN_TYPE_I
    DRIVER_ERROR_CONNECTION_ALLOC_FAILED
    DRIVER_ERROR_UNSUPPORTED_OPERATION_S
    DRIVER_ERROR_UNKNOWN_NUMBER_OF_COLUMNS
    DRIVER_ERROR_UNKNOWN_NUMBER_OF_COLUMNS_S
    DRIVER_ERROR_INVALID_BULK_FETCH_SIZE_S
    DRIVER_ERROR_NO_PARAM_METADATA
    DRIVER_ERROR_NO_PARAM_METADATA_I
    DRIVER_ERROR_NO_PARAM_METADATA_IS
    DRIVER_ERROR_BULK_FETCH_NO_BULK_VALUES
    DRIVER_ERROR_NO_INPUT_PARAMS_EXPECTED
    DRIVER_ERROR_BULK_EXECUTE_INVALID_ROWS
    DRIVER_ERROR_LIBRARY_LOAD_FAILED
    DRIVER_ERROR_LIBRARY_NO_VERSION_STRING
    DRIVER_ERROR_LIBRARY_VERSION_MISMATCH_SS
    DRIVER_ERROR_INVALID_DATE_S
    DRIVER_ERROR_INVALID_DATE_SS
    DRIVER_ERROR_INVALID_DATE_IIS
    DRIVER_ERROR_INVALID_DATE_IISS
    DRIVER_ERROR_LOB_READER_WRONG_COLUMN_I
    DRIVER_ERROR_NO_PARAM_INFO_I
    DRIVER_ERROR_INVALID_CONNECT_PROPERTY_S
    DRIVER_ERROR_LOB_READER_STILL_IN_USE
    DRIVER_ERROR_LOB_READER_NO_PARAM_INDEX
    DRIVER_ERROR_LOB_READER_NULL_DATA_FETCH
	DRIVER_ERROR_LOB_READER_LOB_READER_NOT_LOB_DATA
	DRIVER_ERROR_INVALID_COMMUNICATION_TIMEOUT
	DRIVER_ERROR_INVALID_PACKET_SIZE
	DRIVER_ERROR_INVALID_REALVECTOR_SIZE_III
	DRIVER_ERROR_INVALID_REALVECTOR_SIZE_IN_BATCH_IIII
	DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_III
	DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_IN_BATCH_IIII
	DRIVER_ERROR_REALVECTOR_VALUE_OUT_OF_RANGE_IIS
	DRIVER_ERROR_INVALID_REALVECTOR_IN_FETCH
	DRIVER_ERROR_INVALID_REALVECTOR_IN_BULK_FETCH_I
	DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_III
	DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_IN_BATCH_IIII
	DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_III
	DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_IN_BATCH_IIII
	DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS
	DRIVER_ERROR_INVALID_HALFVECTOR_IN_FETCH
	DRIVER_ERROR_INVALID_HALFVECTOR_IN_BULK_FETCH_I
)

type DriverErrorInfo struct {
    errorCode int
    errorText string
}

// NOTE: This is NOT meant to be used directly, but (at the time of writing) Go doesn't
// allow for complex/user-defined global variables to be  declared as constant/immutable.
// Please use getDriverErrorInfo() to access the entries of this map!
var _errorCodeMap = map[int]DriverErrorInfo {
    DRIVER_ERROR_UNKNOWN_TYPE:                       {-11101, "Unknown Type"},
    DRIVER_ERROR_UNKNOWN_TYPE_S:                     {-11101, "Unknown Type: %s "},
    DRIVER_ERROR_UNKNOWN_COLUMN_TYPE_I:              {-11101, "Unknown column type: %d"},
    DRIVER_ERROR_BULK_FETCH_TYPE_S:                  {-11102, "Error: Not bulk fetching %s"},
    DRIVER_ERROR_INVALID_NUMBER_OF_PARAM_II:         {-11103, "Expected number of input parameters: %d, got: %d"},
    DRIVER_ERROR_NO_COLUMN_INFO_I:                   {-11104, "No column information was obtained for column %d"},
    DRIVER_ERROR_INVALID_COLUMN_TYPE_I:              {-11105, "Could not determine the column type for the: %d column"},
    DRIVER_ERROR_CONNECTION_ALLOC_FAILED:            {-11106, "Failed to allocate a connection object"},
    DRIVER_ERROR_UNSUPPORTED_OPERATION_S:            {-11107, "%s"},
    DRIVER_ERROR_UNKNOWN_NUMBER_OF_COLUMNS:          {-11108, "Could not obtain the number of ResultSet columns for the executed Query"},
    DRIVER_ERROR_UNKNOWN_NUMBER_OF_COLUMNS_S:        {-11108, "Could not obtain the number of ResultSet columns for the executed Query: %s"},
    DRIVER_ERROR_INVALID_BULK_FETCH_SIZE_S:          {-11109, "%s"},
    DRIVER_ERROR_NO_PARAM_METADATA:                  {-11110, "Could not get Parameter Metadata for the column"},
    DRIVER_ERROR_NO_PARAM_METADATA_I:                {-11110, "Could not get Parameter Metadata for the column %d"},
    DRIVER_ERROR_NO_PARAM_METADATA_IS:               {-11110, "Could not get Parameter Metadata for the column %d: %s"},
    DRIVER_ERROR_BULK_FETCH_NO_BULK_VALUES:          {-11111, "No values provided"},
    DRIVER_ERROR_NO_INPUT_PARAMS_EXPECTED:           {-11112, "This statement execution does not expect any input/output parameters"},
    DRIVER_ERROR_BULK_EXECUTE_INVALID_ROWS:          {-11113, "All of the batch rows do not have the same length"},
    DRIVER_ERROR_LIBRARY_LOAD_FAILED:                {-11114, "Loading the shared library has failed, please ensure that it is on your library path"},
    DRIVER_ERROR_LIBRARY_NO_VERSION_STRING:          {-11115, "Unable to retrieve the version string from the shared library"},
    DRIVER_ERROR_LIBRARY_VERSION_MISMATCH_SS:        {-11116, "Invalid shared library version version.  Expected '%s', but found '%s'."},
    DRIVER_ERROR_INVALID_DATE_S:                     {-11117, "Specified date '%v' with year = 0 is not supported by the server"},
    DRIVER_ERROR_INVALID_DATE_SS:                    {-11117, "Specified date '%v' would result in a UTC date '%v' with year = 0, which is not supported by the server"},
    DRIVER_ERROR_INVALID_DATE_IIS:                   {-11117, "Error for Time value in row %d, column %d: Specified date '%v' with year = 0 is not supported by the server"},
    DRIVER_ERROR_INVALID_DATE_IISS:                  {-11117, "Error for Time value in row %d, column %d: Specified date '%v' would result in a UTC date '%v' with year = 0, which is not supported by the server"},
    DRIVER_ERROR_LOB_READER_WRONG_COLUMN_I:          {-11118, "LOB reader is being provided for a non-LOB column type: %d"},
    DRIVER_ERROR_NO_PARAM_INFO_I:                    {-11119, "Unable to get the Param Info for column %d"},
    DRIVER_ERROR_INVALID_CONNECT_PROPERTY_S:         {-11120, "%s"},
    DRIVER_ERROR_LOB_READER_STILL_IN_USE:            {-11121, "The previous reader is still being used"},
    DRIVER_ERROR_LOB_READER_NO_PARAM_INDEX:          {-11122, "Parameter index not set for WriteLOB"},
    DRIVER_ERROR_LOB_READER_NULL_DATA_FETCH:         {-11123, "Fetching null data with a ReadLOB - please re-execute the query use a NullReadLOB to get the data"},
    DRIVER_ERROR_LOB_READER_LOB_READER_NOT_LOB_DATA: {-11124, "Not fetching LOB data"},
	DRIVER_ERROR_INVALID_COMMUNICATION_TIMEOUT:		 {-11125, "The provided communication timeout is invalid"},
	DRIVER_ERROR_INVALID_PACKET_SIZE:				 {-11126, "The provided statement packet size is invalid (the value must be in this range: %d <= packet size value <= %d)"},
	DRIVER_ERROR_INVALID_REALVECTOR_SIZE_III:		 {-11127, "The Real Vector supplied does not have the correct number of elements (Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_III:		 {-11128, "The Real Vector supplied does not have the correct number of elements (Column: %d): %d elements (expected max %d elements)"},
	DRIVER_ERROR_REALVECTOR_VALUE_OUT_OF_RANGE_IIS:	 {-11129, "Real Vector value supplied is out of range (Column: %d, Row: %d): %v"},
	DRIVER_ERROR_INVALID_REALVECTOR_SIZE_IN_BATCH_IIII:		 {-11130, "The Real Vector supplied does not have the correct number of elements (Row: %d, Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_IN_BATCH_IIII:		 {-11131, "The Real Vector supplied does not have the correct number of elements (Row: %d, Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_REALVECTOR_IN_FETCH:		 {-11132, "The Real Vector fetched is invalid"},
	DRIVER_ERROR_INVALID_REALVECTOR_IN_BULK_FETCH_I: {-11133, "The Real Vector fetched is invalid (Row: %d)"},
	DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_III:		 {-11134, "The Half Vector supplied does not have the correct number of elements (Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_III:		 {-11135, "The Half Vector supplied does not have the correct number of elements (Column: %d): %d elements (expected max %d elements)"},
	DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS:	 {-11136, "Half Vector value supplied is out of range (Column: %d, Row: %d): %v"},
	DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_IN_BATCH_IIII:		 {-11137, "The Half Vector supplied does not have the correct number of elements (Row: %d, Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_IN_BATCH_IIII:		 {-11138, "The Half Vector supplied does not have the correct number of elements (Row: %d, Column: %d): %d elements (expected %d elements)"},
	DRIVER_ERROR_INVALID_HALFVECTOR_IN_FETCH:		 {-11139, "The Half Vector fetched is invalid"},
	DRIVER_ERROR_INVALID_HALFVECTOR_IN_BULK_FETCH_I: {-11140, "The Half Vector fetched is invalid (Row: %d)"},
}

func getDriverErrorInfo(driverErrorCode DriverErrorCode) (*DriverErrorInfo, error) {
    driverErrorInfo, ok := _errorCodeMap[int(driverErrorCode)]

    if !ok {
        return nil, fmt.Errorf("No error found for the code provided: %d", int(driverErrorCode))
    }

    return &driverErrorInfo, nil
}
