package driver

import (
	"database/sql"
	"database/sql/driver"
	api "SAP/go-hdb/driver/internal/api"
)

var init_ok bool

type drv struct{}


func init() {
	sql.Register(DriverName, &drv{})
	init_ok = api.Init()
}

func (d *drv) Open(dsn string) (driver.Conn, error) {
	if !init_ok {
		return nil, newError(newGoDriverError(DRIVER_ERROR_LIBRARY_LOAD_FAILED))
	}

	version, ok := api.ClientVersion()

	if !ok {
		return nil, newError(newGoDriverError(DRIVER_ERROR_LIBRARY_NO_VERSION_STRING))
	} else if version != EXPECTED_DBCAPI_VERSION {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_LIBRARY_VERSION_MISMATCH_SS,
			EXPECTED_DBCAPI_VERSION, version))
	}

	conn, err := newConnection()

	if err != nil {
		return nil, err
	}

	err = conn.connectWithDSNString(dsn)

	if err != nil {
		return nil, err
	}

	return conn, nil
}
