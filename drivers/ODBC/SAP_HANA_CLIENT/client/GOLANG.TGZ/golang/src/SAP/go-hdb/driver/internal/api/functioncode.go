package api

// We only need a few of them for functions within the golang driver,
// so keeping this upt to date isn't particulary necessary
// If a new function code is needed for golang specific operation
// Updated it here.
type FunctionCode = int

// Consult api/Communication/Protocol/Layout.hpp
// for the full list of function codes
const (
	_                   = iota
	FunctionCode_DDL    = 1
	FunctionCode_INSERT = 2
	FunctionCode_UPDATE = 3
	FunctionCode_DELETE = 4
)
