package driver

import (
	"container/list"
	"context"
	"database/sql/driver"
	"fmt"
	"math"
	"reflect"
	"runtime/cgo"
	"time"
	"unsafe"
	api "SAP/go-hdb/driver/internal/api"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

// Needed to handle bound parameters
type boundParameterValue struct {
	boundStruct api.BindData
	isBatch     bool
	batchSize   uint64
}

func (bpv *boundParameterValue) cleanup() {
	if bpv.boundStruct != nil {
		defer bpv.boundStruct.Free()
	}
}

type paramInfoValues struct {
	paramInfos []api.ParameterInfo
}

func (bpi *paramInfoValues) cleanup() {
	if bpi.paramInfos != nil {
		// Assumes that all locations have a value associated
		for i := 0; i < len(bpi.paramInfos); i++ {
			if bpi.paramInfos[i] != nil {
				bpi.paramInfos[i].Free()
			}
		}
	}
}


type statement struct {
	query               string
	apiStatement        api.PreparedStatement
	conn                *connection
	Ok                  bool
	functionCode        int
	boundParameterInfos *paramInfoValues // Used in executeBatchInternal
	err                 error            // Permanent error for the statement (e.g. not being able to get param information required for execution)
	// Rows are first track in a map (in increasing order of rows), then for a specific row
	// the WriteLOBs are stored (with knowledge of the column index), in increasing order of columns.
	// Both indices are zero based
	storedWriteLobs     map[uint]*list.List
	theErrors *HdbError // Holds errors/warnings
	handle *cgo.Handle // Holds the pointer to the statement itself for C callback usage
	packetSize *uint32
}

// driver.Stmt interface https://pkg.go.dev/database/sql/driver#Stmt
func (statement *statement) Close() error {
	statement.apiStatement.Free()

	if statement.boundParameterInfos != nil {
		statement.boundParameterInfos.cleanup()
	}

	if statement.hasWriteLOBs() {
		statement.clearLOBs()
	}

	statement.resetErrors() // Already returned from Query[Context]/Exec[Context]
	if statement.conn.dsnInfo.ReportWarningsWithErrors() {
		statement.conn.apiConnection.RemoveWarningCallback()
	}

	return nil
}

// driver.Stmt interface https://pkg.go.dev/database/sql/driver#Stmt
func (statement *statement) Exec(args []driver.Value) (driver.Result, error) {
	return statement.execInternal(context.Background(), args)
}

// driver.StmtExecContext interface https://pkg.go.dev/database/sql/driver#StmtExecContext
func (statement *statement) ExecContext(ctx context.Context, args []driver.NamedValue) (driver.Result, error) {
	value := make([]driver.Value, len(args))

	for i := 0; i < len(args); i++ {
		value[i] = args[i].Value
	}

	return statement.execInternal(ctx, value)
}

func (statement *statement) execInternal(ctx context.Context, args []driver.Value) (driver.Result, error) {
	// This needs to find, from this level, whether or not we are dealing with [][]interface{}
	// or regular values.
	// 1) If we are dealing with regular parameters, proceed as normal
	// 2) If we are dealing with an [][]interface{} this will be the
	// only parameter [len(args) == 1].
	//    a) Bindings will be consumed up to how many rows contain the same types of columns
	//       consecutively. Once a row is found that is not similar, what has been batched so far is
	//       sent off
	//    b) Variable length arguments may use the metadata length reported to know the buffer size
	//       to use
	// 3) [][]interface{} and separate parameters cannot be mixed
	statement.resetErrors()
	if statement.functionCode == 0 {
		statement.functionCode = statement.apiStatement.GetFunctionCode()
	}
	err := statement.setAPIPropertiesAffectingExecution(ctx)

	if err != nil {
		return nil, err
	}

	defer statement.clearAPIPropertiesSetFromStmtContext()

	argsLength := len(args)
	if argsLength == 1 {
		v := reflect.ValueOf(args[0])
		if bulkValues, ok := v.Interface().([][]interface{}); ok {
			if (statement.functionCode != api.FunctionCode_INSERT) &&
				(statement.functionCode != api.FunctionCode_UPDATE) &&
				(statement.functionCode != api.FunctionCode_DELETE) {
				return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
					"Batching is only supported for Inserts/Updates/Deletes"))
			}

			err = statement.executeBatchInternal(bulkValues, ctx)
		} else {
			err = statement.executeInternal(args, ctx)
		}
	} else {
		err = statement.executeInternal(args, ctx)
	}

	if err != nil {
		v := reflect.ValueOf(err)
		hanaError, ok := v.Interface().(Error)

		if ok {
			statement.addError(hanaError)
			return nil, statement.errors()
		}

		// Error required for upper layer - return directly
		return nil, err
	}

	if statement.functionCode == api.FunctionCode_DDL {
		return driver.ResultNoRows, nil
	}
	rowsAffected := statement.apiStatement.RowsAffected()
	if rowsAffected == -1 {
		err = statement.conn.getError()

		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				statement.addError(hanaError)
				return &result{rowsAffected: -1, err: statement.errors()}, statement.errors()
			}

			return &result{rowsAffected: -1, err: err}, err
		}

		return &result{rowsAffected: -1, err: nil}, statement.errors()
	} else {
		return &result{rowsAffected: int64(rowsAffected), err: nil}, statement.errors()
	}
}

func (statement *statement) clearAPIPropertiesSetFromStmtContext() {
// Per-statement properties which are set through dbcapi API calls directly
// for the duration of the current excute call
	statement.unsetTimeout()
	_ = statement.setRowsetFetchSize(1)
	statement.unsetPacketSize()
}

func (statement *statement) setAPIPropertiesAffectingExecution(ctx context.Context) error {
// Per-statement properties which are set through dbcapi API calls directly
// before the execute call and which last for the duration of the current excute call
	deadline, ok := ctx.Deadline()

	if ok {
		err := statement.setTimeout(deadline.Sub(time.Now()))
		if err != nil {
			return err
		}
	}

	packetSize, ok := getStmtPacketSizeFromContext(ctx)

	if ok {
		statement.setPacketSize(packetSize)
	}

	return nil
}


func (statement *statement) executeInternal(args []driver.Value,
	ctx context.Context) error {
	numberOfParameters := len(args)
	expectedNumberOfParams := statement.apiStatement.NumParams()

	if numberOfParameters != expectedNumberOfParams {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_NUMBER_OF_PARAM_II,
			expectedNumberOfParams, numberOfParameters))
	}

	statement.clearLOBs()

	for i := 0; i < len(args); i++ {
		bpv, err := statement.bindParameter(i, args[i])
		defer bpv.cleanup()

		if err != nil {
			return err
		}
	}

	var execRes bool
	communicationTimeout, ok := getStmtCommunicationTimeoutFromContext(ctx)

	if ok {
		execRes = statement.apiStatement.ExecuteWithTimeout(communicationTimeout)
	} else {
		execRes = statement.apiStatement.Execute()
	}


	var err error

	if !execRes {
		err = statement.conn.getError()
	}

	if statement.hasWriteLOBs() {
		if err != nil {
			statement.clearLOBs()
		} else {
			err = statement.sendDataFromWriteLOBs()
		}
	}

	return err
}

//This function can be optimized since dbcapi is fixed now. The caller can allocate
//a buffer once and pass it to the function, rather then this function allocating
//buffer for a single use.
func (statement *statement) bindParameter(index int, paramVal driver.Value) (*boundParameterValue, error) {
	// All pointer memory is to be deallocated by the caller
	bpv := new(boundParameterValue)
	bindData, ok := statement.apiStatement.DescribeBindParam(index)
	bpv.boundStruct = bindData

	if !ok {
		return bpv, statement.conn.getError()
	}

	isNotAddress := false
	isNotDataAtExecute := false

	if paramVal == nil {
		bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
		bpv.boundStruct.SetNull(0, true)
	} else {
		v := reflect.ValueOf(paramVal)

		switch v.Kind() {
		case reflect.Uint8:
			fallthrough
		case reflect.Uint16:
			fallthrough
		case reflect.Uint32:
			fallthrough
		case reflect.Uint64:
			fallthrough
		case reflect.Uint:
			bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
			iVal := (*cstd.UInt64)(cstd.Malloc(cstd.SizeofUInt64))
			*iVal = cstd.UInt64(v.Uint())
			bpv.boundStruct.SetValue(0, unsafe.Pointer(iVal), uintptr(cstd.SizeofUInt64))
			bpv.boundStruct.SetType(api.A_UVAL64)
		case reflect.Int8:
			fallthrough
		case reflect.Int16:
			fallthrough
		case reflect.Int32:
			fallthrough
		case reflect.Int64:
			fallthrough
		case reflect.Int:
			bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
			iVal := (*cstd.Int64)(cstd.Malloc(cstd.SizeofInt64))
			*iVal = cstd.Int64(v.Int())
			bpv.boundStruct.SetValue(0, unsafe.Pointer(iVal), uintptr(cstd.SizeofInt64))
			bpv.boundStruct.SetType(api.A_VAL64)
		case reflect.Bool:
			bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
			bVal := (*cstd.Bool)(cstd.Malloc(cstd.SizeofBool))
			*bVal = cstd.Bool(v.Bool())
			bpv.boundStruct.SetValue(0, unsafe.Pointer(bVal), uintptr(cstd.SizeofBool))
			bpv.boundStruct.SetType(api.A_VAL8)
		case reflect.Float32:
			fallthrough
		case reflect.Float64:
			bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
			dVal := (*cstd.Double)(cstd.Malloc(cstd.SizeofDouble))
			*dVal = cstd.Double(v.Float())
			bpv.boundStruct.SetValue(0, unsafe.Pointer(dVal), uintptr(cstd.SizeofDouble))
			bpv.boundStruct.SetType(api.A_DOUBLE)
		case reflect.String:
			strVal := v.String()
			stringLen := len(strVal)
			a := make([]byte, stringLen+1)
			copy(a[:], strVal)
			stringVal := (*cstd.Char)(cstd.Malloc(cstd.Size_t(stringLen + 1)))
			cstd.Memset(unsafe.Pointer(stringVal), cstd.Int(0), cstd.Size_t(stringLen+1))
			cstd.Strncpy((*cstd.Char)(stringVal), (*cstd.Char)(unsafe.Pointer(&a[0])), cstd.Size_t(stringLen))
			bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
			bpv.boundStruct.SetValue(0, unsafe.Pointer(stringVal), uintptr(stringLen))
			bpv.boundStruct.SetType(api.A_STRING)
		case reflect.Slice:
			if bArr, ok := v.Interface().([]byte); ok {
				bArrLen := len(bArr)
				if len(bArr) > 0 {
					sliceVal := (*cstd.Char)(cstd.Malloc(cstd.Size_t(bArrLen)))
					cstd.Memcpy(unsafe.Pointer(sliceVal), unsafe.Pointer(&bArr[0]), cstd.Size_t(bArrLen))
					bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
					bpv.boundStruct.SetValue(0, unsafe.Pointer(sliceVal), uintptr(cstd.Size_t(bArrLen)))
				} else {
					a := make([]byte, 1)
					sliceLength := cstd.Size_t(1)
					sliceVal := (*cstd.Char)(cstd.Malloc(cstd.Size_t(sliceLength)))
					cstd.Memcpy(unsafe.Pointer(sliceVal), unsafe.Pointer(&a[0]), sliceLength)
					bpv.boundStruct.InitializeBuffers(1, isNotAddress, isNotDataAtExecute)
					bpv.boundStruct.SetValue(0, unsafe.Pointer(sliceVal), uintptr(cstd.Size_t(bArrLen)))
				}
				bpv.boundStruct.SetType(api.A_BINARY)
			} else {
				err := statement.handleNonByteSliceInputParameter(v, index, bpv)

				if err != nil {
					return bpv, err
				}
			}
		default:
			if tVal, ok := v.Interface().(time.Time); ok {
				err := statement.createStringBufferForTimeValue(bpv, tVal, index)

				if err != nil {
					return bpv, err
				}
			} else if writeLOB, ok := v.Interface().(*WriteLOB); ok {
				// We hold all Write LOBs for after the call to dbcapi_execute()
				// to subsequently and sequentially send their data via
				// dbcapi_send_param_data().
				// See sendretrievepartblob.SendRetrievePartBlob.run()
				err := statement.bindBufferForDataAfterExecute(bpv, writeLOB,
					index)

				if err != nil {
					return bpv, err
				}

				statement.storeLOBForColumnOfSingleRow(uint(index), writeLOB)
			} else {
				return bpv, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNKNOWN_TYPE_S,
					v.Kind()))
			}
		}
	}

	bindRes := statement.apiStatement.BindParam(index, bpv.boundStruct)

	if !bindRes {
		return bpv, statement.conn.getError()
	}
	return bpv, nil
}

func (statement *statement) handleNonByteSliceInputParameter(v reflect.Value, index int, bpv *boundParameterValue) error {
	paramInfo, ok := statement.apiStatement.GetBindParamInfo(index)

	if ok {
		defer paramInfo.Free()

		if floatArray, ok := v.Interface().([]float32); ok {
			if statement.isRealVectorColumn(paramInfo) {
				err := statement.addFloat32SliceInputParameterValuesForRealVectorColumn(index,
					paramInfo, bpv, floatArray)

				if err != nil {
					return err
				}

				return nil
			} else if statement.isHalfVectorColumn(paramInfo) {
				err := statement.addFloat32SliceInputParameterValuesForHalfVectorColumn(index,
					paramInfo, bpv, floatArray)

				if err != nil {
					return err
				}

				return nil
			}
		} else if doubleArray, ok := v.Interface().([]float64); ok {
			if statement.isRealVectorColumn(paramInfo) {
				err := statement.addFloat64SliceInputParameterValuesForRealVectorColumn(index,
					paramInfo, bpv, doubleArray)

				if err != nil {
					return err
				}

				return nil
			} else if statement.isHalfVectorColumn(paramInfo) {
				err := statement.addFloat64SliceInputParameterValuesForHalfVectorColumn(index,
					paramInfo, bpv, doubleArray)

				if err != nil {
					return err
				}

				return nil
			}
		}
	}

	return newError(newGoDriverError(DRIVER_ERROR_UNKNOWN_TYPE))
}

const (
	maxRealVectorValue = math.MaxFloat32
	minRealVectorValue = -math.MaxFloat32
	maxPositiveNormalizedFloat16 = 65504.0;
	minNegativeNormalizedFloat16 = -65504.0;
)

func (statement *statement) isRealVectorColumn(paramInfo api.ParameterInfo) bool {
	return (paramInfo.NativeType() == api.DT_REAL_VECTOR)
}

func (statement *statement) isHalfVectorColumn(paramInfo api.ParameterInfo) bool {
	return (paramInfo.NativeType() == api.DT_HALF_VECTOR)
}

func (statement *statement) addFloat32SliceInputParameterValuesForRealVectorColumn(columnIndex int,
	paramInfo api.ParameterInfo, bpv *boundParameterValue, arrayValues []float32) error {
	numberOfValues := len(arrayValues)
	// (Number of values (recorded as 4 byte int) + (sizeof(float32)*number of values)
	dataSize := uint32(unsafe.Sizeof(uint32(0)))
	theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
	bpv.boundStruct.InitializeBuffers(1, false, false)
	bpv.boundStruct.SetValue(0, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))
	bpv.boundStruct.SetType(api.A_BINARY)

	if paramInfo.Precision() == 0 { // Unconstrained column
		if numberOfValues > api.GetSuggestedUnconstrainedRealVectorDimension() {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_III,
				columnIndex, numberOfValues, api.GetSuggestedUnconstrainedRealVectorDimension()))
		}
	} else if (paramInfo.Precision() != uint16(numberOfValues))	{
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_REALVECTOR_SIZE_III,
			columnIndex, numberOfValues, int(paramInfo.Precision())))
	}

	statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

	for rowIndex := 1; rowIndex <= numberOfValues; rowIndex++ {
		rawIntValue := *(*uint32)(unsafe.Pointer(&arrayValues[rowIndex - 1]))
		valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
			uintptr(cstd.SizeofChar)*uintptr(rowIndex)*uintptr(dataSize)))
		statement.addBinary32ValueToVectorCBuffer(rawIntValue, valueLocation)
	}

	return nil
}

func (statement *statement) addFloat64SliceInputParameterValuesForRealVectorColumn(columnIndex int,
	paramInfo api.ParameterInfo, bpv *boundParameterValue, arrayValues []float64) error {
	numberOfValues := len(arrayValues)
	// (Number of values (recorded as 4 byte int) + (sizeof(float32)*number of values)
	dataSize := uint32(unsafe.Sizeof(uint32(0)))
	theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
	bpv.boundStruct.InitializeBuffers(1, false, false)
	bpv.boundStruct.SetValue(0, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))
	bpv.boundStruct.SetType(api.A_BINARY)

	if paramInfo.Precision() == 0 { // Unconstrained column
		if numberOfValues > api.GetSuggestedUnconstrainedRealVectorDimension() {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_III,
				columnIndex, numberOfValues, api.GetSuggestedUnconstrainedRealVectorDimension()))
		}
	} else if (paramInfo.Precision() != uint16(numberOfValues))	{
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_REALVECTOR_SIZE_III,
			columnIndex, numberOfValues, int(paramInfo.Precision())))
	}

	statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

	for rowIndex := 1; rowIndex <= numberOfValues; rowIndex++ {
		if arrayValues[rowIndex - 1] > maxRealVectorValue ||
			arrayValues[rowIndex - 1] < minRealVectorValue {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_REALVECTOR_VALUE_OUT_OF_RANGE_IIS,
				columnIndex, rowIndex, arrayValues[rowIndex -1]))
		}

		floatValue := float32(arrayValues[rowIndex - 1])
		rawIntValue := *(*uint32)(unsafe.Pointer(&floatValue))
		valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
			uintptr(cstd.SizeofChar)*uintptr(rowIndex)*uintptr(dataSize)))
		statement.addBinary32ValueToVectorCBuffer(rawIntValue, valueLocation)
	}

	return nil
}

func (statement *statement) addBinary32ValueToVectorCBuffer(binary32Value uint32,
	theValues *cstd.Char) {
	valueLocation := (*cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(theValues))))
	valueLocationPtr := valueLocation
	*valueLocationPtr = (cstd.Char)(binary32Value & 0xFF)
	valueLocationPtr = (*cstd.Char)(unsafe.Add(unsafe.Pointer(valueLocation),
		uintptr(cstd.SizeofChar*1)))
	*valueLocationPtr = (cstd.Char)((binary32Value >> 8) & 0xFF)
	valueLocationPtr = (*cstd.Char)(unsafe.Add(unsafe.Pointer(valueLocation),
		uintptr(cstd.SizeofChar*2)))
	*valueLocationPtr = (cstd.Char)((binary32Value >> 16) & 0xFF)
	valueLocationPtr = (*cstd.Char)(unsafe.Add(unsafe.Pointer(valueLocation),
		uintptr(cstd.SizeofChar*3)))
	*valueLocationPtr = (cstd.Char)((binary32Value >> 24) & 0xFF)
}

func (statement *statement) setupCBufferForVectorValues(numberOfVectorValues int,
	dataSize uint32) (*cstd.Char, uint32) {
	// The size is always a 4 byte integer
	bufferSize := uint32(unsafe.Sizeof(uint32(0))) + uint32(numberOfVectorValues)*dataSize
	theValues := (*cstd.Char)(cstd.Calloc(cstd.Size_t(bufferSize), cstd.SizeofChar))
	return theValues, bufferSize
}


func (statement *statement) addFloat32SliceInputParameterValuesForHalfVectorColumn(columnIndex int,
	paramInfo api.ParameterInfo, bpv *boundParameterValue, arrayValues []float32) error {
	numberOfValues := len(arrayValues)
	lengthSize := uint32(unsafe.Sizeof(uint32(0)))
	dataSize := uint32(unsafe.Sizeof(uint16(0)))
	// (Number of values (recorded as 4 byte int) + (sizeof(float16)*number of values)
	theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
	bpv.boundStruct.InitializeBuffers(1, false, false)
	bpv.boundStruct.SetValue(0, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))
	bpv.boundStruct.SetType(api.A_BINARY)

	if paramInfo.Precision() == 0 { // Unconstrained column
		if numberOfValues > api.GetSuggestedUnconstrainedHalfVectorDimension() {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_III,
				columnIndex, numberOfValues, api.GetSuggestedUnconstrainedHalfVectorDimension()))
		}
	} else if (paramInfo.Precision() != uint16(numberOfValues))	{
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_III,
			columnIndex, numberOfValues, int(paramInfo.Precision())))
	}

	statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

	for rowIndex := 0; rowIndex < numberOfValues; rowIndex++ {
		if arrayValues[rowIndex] > maxPositiveNormalizedFloat16 ||
			arrayValues[rowIndex] < minNegativeNormalizedFloat16 {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS,
				columnIndex, rowIndex, arrayValues[rowIndex]))
		}
		float32Value := arrayValues[rowIndex]
		valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
			uintptr(cstd.SizeofChar)*(uintptr(lengthSize) + uintptr(rowIndex)*uintptr(dataSize))))
		statement.addFloat32ValueAsBinary16ToVectorCBuffer(float32Value, valueLocation)
	}

	return nil
}

func (statement *statement) addFloat64SliceInputParameterValuesForHalfVectorColumn(columnIndex int,
	paramInfo api.ParameterInfo, bpv *boundParameterValue, arrayValues []float64) error {
	numberOfValues := len(arrayValues)
	lengthSize := uint32(unsafe.Sizeof(uint32(0)))
	dataSize := uint32(unsafe.Sizeof(uint16(0)))
	// (Number of values (recorded as 4 byte int) + (sizeof(float16)*number of values)
	theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
	bpv.boundStruct.InitializeBuffers(1, false, false)
	bpv.boundStruct.SetValue(0, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))
	bpv.boundStruct.SetType(api.A_BINARY)

	if paramInfo.Precision() == 0 { // Unconstrained column
		if numberOfValues > api.GetSuggestedUnconstrainedHalfVectorDimension() {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_III,
				columnIndex, numberOfValues, api.GetSuggestedUnconstrainedHalfVectorDimension()))
		}
	} else if (paramInfo.Precision() != uint16(numberOfValues))	{
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_III,
			columnIndex, numberOfValues, int(paramInfo.Precision())))
	}

	statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

	for rowIndex := 0; rowIndex < numberOfValues; rowIndex++ {
		if arrayValues[rowIndex] > maxPositiveNormalizedFloat16 ||
			arrayValues[rowIndex] < minNegativeNormalizedFloat16 {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS,
				columnIndex, rowIndex, arrayValues[rowIndex]))
		}
		float32Value := float32(arrayValues[rowIndex])
		valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
			uintptr(cstd.SizeofChar)*(uintptr(lengthSize) + uintptr(rowIndex)*uintptr(dataSize))))
		statement.addFloat32ValueAsBinary16ToVectorCBuffer(float32Value, valueLocation)
	}

	return nil
}

func (statement *statement) addFloat32ValueAsBinary16ToVectorCBuffer(float32Value float32,
	theValues *cstd.Char) {
	valueAsUint16 :=  convertFloat32ValueBinary16(float32Value)
	valueLocation := (*cstd.Char)(unsafe.Pointer(uintptr(unsafe.Pointer(theValues))))
	valueLocationPtr := valueLocation
	*valueLocationPtr = (cstd.Char)(valueAsUint16 & 0xFF)
	valueLocationPtr = (*cstd.Char)(unsafe.Add(unsafe.Pointer(valueLocation),
		uintptr(cstd.SizeofChar*1)))
	*valueLocationPtr = (cstd.Char)((valueAsUint16 >> 8) & 0xFF)
}

// Lifted from InterfacesCommon::floatToHalf
// NOTE:
// 1) In future this should be replaced by a a DBCAPI function that does this logic
// to eliminate duplication/prevent this code from becoming stale if the logic is modified
// 2) There is also a chance that this can be sped up by using a pre-generated table for the values
// as described in the paper: http://www.fox-toolkit.org/ftp/fasthalffloatconversion.pdf
func convertFloat32ValueBinary16(float32Value float32) uint16 {
	valueAsUint32 :=  *(*uint32)(unsafe.Pointer(&float32Value))
	sign := int((valueAsUint32 >> 16) & 0x8000)
	exponent := int(((valueAsUint32 >> 23) & 0xFF) - (127 - 15))
	mantissa := int((valueAsUint32 >> 13) & 0x3FF)

	if exponent <= 0 {
		// Subnormal number
		if exponent < -10 {
			// Too small to be represented as a subnormal half, return signed zero
			return uint16(sign)
		}
		// Add the implicit leading 1 bit
		mantissa = (mantissa | 0x0400) & 0x0FFFF
		// Apply rounding to the nearest even value
		roundBit := 1 << (1 - exponent - 1);

		if (mantissa & roundBit) > 0 {
			mantissa += roundBit;
			// Handle overflow of mantissa
			if (mantissa & 0x0800) > 0 {  // Overflow check
				mantissa >>= 1		 // Adjust mantissa
				exponent++			 // Increment exponent
			}
		}
		// Right-shift the mantissa
		mantissa >>= (1 - exponent);
		exponent = 0;
	} else if (exponent >= 31) {
		// Infinity or NaN
		exponent = 31;
		if ((valueAsUint32 & 0x7FFFFF) != 0 && ((valueAsUint32 >> 23) & 0xFF) == 0xFF) {
			// NaN, set mantissa to any non-zero value
			mantissa = 0x200;
		} else {
			// Infinity
			mantissa = 0;
		}
	} else {
		// Round to nearest even - bankers' rounding
		if (valueAsUint32 & 0x1000) > 0 {
			mantissa++;
			if (mantissa & 0x400) > 0 {
				mantissa = 0;
				exponent++;
				if (exponent >= 31) {
					exponent = 31;
				}
			}
		}
	}

	return uint16(sign) | uint16(exponent << 10) | uint16(mantissa)
}

func (statement *statement) createStringBufferForTimeValue(bpv *boundParameterValue,
	tVal time.Time, index int) error {
	paramInfo, ok := statement.apiStatement.GetBindParamInfo(index)
	defer paramInfo.Free()

	if !ok {
		return newError(newGoDriverError(DRIVER_ERROR_NO_PARAM_METADATA))
	}

	var insertTimeVal time.Time

	if statement.conn.dsnInfo.ConvertTimestampToUTC() {
		insertTimeVal = tVal.UTC()
	} else {
		insertTimeVal = tVal
	}

	strVal := ""

	if (insertTimeVal.Year() == 0) && //Server does not support the year = 0 for DATE and TIMESTAMP type columns
		((paramInfo.NativeType() == api.DT_DAYDATE) ||
			(paramInfo.NativeType() == api.DT_DATE) ||
			(paramInfo.NativeType() == api.DT_LONGDATE) ||
			(paramInfo.NativeType() == api.DT_SECONDDATE)) {
		if statement.conn.dsnInfo.ConvertTimestampToUTC() {
			return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_SS,
				tVal, insertTimeVal))
		}
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_S, insertTimeVal))
	}
	if paramInfo.NativeType() == api.DT_SECONDTIME || // TIME
		paramInfo.NativeType() == api.DT_TIME {
		strVal = insertTimeVal.Format(TIME_LAYOUT_STRING)
	} else if paramInfo.NativeType() == api.DT_DAYDATE || // DATE
		paramInfo.NativeType() == api.DT_DATE {
		strVal = insertTimeVal.Format(DATE_LAYOUT_STRING)
	} else if paramInfo.NativeType() == api.DT_LONGDATE || // TIMESTAMP
		paramInfo.NativeType() == api.DT_SECONDDATE {
		if insertTimeVal.Nanosecond() == 0 {
			strVal = insertTimeVal.Format(SECONDDATE_LAYOUT_STRING)
		} else {
			strVal = insertTimeVal.Format(TS_LAYOUT_STRING)
		}
	} else { // Non-DATE|TIME|TIMESTAMP type - let the conversion success/failure be determined by lower levels
		strVal = insertTimeVal.Format(TS_LAYOUT_STRING)
	}

	stringLen := len(strVal)
	a := make([]byte, stringLen+1)
	copy(a[:], strVal)
	stringVal := (*cstd.Char)(cstd.Malloc(cstd.Size_t(stringLen + 1)))
	cstd.Strncpy((*cstd.Char)(stringVal), (*cstd.Char)(unsafe.Pointer(&a[0])), cstd.Size_t(stringLen))
	bpv.boundStruct.InitializeBuffers(1, false, false)
	bpv.boundStruct.SetValue(0, unsafe.Pointer(stringVal), uintptr(cstd.Size_t(stringLen)))
	bpv.boundStruct.SetType(api.A_STRING)
	return nil
}

func (statement *statement) bindBufferForDataAfterExecute(bpv *boundParameterValue,
	writeLOB *WriteLOB, index int) error {
	paramInfo, ok := statement.apiStatement.GetBindParamInfo(index)
	defer paramInfo.Free()

	if !ok {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_PARAM_METADATA_I,
			index))
	}

	// If multibyte, UTF-8 data is provided for a CLOB column,
	// its handling will be dependent on dbcapi/SQLDBC's handling.
	// No validation/conversion is done here
	if((paramInfo.NativeType() == api.DT_CLOB) ||
		(paramInfo.NativeType() == api.DT_NCLOB)) {
		bpv.boundStruct.SetType(api.A_STRING)
	} else if(paramInfo.NativeType() == api.DT_BLOB) {
		bpv.boundStruct.SetType(api.A_BINARY)
	} else { // Error - not a lob column
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_LOB_READER_WRONG_COLUMN_I,
			int(paramInfo.NativeType())))
	}

	// Signal this is Data provided after the execute call
	// This is implicitly done via the calloc() call initialization, earlier
	// but it is done here to ensure everything is correct
	bpv.boundStruct.InitializeBuffers(1, false, true)
	// bpv.boundStruct.SetValue(0, nil, uintptr(cstd.Size_t(2147483647)))
	return nil
}

func (statement *statement) executeBatchInternal(bulkValues [][]interface{},
	ctx context.Context) error {
	if statement.err != nil {
		return statement.err
	}
	// Bindings will be consumed up to how many rows contain the same types of columns
	// consecutively. Once a row is found that is not similar, what has been batched so far is
	// sent off and the logic continues with the next set of rows until the batch is consumed.
	// It is recommended to use the same types in all columns for all rows, for maximum efficiency.
	rows := len(bulkValues)

	if rows == 0 {
		return newError(newGoDriverError(DRIVER_ERROR_BULK_FETCH_NO_BULK_VALUES))
	}

	var (
		err error
		// boundParameterInfos *paramInfoValues
	)

	if statement.boundParameterInfos == nil {
		statement.err = statement.retrieveParamInfos()

		if statement.err != nil {
			return statement.err
		}
	}

	for rowIndex := 0; rowIndex < rows; {
		startRow := rowIndex
		var startingRowValues []reflect.Value
		startingRowValues, err =
			statement.getColumnTypesForRow(bulkValues[startRow], rowIndex)

		if err != nil {
			return err
		}
		rowIndex++

		for rowIndex < rows {
			include, err := statement.rowCanBeIncludedInBatch(bulkValues[rowIndex],
				startingRowValues, rowIndex)

			if err != nil {
				return err
			} else if !include {
				break
			}

			rowIndex++
		}

		if err != nil {
			return err
		}

		res := statement.apiStatement.SetBatchSize(uint(rowIndex-startRow))

		if !res {
			return statement.conn.getError()
		}

		err = statement.bindBulkParametersAndExecute(startRow, rowIndex-1, startingRowValues,
			bulkValues, ctx)

		if err != nil {
			return err
		}
	}

	return nil
}

func (statement *statement) getColumnTypesForRow(row []interface{}, rowIndex int) ([]reflect.Value, error) {
	rowLength := len(row)
	expectedNumberOfParams := len(statement.boundParameterInfos.paramInfos)

	if rowLength != expectedNumberOfParams {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_NUMBER_OF_PARAM_II,
			expectedNumberOfParams, rowLength))
	}

	columnValues := make([]reflect.Value, rowLength)

	var err error
	for columnIndex, column := range row {
		columnValue := reflect.ValueOf(column)

		if columnValue.IsValid() {
			err = statement.isAcceptableInputParameterType(columnValue, rowIndex, columnIndex)

			if err != nil {
				break
			}
		}
		columnValues[columnIndex] = columnValue
	}

	return columnValues, err
}

func (statement *statement) retrieveParamInfos() error {
	if statement.boundParameterInfos != nil {
		return nil
	}
	boundParameterInfos := new(paramInfoValues)
	// Deallocated by boundParameterInfos.cleanup()
	expectedNumberOfParams := statement.apiStatement.NumParams()

	if expectedNumberOfParams == 0 {
		return newError(newGoDriverError(DRIVER_ERROR_NO_INPUT_PARAMS_EXPECTED))
	}

	boundParameterInfos.paramInfos = make([]api.ParameterInfo, expectedNumberOfParams)

	var err error

	for columnIndex := 0; columnIndex < expectedNumberOfParams; columnIndex++ {
		paramInfo, ok := statement.apiStatement.GetBindParamInfo(columnIndex)

		if !ok {
			err = newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_PARAM_METADATA_IS,
				columnIndex+1, statement.conn.getError()))
			break
		}
		boundParameterInfos.paramInfos[columnIndex] = paramInfo
	}

	statement.boundParameterInfos = boundParameterInfos
	return err
}

func (statement *statement) retrieveParamInfo(columnIndex int) api.ParameterInfo {
	return statement.boundParameterInfos.paramInfos[columnIndex]
}

func (statement *statement) rowCanBeIncludedInBatch(row []interface{},
	startingRowValues []reflect.Value, rowIndex int) (bool, error) {
	if len(row) != len(startingRowValues) {
		return false, newError(newGoDriverError(DRIVER_ERROR_BULK_EXECUTE_INVALID_ROWS))
	}

	canBeBatched := true

	for columnIndex, columnInterface := range row {
		columnValue := reflect.ValueOf(columnInterface)
		startingRowValue := startingRowValues[columnIndex]

		// nil (NULL) matches any previous column value type
		if !startingRowValue.IsValid() {
			// If any of the startingRowValues are nil and the current row's column value is not
			// nil, then set the startingRowValue to the value of the current row's column - it will
			// be used in future comparisons
			if columnValue.IsValid() {
				startingRowValues[columnIndex] = columnValue
			}
		} else if columnValue.IsValid() {
			err := statement.isAcceptableInputParameterType(columnValue, rowIndex, columnIndex)

			if err != nil {
				return false, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
						fmt.Sprintf("Unsupported type (row %d, column %d)", rowIndex+1,
							columnIndex+1)))
			}

			canBeBatched = columnValue.Kind() == startingRowValue.Kind()
		} // !columnValue.isValid() => nil [NULL] (which matches any type)

		if !canBeBatched {
			break
		}
	}
	return canBeBatched, nil
}

func (statement *statement) isAcceptableInputParameterType(value reflect.Value,
	rowIndex int, columnIndex int) error {
	paramInfo := statement.retrieveParamInfo(columnIndex)

	if paramInfo == nil {
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_PARAM_INFO_I, columnIndex))
	}

	switch value.Kind() {
	case reflect.Slice:
		if _, ok := value.Interface().([]byte); ok {
			return nil
		} else if _, ok := value.Interface().([]float32); ok {
			return nil
		} else if _, ok := value.Interface().([]float64); ok {
			return nil
		}
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			fmt.Sprintf("Unsupported type (row %d, column %d)", rowIndex+1, columnIndex+1)))
	case reflect.Uint8:
		fallthrough
	case reflect.Uint16:
		fallthrough
	case reflect.Uint32:
		fallthrough
	case reflect.Uint64:
		fallthrough
	case reflect.Uint:
		fallthrough
	case reflect.Int8:
		fallthrough
	case reflect.Int16:
		fallthrough
	case reflect.Int32:
		fallthrough
	case reflect.Int64:
		fallthrough
	case reflect.Int:
		fallthrough
	case reflect.Bool:
		fallthrough
	case reflect.Float32:
		fallthrough
	case reflect.Float64:
		fallthrough
	case reflect.String:
		return nil
	default:
		if tVal, ok := value.Interface().(time.Time); ok {
			var insertTimeVal time.Time

			if statement.conn.dsnInfo.ConvertTimestampToUTC() {
				insertTimeVal = tVal.UTC()
			} else {
				insertTimeVal = tVal
			}

			// Server does not support the year = 0 for DATE and TIMESTAMP type columns
			if (insertTimeVal.Year() == 0) &&
				((paramInfo.NativeType() == api.DT_DAYDATE) ||
					(paramInfo.NativeType() == api.DT_DATE) ||
					(paramInfo.NativeType() == api.DT_LONGDATE) ||
					(paramInfo.NativeType() == api.DT_SECONDDATE)) {
				if statement.conn.dsnInfo.ConvertTimestampToUTC() {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_SS,
						tVal, insertTimeVal))
				}
				return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_S, insertTimeVal))
			}
			return nil
		}
		return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_UNSUPPORTED_OPERATION_S,
			fmt.Sprintf("Unsupported type (row %d, column %d)", rowIndex+1, columnIndex+1)))
	}
}

func (statement *statement) bindBulkParametersAndExecute(startRow int, endRow int,
	columnValues []reflect.Value, bulkValues [][]interface{},
	ctx context.Context) error {

	boundColumns, err := statement.bindBulkParameters(startRow, endRow, columnValues, bulkValues)

	for _, boundColumn := range boundColumns {
		if boundColumn != nil {
			defer boundColumn.cleanup()
		}
	}

	if err != nil {
		return err
	}

	var execRes bool
	communicationTimeout, ok := getStmtCommunicationTimeoutFromContext(ctx)

	if ok {
		execRes = statement.apiStatement.ExecuteWithTimeout(communicationTimeout)
	} else {
		execRes = statement.apiStatement.Execute()
	}

	if !execRes {
		// TODO: When multiple errors can be returned, this needs to generate errors
		// that include the row number of concern. This can be done by consulting
		// dbcapi_get_row_status( dbcapi_stmt * dbcapi_stmt ), where 1 = success,
		// and -2 = failure. It is the failure indications that will be used to update
		// NOTE: There is no way for providing information from the status array itself consistently, as that
		// would need non-standard API support (the Result struct only provides a single int64 value from the RowsAffected() method).
		// We only are concerned with the row index of erroneous cases here
		// (no error pointing to a row of input parmaeters => it was successfully used in execution)
		// The obvious deficiency = applications are unable to determine individual rows affected where
		// a row of parameters can affect one or more rows.
		return statement.conn.getError()
	}

	return nil
}

func (statement *statement) bindBulkParameters(startRow int, endRow int,
	columnValues []reflect.Value, bulkValues [][]interface{}) ([]*boundParameterValue, error) {
	numberOfColumns := len(columnValues)
	// boundColumns always needs to be returned as the memory is deallocated by the caller using
	// using defer boundColumns[index].cleanup()
	boundColumns := make([]*boundParameterValue, numberOfColumns)
	var err error

	// Loop through the columns kinds, and make a buffer array for it
	for i := 0; i < numberOfColumns; i++ {
		columnValue := columnValues[i]

		var bpv *boundParameterValue
		// NOTE: This was included, and is actually a bug:
		// var err error
		//
		if !columnValue.IsValid() {
			// this is only the case if all of the rows for a particular column had nil values
			bpv, err = statement.bindBulkNullValuesForColumn(i, startRow, endRow)
		} else {
			bpv, err = statement.bindBulkRegularParameters(i, columnValue, bulkValues, startRow,
				endRow)
		}

		boundColumns[i] = bpv

		if err != nil {
			break
		}
	}
	return boundColumns, err
}

func (statement *statement) bindBulkNullValuesForColumn(columnIndex int, startRow int,
	endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		bpv.boundStruct.SetNull(outputValueIndex, true)
	}

	bindRes := statement.apiStatement.BindParam(columnIndex, bpv.boundStruct)

	if !bindRes {
		return bpv, statement.conn.getError()
	}

	return bpv, nil
}

func (statement *statement) bindBulkRegularParameters(columnIndex int,
	columnValue reflect.Value, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	var bpv *boundParameterValue
	var err error

	switch columnValue.Kind() {
	case reflect.Uint8:
		fallthrough
	case reflect.Uint16:
		fallthrough
	case reflect.Uint32:
		fallthrough
	case reflect.Uint64:
		fallthrough
	case reflect.Uint:
		bpv, err = statement.bindIntegerBatch(columnIndex, bulkValues, startRow, endRow, false)
	case reflect.Int8:
		fallthrough
	case reflect.Int16:
		fallthrough
	case reflect.Int32:
		fallthrough
	case reflect.Int64:
		fallthrough
	case reflect.Int:
		bpv, err = statement.bindIntegerBatch(columnIndex, bulkValues, startRow, endRow, true)
	case reflect.Float32:
		fallthrough
	case reflect.Float64:
		bpv, err = statement.bindFloatBatch(columnIndex, bulkValues, startRow, endRow)
	case reflect.Bool:
		bpv, err = statement.bindBooleanBatch(columnIndex, bulkValues, startRow, endRow)
	case reflect.String:
		bpv, err = statement.bindStringBatch(columnIndex, bulkValues, startRow, endRow)
	case reflect.Slice:
		if _, ok := columnValue.Interface().([]byte); ok {
			bpv, err = statement.bindByteArrayBatch(columnIndex, bulkValues, startRow, endRow)
		} else {
			bpv, err = statement.handleBulkNonByteSliceInputParameterBatch(columnIndex, columnValue, bulkValues, startRow, endRow)
		}
	default: {
		if _, ok := columnValue.Interface().(time.Time); ok {
			// Time batch (validated in rowCanBeIncludedInBatch())
			bpv, err = statement.bindTimeBatch(columnIndex, bulkValues, startRow, endRow)
		}
	}
	}

	if err != nil {
		return bpv, err
	}

	bindRes := statement.apiStatement.BindParam(columnIndex, bpv.boundStruct)

	if !bindRes {
		return bpv, statement.conn.getError()
	}
	return bpv, nil
}

func (statement *statement) initializeBatchBoundParameterValuesForColumn(columnIndex int,
	batchSize int) (*boundParameterValue, error) {
	return statement.initializeBatchBoundParameterValuesForColumnInternal(columnIndex,
		batchSize, false)
}

func (statement *statement) initializeBatchBoundParameterValuesForColumnInternal(columnIndex int,
	batchSize int, forDataAtExecute bool) (*boundParameterValue, error) {
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv := new(boundParameterValue)
	bpv.isBatch = true
	bpv.batchSize = uint64(batchSize)
	bindData, ok := statement.apiStatement.DescribeBindParam(columnIndex)
	bpv.boundStruct = bindData

	if !ok {
		return bpv, statement.conn.getError()
	}

	bindData.InitializeBuffers(uintptr(batchSize), true, forDataAtExecute)
	return bpv, nil
}

func (statement *statement) bindIntegerBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int, signed bool) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	if signed {
		bpv.boundStruct.SetType(api.A_VAL64)
	} else {
		bpv.boundStruct.SetType(api.A_UVAL64)
	}

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			if signed {
				iVal := (*cstd.Int64)(cstd.Malloc(cstd.SizeofInt64))
				*iVal = cstd.Int64(theValue.Int())
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(iVal), uintptr(cstd.SizeofInt64))
			} else {
				iVal := (*cstd.UInt64)(cstd.Malloc(cstd.SizeofUInt64))
				*iVal = cstd.UInt64(theValue.Uint())
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(iVal), uintptr(cstd.SizeofUInt64))
			}
		}
	}

	return bpv, nil
}

func (statement *statement) bindFloatBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_DOUBLE)

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			dVal := (*cstd.Double)(cstd.Malloc(cstd.SizeofDouble))
			*dVal = cstd.Double(theValue.Float())
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(dVal), uintptr(cstd.SizeofDouble))
		}
	}

	return bpv, nil
}

func (statement *statement) bindBooleanBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_VAL8)

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			bVal := (*cstd.UInt8)(cstd.Malloc(cstd.SizeofUInt8))
			if theValue.Bool() {
				*bVal = cstd.UInt8(1)
			} else {
				*bVal = cstd.UInt8(0)
			}
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(bVal), uintptr(cstd.SizeofUInt8))
		}
	}

	return bpv, nil
}

func (statement *statement) bindStringBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_STRING)

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(cstd.CString(theValue.String())),
				uintptr(len(theValue.String())))
		}
	}

	return bpv, nil
}

func (statement *statement) bindByteArrayBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_BINARY)

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		// The check for this is a []byte done earlier [in isAcceptableInputParameterType()],
		// here we just use the value here
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			bArrLen := len(theValue.Bytes())
			var bArrVal *cstd.Char

			if bArrLen > 0 {
				bArrVal = (*cstd.Char)(cstd.Malloc(cstd.Size_t(bArrLen)))
				cstd.Memcpy(unsafe.Pointer(bArrVal), unsafe.Pointer(&theValue.Bytes()[0]),
					cstd.Size_t(bArrLen))
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(bArrVal),
					uintptr(bArrLen))
			} else {
				a := make([]byte, 1)
				bArrVal = (*cstd.Char)(cstd.Malloc(cstd.Size_t(1)))
				cstd.Memcpy(unsafe.Pointer(bArrVal), unsafe.Pointer(&a[0]), cstd.Size_t(1))
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(bArrVal),
					uintptr(1))
			}
		}
	}

	return bpv, nil
}

func (statement *statement) handleBulkNonByteSliceInputParameterBatch(index int, v reflect.Value,
	bulkValues [][]interface{}, startRow int, endRow int) (*boundParameterValue, error) {
    var bpv *boundParameterValue
	batchSize := endRow - startRow + 1
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(index, batchSize)
	paramInfo := statement.retrieveParamInfo(index)

	if paramInfo == nil {
		return bpv, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_PARAM_INFO_I, index))
	}
	_ = bulkValues

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_BINARY)

	if _, ok := v.Interface().([]float32); ok {
		if statement.isRealVectorColumn(paramInfo) {
			err = statement.addFloat32SliceInputParameterBatchValuesForRealVectorColumn(index,
				paramInfo, bpv, bulkValues, startRow, endRow)

			return bpv, err
		} else if statement.isHalfVectorColumn(paramInfo) {
			err = statement.addFloat32SliceInputParameterBatchValuesForHalfVectorColumn(index,
				paramInfo, bpv, bulkValues, startRow, endRow)

			return bpv, err
		}
	} else if _, ok := v.Interface().([]float64); ok {
		if statement.isRealVectorColumn(paramInfo) {
			err = statement.addFloat64SliceInputParameterBatchValuesForRealVectorColumn(index,
				paramInfo, bpv, bulkValues, startRow, endRow)

			return bpv, err
		} else if statement.isHalfVectorColumn(paramInfo) {
			err = statement.addFloat64SliceInputParameterBatchValuesForHalfVectorColumn(index,
				paramInfo, bpv, bulkValues, startRow, endRow)

			return bpv, err
		}
	}

	return bpv,	 newError(newGoDriverError(DRIVER_ERROR_UNKNOWN_TYPE))
}

func (statement *statement) addFloat32SliceInputParameterBatchValuesForRealVectorColumn(
	columnIndex int, paramInfo api.ParameterInfo, bpv *boundParameterValue,
	bulkValues [][]interface{}, startRow int, endRow int) error {
	dataSize := uint32(unsafe.Sizeof(uint32(0)))

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		_ = outputValueIndex
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			// Should be valid as verified earlier
			arrayValues, _ := theValue.Interface().([]float32)
			numberOfValues := len(arrayValues)
			theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))

			if paramInfo.Precision() == 0 { // Unconstrained column
				if numberOfValues > api.GetSuggestedUnconstrainedRealVectorDimension() {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_IN_BATCH_IIII,
						startRow, columnIndex, numberOfValues, api.GetSuggestedUnconstrainedRealVectorDimension()))
				}
			} else if (paramInfo.Precision() != uint16(numberOfValues))	{
				return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_REALVECTOR_SIZE_IN_BATCH_IIII,
					startRow, columnIndex, numberOfValues, int(paramInfo.Precision())))
			}

			statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

			// Loop through and get the values
			for rowIndex := 1; rowIndex <= numberOfValues; rowIndex++ {
				floatValue := arrayValues[rowIndex - 1]
				rawIntValue := *(*uint32)(unsafe.Pointer(&floatValue))
				valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
					uintptr(cstd.SizeofChar)*uintptr(rowIndex)*uintptr(dataSize)))
				statement.addBinary32ValueToVectorCBuffer(rawIntValue, valueLocation)
			}
		}
	}

	return nil
}

func (statement *statement) addFloat64SliceInputParameterBatchValuesForRealVectorColumn(
	columnIndex int, paramInfo api.ParameterInfo, bpv *boundParameterValue,
	bulkValues [][]interface{}, startRow int, endRow int) error {
	dataSize := uint32(unsafe.Sizeof(uint32(0)))

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		_ = outputValueIndex
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			// Should be valid as verified earlier
			arrayValues, _ := theValue.Interface().([]float64)
			numberOfValues := len(arrayValues)
			theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))

			if paramInfo.Precision() == 0 { // Unconstrained column
				if numberOfValues > api.GetSuggestedUnconstrainedRealVectorDimension() {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_REALVECTOR_SIZE_IN_BATCH_IIII,
						startRow, columnIndex, numberOfValues, api.GetSuggestedUnconstrainedRealVectorDimension()))
				}
			} else if (paramInfo.Precision() != uint16(numberOfValues))	{
				return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_REALVECTOR_SIZE_IN_BATCH_IIII,
					startRow, columnIndex, numberOfValues, int(paramInfo.Precision())))
			}

			statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

			// Loop through and get the values
			for rowIndex := 1; rowIndex <= numberOfValues; rowIndex++ {
				if arrayValues[rowIndex - 1] > maxRealVectorValue ||
					arrayValues[rowIndex - 1] < minRealVectorValue {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_REALVECTOR_VALUE_OUT_OF_RANGE_IIS,
						columnIndex, rowIndex, arrayValues[rowIndex -1]))
				}

				floatValue := float32(arrayValues[rowIndex - 1])
				rawIntValue := *(*uint32)(unsafe.Pointer(&floatValue))
				valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
					uintptr(cstd.SizeofChar)*uintptr(rowIndex)*uintptr(dataSize)))
				statement.addBinary32ValueToVectorCBuffer(rawIntValue, valueLocation)
			}
		}
	}

	return nil
}

func (statement *statement) addFloat32SliceInputParameterBatchValuesForHalfVectorColumn(
	columnIndex int, paramInfo api.ParameterInfo, bpv *boundParameterValue,
	bulkValues [][]interface{}, startRow int, endRow int) error {
	lengthSize := uint32(unsafe.Sizeof(uint32(0)))
	dataSize := uint32(unsafe.Sizeof(uint16(0)))

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		_ = outputValueIndex
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			// Should be valid as verified earlier
			arrayValues, _ := theValue.Interface().([]float32)
			numberOfValues := len(arrayValues)
			theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))

			if paramInfo.Precision() == 0 { // Unconstrained column
				if numberOfValues > api.GetSuggestedUnconstrainedHalfVectorDimension() {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_IN_BATCH_IIII,
						startRow, columnIndex, numberOfValues, api.GetSuggestedUnconstrainedHalfVectorDimension()))
				}
			} else if (paramInfo.Precision() != uint16(numberOfValues))	{
				return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_IN_BATCH_IIII,
					startRow, columnIndex, numberOfValues, int(paramInfo.Precision())))
			}

			statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

			// Loop through and get the values
			for rowIndex := 0; rowIndex < numberOfValues; rowIndex++ {
                if arrayValues[rowIndex] > maxPositiveNormalizedFloat16 ||
                    arrayValues[rowIndex] < minNegativeNormalizedFloat16 {
                    return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS,
                        columnIndex, rowIndex, arrayValues[rowIndex]))
                }
                float32Value := arrayValues[rowIndex]
                valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
                    uintptr(cstd.SizeofChar)*(uintptr(lengthSize) + uintptr(rowIndex)*uintptr(dataSize))))
                statement.addFloat32ValueAsBinary16ToVectorCBuffer(float32Value, valueLocation)
			}
		}
	}

	return nil
}

func (statement *statement) addFloat64SliceInputParameterBatchValuesForHalfVectorColumn(
	columnIndex int, paramInfo api.ParameterInfo, bpv *boundParameterValue,
	bulkValues [][]interface{}, startRow int, endRow int) error {
	lengthSize := uint32(unsafe.Sizeof(uint32(0)))
	dataSize := uint32(unsafe.Sizeof(uint16(0)))

	for i := startRow; i <= endRow; i++ {
		outputValueIndex := i - startRow
		_ = outputValueIndex
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			// Should be valid as verified earlier
			arrayValues, _ := theValue.Interface().([]float64)
			numberOfValues := len(arrayValues)
			theValues, bufferSize := statement.setupCBufferForVectorValues(numberOfValues, dataSize)
			bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(theValues), uintptr(cstd.Size_t(bufferSize)))

			if paramInfo.Precision() == 0 { // Unconstrained column
				if numberOfValues > api.GetSuggestedUnconstrainedHalfVectorDimension() {
					return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_UNCONSTRAINED_HALFVECTOR_SIZE_IN_BATCH_IIII,
						startRow, columnIndex, numberOfValues, api.GetSuggestedUnconstrainedHalfVectorDimension()))
				}
			} else if (paramInfo.Precision() != uint16(numberOfValues))	{
				return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_HALFVECTOR_SIZE_IN_BATCH_IIII,
					startRow, columnIndex, numberOfValues, int(paramInfo.Precision())))
			}

			statement.addBinary32ValueToVectorCBuffer(uint32(numberOfValues), theValues)

			// Loop through and get the values
			for rowIndex := 0; rowIndex < numberOfValues; rowIndex++ {
                if arrayValues[rowIndex] > maxPositiveNormalizedFloat16 ||
                    arrayValues[rowIndex] < minNegativeNormalizedFloat16 {
                    return newError(newGoDriverErrorWithArgs(DRIVER_ERROR_HALFVECTOR_VALUE_OUT_OF_RANGE_IIS,
                        columnIndex, rowIndex, arrayValues[rowIndex]))
                }
                float32Value := float32(arrayValues[rowIndex])
                valueLocation := (*cstd.Char)(unsafe.Add(unsafe.Pointer(theValues),
                    uintptr(cstd.SizeofChar)*(uintptr(lengthSize) + uintptr(rowIndex)*uintptr(dataSize))))
                statement.addFloat32ValueAsBinary16ToVectorCBuffer(float32Value, valueLocation)
			}
		}
	}

	return nil
}

func (statement *statement) bindTimeBatch(columnIndex int, bulkValues [][]interface{},
	startRow int, endRow int) (*boundParameterValue, error) {
	batchSize := endRow - startRow + 1
	// bpv always needs to be returned as the memory is deallocated by the caller using
	// using defer bpv.cleanup()
	bpv, err := statement.initializeBatchBoundParameterValuesForColumn(columnIndex, batchSize)

	if err != nil {
		return bpv, err
	}

	bpv.boundStruct.SetType(api.A_STRING)
	var firstError error

	for i := startRow; i <= endRow; i++ {
		theValue := reflect.ValueOf(bulkValues[i][columnIndex])
		outputValueIndex := i - startRow
		bpv.boundStruct.SetNull(outputValueIndex, !theValue.IsValid())

		if theValue.IsValid() {
			// This validation is always done in rowCanBeIncludedInBatch(), so we can just get the
			// value here
			tVal, _ := theValue.Interface().(time.Time)
			strVal, err := statement.getAdjustedStringValueFromTime(i, columnIndex, tVal)

			if firstError == nil && err != nil {
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(cstd.CString("")),
					uintptr(0))
				// Allow for all values to be evaluated to simplify batch cleanup
				firstError = err
			} else {
				bpv.boundStruct.SetValue(outputValueIndex, unsafe.Pointer(cstd.CString(strVal)),
					uintptr(len(strVal)))
			}
		}
	}

	return bpv, firstError
}

func (statement *statement) getAdjustedStringValueFromTime(rowIndex int, columnIndex int,
	tVal time.Time) (string, error) {
	var insertTimeVal time.Time
	var strVal string

	if statement.conn.dsnInfo.ConvertTimestampToUTC() {
		insertTimeVal = tVal.UTC()
	} else {
		insertTimeVal = tVal
	}

	paramInfo := statement.retrieveParamInfo(columnIndex)

	if paramInfo == nil {
		return strVal, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_NO_PARAM_INFO_I, columnIndex))
	}

	// Server does not support the year = 0 for DATE and TIMESTAMP type columns
	if (insertTimeVal.Year() == 0) &&
		((paramInfo.NativeType() == api.DT_DAYDATE) ||
			(paramInfo.NativeType() == api.DT_DATE) ||
			(paramInfo.NativeType() == api.DT_LONGDATE) ||
			(paramInfo.NativeType() == api.DT_SECONDDATE)) {
		if statement.conn.dsnInfo.ConvertTimestampToUTC() {
			return strVal, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_IISS,
				rowIndex, columnIndex, tVal, insertTimeVal))
		}
		return strVal, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_DATE_IIS,
			rowIndex, columnIndex, insertTimeVal))
	}

	if paramInfo.NativeType() == api.DT_SECONDTIME || // TIME
		paramInfo.NativeType() == api.DT_TIME {
		strVal = insertTimeVal.Format(TIME_LAYOUT_STRING)
	} else if paramInfo.NativeType() == api.DT_DAYDATE || // DATE
		paramInfo.NativeType() == api.DT_DATE {
		strVal = insertTimeVal.Format(DATE_LAYOUT_STRING)
	} else if paramInfo.NativeType() == api.DT_LONGDATE || // TIMESTAMP
		paramInfo.NativeType() == api.DT_SECONDDATE {
		if insertTimeVal.Nanosecond() == 0 {
			strVal = insertTimeVal.Format(SECONDDATE_LAYOUT_STRING)
		} else {
			strVal = insertTimeVal.Format(TS_LAYOUT_STRING)
		}
	} else {
		// Non-DATE|TIME|TIMESTAMP type - let the conversion success/failure be determined by
		// The C layer implementation
		strVal = insertTimeVal.Format(TS_LAYOUT_STRING)
	}
	return strVal, nil
}

// driver.Stmt interface https://pkg.go.dev/database/sql/driver#Stmt
func (statement *statement) NumInput() int {
	// We don't let the sql package handle the validation, since we now support bulk parameters
	// passed in as an array of an array [][] interface{} so we return -1 here
	return -1
}

// driver.Stmt interface https://pkg.go.dev/database/sql/driver#Stmt
func (statement *statement) Query(args []driver.Value) (driver.Rows, error) {
	return statement.queryInternal(context.Background(), args)
}

// driver.StmtQueryContext interface https://pkg.go.dev/database/sql/driver#StmtQueryContext
func (statement *statement) QueryContext(ctx context.Context, args []driver.NamedValue) (driver.Rows, error) {
	value := make([]driver.Value, len(args))

	for i := 0; i < len(args); i++ {
		value[i] = args[i].Value
	}

	return statement.queryInternal(ctx, value)
}

func (statement *statement) queryInternal(ctx context.Context, args []driver.Value) (driver.Rows, error) {
	statement.resetErrors()
	numberOfParameters := len(args)
	expectedNumberOfParams := statement.apiStatement.NumParams()

	if numberOfParameters != expectedNumberOfParams {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_NUMBER_OF_PARAM_II,
			expectedNumberOfParams, numberOfParameters))
	}

	for i := 0; i < len(args); i++ {
		bpv, err := statement.bindParameter(i, args[i])
		if bpv != nil {
			defer bpv.cleanup()
		}

		if err != nil {
			return nil, err
		}
	}

	err := statement.setAPIPropertiesAffectingQuery(ctx)

	if err != nil {
		return nil, err
	}

	defer statement.clearAPIPropertiesSetFromStmtContext()

	err = statement.executeQuery(ctx)

	if err != nil {
		return nil, err
	}

	return statement.newResultSetRows(ctx)
}

func (statement *statement) setAPIPropertiesAffectingQuery(ctx context.Context) error {
// Per-statement properties which are set through dbcapi API calls directly
// before the execute call and which last for the duration of the current excute call
	deadline, ok := ctx.Deadline()

	if ok {
		err := statement.setTimeout(deadline.Sub(time.Now()))
		if err != nil {
			return err
		}
	}

	packetSize, ok := getStmtPacketSizeFromContext(ctx)

	if ok {
		statement.setPacketSize(packetSize)
	}

	return nil
}

func (statement *statement) executeQuery(ctx context.Context) error {
	var execRes bool
	communicationTimeout, ok := getStmtCommunicationTimeoutFromContext(ctx)

	if(ok) {
		execRes = statement.apiStatement.ExecuteWithTimeout(communicationTimeout)
	} else {
		execRes = statement.apiStatement.Execute()
	}
	if !execRes {
		err := statement.conn.getError()

		if err != nil {
			v := reflect.ValueOf(err)
			hanaError, ok := v.Interface().(Error)

			if ok {
				statement.addError(hanaError)
				return statement.errors()
			}

			// Error required for upper layer - return directly
			return err
		}

		return statement.errors()
	}

	return nil
}

func (statement *statement) newResultSetRows(ctx context.Context) (*rows, error) {
	fetchUsingReadLob := getFetchUsingReadLobFromContext(ctx)
	rowsetFetchSize, ok := getFetchSizeFromContext(ctx)
	if ok {
		if rowsetFetchSize == 0 {
			return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_BULK_FETCH_SIZE_S,
				"Could not set fetchsize - the provided value was invalid"))
		}
	}

	statement.setRowsetFetchSize(rowsetFetchSize)
	resultSetRows := &rows{stmt: statement.apiStatement, conn: statement.conn,
		isFromStatement: true, isClosed: false, err: nil, rowsetFetchSize: uint(rowsetFetchSize),
		fetchUsingReadLob: fetchUsingReadLob,
	}

	isBulkFetch := rowsetFetchSize >= 1

	err := resultSetRows.doSetupForFetching(isBulkFetch)

	if err != nil {
		resultSetRows.Close()
		return nil, err
	}

	return resultSetRows, statement.errors()
}

// driver.NameValueChecker interface (https://pkg.go.dev/database/sql/driver#NamedValueChecker)
// CheckNamedValue (from the NamedValueChecker interface) is implemented here to allow our
// custom types implementation
func (statement *statement) CheckNamedValue(nv *driver.NamedValue) error {
	if nv != nil && statement.apiStatement != nil {
		if statement.functionCode == 0 {
			statement.functionCode = statement.apiStatement.GetFunctionCode()
		}

		v := reflect.ValueOf(nv.Value)

		if v.IsValid() {
			if statement.functionCode == api.FunctionCode_INSERT ||
				statement.functionCode == api.FunctionCode_UPDATE ||
				statement.functionCode == api.FunctionCode_DELETE {
				// Special Accepted Type for Bulk Insert/Update/Delete
				if _, ok := v.Interface().([][]interface{}); ok {
					return nil
				// Special Accepted Type for WriteLOB streaming
				} else if _, ok := v.Interface().(*WriteLOB); ok {
					return nil
				// Special Accepted Types for REAL/HALF Vector columns
				} else if _, ok := v.Interface().([]float32); ok {
					return nil
				} else if _, ok := v.Interface().([]float64); ok {
					return nil
				}
			}
		}
	}
	return driver.ErrSkip
}

type driverKey string

// Vendor specific helper functions
const (
	fetchSizeKey = driverKey("fetchsize")
	fetchUsingReadLob = driverKey("fetchUsingReadLob")
	statementCommnicationTimemout = driverKey("statementCommnicationTimemout")
	statementPacketSize = driverKey("statementPacketSize")
)

// ErrorHolder interface
func (statement *statement) resetErrors() {
	statement.theErrors = nil
}

func (statement *statement) errors() error {
	if statement.theErrors != nil && statement.theErrors.NumberOfErrors() > 0 {
		return statement.theErrors
	}

	return nil
}

func (statement *statement) addError(theError Error) {
	if statement.theErrors == nil {
		statement.theErrors = newError(theError)
	} else {
		statement.theErrors.add(theError)
	}
}
//^^ErrorHolder interface
// api.WarningHolder type interface
func (statement *statement) AddWarning(warningCode int, warningMessage string,
	sqlState string) {
	newWarning := newDriverError(warningCode, warningMessage, ErrorLevel_Warning,
		sqlState)
	statement.addError(newWarning)
}
//^^ api.WarningHolder type interface

// Communication Timeout
// Bulk Fetching
func NewFetchSizeContext(ctx context.Context, fetchSize uint) (context.Context, error) {
	if fetchSize == 0 {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_BULK_FETCH_SIZE_S,
			"Provided fetch size must be >= 1"))
	}

	return context.WithValue(ctx, fetchSizeKey, fetchSize), nil
}

func getFetchSizeFromContext(ctx context.Context) (uint, bool) {
	fetchSize, ok := ctx.Value(fetchSizeKey).(uint)
	return fetchSize, ok
}

func (statement *statement) setRowsetFetchSize(rowsetFetchSize uint) error {
	if rowsetFetchSize > 1 {
		ok := statement.apiStatement.SetRowsetSize(rowsetFetchSize)

		if !ok {
			return statement.conn.getError()
		}
	}

	return nil
}

func (statement *statement) setTimeout(timeout time.Duration) error {
	//Add +1 since float64 to int32 will cause some loss in precision
	timeoutRes := statement.apiStatement.SetQueryTimeout(timeout)

	if !timeoutRes {
		return statement.conn.getError()
	}

	return nil
}

func (statement *statement) unsetTimeout() {
	_ = statement.apiStatement.UnsetQueryTimeout()
}


// By default we use no Communication Timeout
func NewCommunicationTimeoutStmtContext(ctx context.Context, communicationTimeout time.Duration) (context.Context, error) {
	if communicationTimeout.Milliseconds() < 0 ||
		communicationTimeout.Milliseconds() > int64(math.MaxUint32) {
		return nil, newError(newGoDriverError(DRIVER_ERROR_INVALID_COMMUNICATION_TIMEOUT))
	}

	return context.WithValue(ctx, statementCommnicationTimemout, communicationTimeout), nil
}

func getStmtCommunicationTimeoutFromContext(ctx context.Context) (time.Duration, bool) {
	communicationTimeout, ok := ctx.Value(statementCommnicationTimemout).(time.Duration)
	return communicationTimeout, ok
}

func NewPacketSizeStmtContext(ctx context.Context, packetSize uint32) (context.Context, error) {
	// TODO: Enforce MIN and MAX Packet Size from SQLDBC
	if packetSize < uint32(MIN_PACKETSIZE) ||
		packetSize > uint32(MAX_PACKETSIZE) {
		return nil, newError(newGoDriverErrorWithArgs(DRIVER_ERROR_INVALID_PACKET_SIZE,
			MIN_PACKETSIZE, MAX_PACKETSIZE))
	}

	return context.WithValue(ctx, statementPacketSize, packetSize), nil
}

func getStmtPacketSizeFromContext(ctx context.Context) (uint32, bool) {
	packetSize, ok := ctx.Value(statementPacketSize).(uint32)
	return packetSize, ok
}

func (statement *statement ) setPermanentPacketSize(ctx context.Context) {
	packetSize, ok := getStmtPacketSizeFromContext(ctx)

	if ok {
		statement.packetSize = new(uint32)
		*statement.packetSize = packetSize
		statement.setPacketSize(packetSize)
	}
}

func (statement *statement ) setPacketSize(packetSize uint32) {
	statement.apiStatement.SetPacketSize(uint(packetSize))
}

func (statement *statement ) unsetPacketSize() {
	// 0 = unset in the underlying C library
	packetSize := uint32(0)

	if statement.packetSize != nil {
		packetSize = *statement.packetSize
	}

	statement.apiStatement.SetPacketSize(uint(packetSize))
}

// ReadLOB Stream Fetching
func NewReadLobFetchContext(ctx context.Context) (context.Context) {
	return context.WithValue(ctx, fetchUsingReadLob, true)
}

func getFetchUsingReadLobFromContext(ctx context.Context) bool {
	fetchUsingReadLob, ok := ctx.Value(fetchUsingReadLob).(bool)

	if !ok {
		fetchUsingReadLob = false
	}

	return fetchUsingReadLob
}

func (statement *statement) hasWriteLOBs() bool {
	return (statement.functionCode == api.FunctionCode_DELETE ||
		statement.functionCode == api.FunctionCode_INSERT ||
		statement.functionCode == api.FunctionCode_UPDATE) && (len(statement.storedWriteLobs) > 0)
}

func (statement *statement) storeLOBForColumnOfSingleRow(columnIndex uint, lob *WriteLOB) {
	statement.storeLOBForColumn(0, columnIndex, lob)
}

func (statement *statement) storeLOBForColumn(rowIndex uint, columnIndex uint, lob *WriteLOB) {
	rowWriteLOBColumnsList, ok := statement.storedWriteLobs[rowIndex]

	if !ok {
		rowWriteLOBColumnsList = list.New()
		statement.storedWriteLobs[rowIndex] = rowWriteLOBColumnsList
	}

	lob.setParameterIndex(columnIndex)
	rowWriteLOBColumnsList.PushBack(lob)
}

func (statement *statement) clearLOBs() {
	// We don't care about the sequencing of rows here - this close() is just
	// reseting the actual WriteLOB object internally, it is not sending any
	// protocol information
	for rowIndex, rowWriteLOBColumnsList := range statement.storedWriteLobs {
		for el := rowWriteLOBColumnsList.Front(); el != nil; el = el.Next() {
			val := reflect.ValueOf(el.Value)

			if val.IsValid() {
				writeLOB, ok := val.Interface().(*WriteLOB)

				if ok {
					writeLOB.close()
				}
			}
		}

		statement.storedWriteLobs[rowIndex] = nil
	}
}

// NOTE: We are doing regular loop by index from 0 here since we know that
// map indices are stored as sequential row indices starting from 0,
// but we don't know if iteration of the map via regular means
// will be in order of the row indices
// Lobs are therefore guaranteed to be processed in increasing order of
// increasing row indices, and for a particular row index, in increasing
// order of column indices.
// This is also being done sequentially. If in future, the server allows for
// concurrent sending of data, this can be modified to process multiple
// WriteLOBs in parallel
func (statement *statement) sendDataFromWriteLOBs() error {
	var err error

	for rowIndex := 0; rowIndex <  len(statement.storedWriteLobs); rowIndex++ {
		rowWriteLOBColumnsList := statement.storedWriteLobs[uint(rowIndex)]

		for el := rowWriteLOBColumnsList.Front(); el != nil; el = el.Next() {
			val := reflect.ValueOf(el.Value)

			if val.IsValid() {
				lobValue, ok := val.Interface().(*WriteLOB)

				if ok {
					if err != nil {
						// Close the other Lobs before returning the error,
						// otherwise the other writers from the producer will continue
						// to block that thread forever!
						lobValue.close()
					} else {
						err = statement.processWriteLOB(lobValue)
					}
				}
			}
		}
	}

	// Reset the storedWriteLobs list to be in case future usages of the statement
	// use different LOBs
	statement.storedWriteLobs = make(map[uint]*list.List)
	return err
}

func (statement *statement) processWriteLOB(writeLOB *WriteLOB) error {
	defer writeLOB.close()
	return writeLOB.sendInputParameterData(statement)
}

// Currently unused
func (statement *statement) clearContextProperties() error {
	statement.apiStatement.Free()

	if statement.boundParameterInfos != nil {
		statement.boundParameterInfos.cleanup()
	}

	if statement.hasWriteLOBs() {
		statement.clearLOBs()
	}

	statement.resetErrors() // Already returned from Query[Context]/Exec[Context]
	if statement.conn.dsnInfo.ReportWarningsWithErrors() {
		statement.conn.apiConnection.RemoveWarningCallback()
	}

	return nil
}

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ api.WarningHolder = (*statement)(nil)
)
