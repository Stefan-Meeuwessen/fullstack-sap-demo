package api

/*
#cgo CFLAGS: -I${SRCDIR}/../../includes
#cgo LDFLAGS: -Wl,-rpath,\$ORIGIN
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "DBCAPI_DLL.h"
#include "DBCAPI.h"
*/
import "C"
import (
	"time"
	"unsafe"
	cstd "SAP/go-hdb/driver/internal/cstd"
)

// Note: This is just meant to be an API object to wrap the C layer API
// So conventional Go idioms for error handling are NOT followed here.
// It is expected that a Go object will wrap/contain/use this object's
// API within a more Go idiomatic API.
// This allows for API testing to be done as well, through the interface provide
// here
type Statement interface {
	Free()
	Reset() bool
	GetFunctionCode() FunctionCode
	RowsAffected() int
	NumColumns() (int, bool)
	SetRowsetSize(rowsetFetchSize uint) bool
	GetData(index uint, offset uintptr, dataBuffer unsafe.Pointer, dataBufferLength uintptr) int
	GetDataInfo(index uint) (DataInfo, bool)
	GetColumnInfo(index int) (ColumnInfo, bool)
	BindColumn(index int, column DataValue) bool
	GetColumn(index int) (DataValue, bool)
	FetchNext() bool
	HasNextResult() bool
	GetNextResult() bool
	FetchedRows() (int, bool)
}

type APIStatement struct {
	apiStatement *CApiStmt
}

func newAPIStatement(apiStatement *CApiStmt) *APIStatement {
	return &APIStatement{apiStatement: apiStatement}
}

func (statement *APIStatement) Free() {
	C.dbcapi_free_stmt(statement.apiStatement)
}

func (statement *APIStatement) Reset() bool {
	closeRowsRes := C.dbcapi_reset(statement.apiStatement)
	return closeRowsRes == 1
}

func (statement *APIStatement) GetFunctionCode() FunctionCode {
	return (FunctionCode)(C.dbcapi_get_function_code(statement.apiStatement))
}

func (statement *APIStatement) RowsAffected() int {
	return (int)(C.dbcapi_affected_rows(statement.apiStatement))
}

func (statement *APIStatement) NumColumns() (int, bool) {
	var numCols int
	numCols = int(C.dbcapi_num_cols(statement.apiStatement))
	if numCols == -1 {
		return numCols, false
	}

	return numCols, true
}

func (statement *APIStatement) GetData(index uint, offset uintptr,
	dataBuffer unsafe.Pointer, dataBufferLength uintptr) int {
	res := C.dbcapi_get_data(statement.apiStatement, (C.dbcapi_u32)(index),
		(C.size_t)(offset), dataBuffer, (C.size_t)(dataBufferLength));
	return int(res);
}
func (statement *APIStatement) GetDataInfo(index uint) (DataInfo, bool) {
	dataInfo := (*C.struct_dbcapi_data_info)(cstd.Calloc(cstd.Size_t(1), cstd.Size_t(C.sizeof_struct_dbcapi_column_info)))
	dataInfoRes := C.dbcapi_get_data_info(statement.apiStatement, C.dbcapi_u32(index), dataInfo)
	if dataInfoRes == 1 {
		// APIColumnInfo takes ownership of bindData memory
		return newAPIDataInfo(dataInfo), true
	} else {
		cstd.Free(unsafe.Pointer(dataInfo))
		return nil, false
	}
}

func (statement *APIStatement) GetColumnInfo(index int) (ColumnInfo, bool) {
	colInfo := (*C.struct_dbcapi_column_info)(cstd.Calloc(cstd.Size_t(1), cstd.Size_t(C.sizeof_struct_dbcapi_column_info)))
	colInfoRes := C.dbcapi_get_column_info(statement.apiStatement, C.dbcapi_u32(index), colInfo)
	if colInfoRes == 1 {
		// APIColumnInfo takes ownership of bindData memory
		return newAPIColumnInfo(colInfo), true
	} else {
		cstd.Free(unsafe.Pointer(colInfo))
		return nil, false
	}
}

func (statement *APIStatement) GetColumn(index int) (DataValue, bool) {
	col := (*C.struct_dbcapi_data_value)(cstd.Calloc(cstd.Size_t(1), cstd.Size_t(C.sizeof_struct_dbcapi_data_value)))
	getCol := C.dbcapi_get_column(statement.apiStatement, C.dbcapi_u32(index), col)
	if getCol == 1 {
		return newDataValueInternal(col, uintptr(1)), true
	} else {
		cstd.Free(unsafe.Pointer(col))
		return nil, false
	}
}

func (statement *APIStatement) BindColumn(index int, column DataValue) bool {
	ok := C.dbcapi_bind_column(statement.apiStatement, C.dbcapi_u32(index), column.BoundData())
	return ok == CApiBool(1)
}

func (statement *APIStatement) FetchNext() bool {
	fetchNextRes := C.dbcapi_fetch_next(statement.apiStatement)
	return fetchNextRes == 1
}


func (statement *APIStatement) HasNextResult() bool {
	hasNextRs := C.dbcapi_has_next_result(statement.apiStatement)
	return int(hasNextRs) == 1
}

func (statement *APIStatement) GetNextResult() bool {
	nextRs := C.dbcapi_get_next_result(statement.apiStatement)
	return nextRs == 1
}

func (statement *APIStatement) FetchedRows() (int, bool) {
	fetchedRows := int(C.dbcapi_fetched_rows(statement.apiStatement))
	if fetchedRows == -1 {
		return 0, false
	}

	return fetchedRows, true
}

func (statement *APIStatement) SetBatchSize(batchSize uint) bool {
	res := C.dbcapi_set_batch_size(statement.apiStatement, C.dbcapi_u32(batchSize))
	return res == 1
}

func (statement *APIStatement) SetRowsetSize(rowsetFetchSize uint) bool {
	ok := C.dbcapi_set_rowset_size(statement.apiStatement, C.dbcapi_u32(rowsetFetchSize))
	return ok == 1
}

type PreparedStatement interface {
    Statement // Implements all of the statement interface
	NumParams() int
	Execute() bool
	ExecuteWithTimeout(commmunicationTimeout time.Duration) bool
    SetPacketSize(packetSize uint)
	SetBatchSize(packetSize uint) bool
	SetQueryTimeout(timeout time.Duration) bool
	UnsetQueryTimeout() bool
	SendParamData(index uint, data unsafe.Pointer, dataSize int) bool
	FinishParamData(index int) bool
	GetBindParamInfo(index int) (ParameterInfo, bool)
	DescribeBindParam(index int) (BindData, bool)
	BindParam(index int, param BindData) bool
}

type APIPreparedStatement struct {
	*APIStatement // Implements all of the APIStatement interface
}

func newAPIPreparedStatement(apiStatement *CApiStmt) *APIPreparedStatement {
	return &APIPreparedStatement{APIStatement: newAPIStatement(apiStatement)}
}

// Statement Interface
func (statement *APIPreparedStatement) Free() {
	statement.APIStatement.Free()
}

func (statement *APIPreparedStatement) Reset() bool {
	return statement.APIStatement.Reset()
}

func (statement *APIPreparedStatement) GetFunctionCode() FunctionCode {
	return statement.APIStatement.GetFunctionCode()
}

func (statement *APIPreparedStatement) RowsAffected() int {
	return statement.APIStatement.RowsAffected()
}

    func (statement *APIPreparedStatement) NumColumns() (int, bool) {
	return statement.APIStatement.NumColumns()
}

func (statement *APIPreparedStatement) GetData(index uint, offset uintptr,
	dataBuffer unsafe.Pointer, dataBufferLength uintptr) int {
	return statement.APIStatement.GetData(index, offset,
		dataBuffer, dataBufferLength)
}

func (statement *APIPreparedStatement) GetColumnInfo(index int) (ColumnInfo, bool) {
	return statement.APIStatement.GetColumnInfo(index)
}

func (statement *APIPreparedStatement) GetColumn(index int) (DataValue, bool) {
	return statement.APIStatement.GetColumn(index)
}

func (statement *APIPreparedStatement) BindColumn(index int, column DataValue) bool {
	return statement.APIStatement.BindColumn(index, column)
}

func (statement *APIPreparedStatement) FetchNext() bool {
	return statement.APIStatement.FetchNext()
}

func (statement *APIPreparedStatement) GetNextResult() bool {
	return statement.APIStatement.GetNextResult()
}

func (statement *APIPreparedStatement) FetchedRows() (int, bool) {
	return statement.APIStatement.FetchedRows()
}

func (statement *APIPreparedStatement) SetRowsetSize(rowsetFetchSize uint) bool {
	return statement.APIStatement.SetRowsetSize(rowsetFetchSize)
}
//^^ Statement interface

// PreparedStatement Interface
func (statement *APIPreparedStatement) NumParams() int {
	return int(C.dbcapi_num_params(statement.APIStatement.apiStatement))
}

func (statement *APIPreparedStatement) Execute() bool {
	execRes := C.dbcapi_execute(statement.APIStatement.apiStatement)
	return execRes == 1
}

func (statement *APIPreparedStatement) ExecuteWithTimeout(communicationTimeout time.Duration) bool {
	execRes := C.dbcapi_execute2(statement.APIStatement.apiStatement,
		C.dbcapi_u32(communicationTimeout.Milliseconds()))
	return execRes == 1
}

func (statement *APIPreparedStatement) SendParamData(index uint, data unsafe.Pointer, dataSize int) bool {
	res := C.dbcapi_send_param_data(statement.APIStatement.apiStatement, C.dbcapi_u32(index),
		(*C.char)(data), C.size_t(dataSize))
	return res == 1
}

func (statement *APIPreparedStatement) FinishParamData(index int) bool {
	res := C.dbcapi_finish_param_data(statement.APIStatement.apiStatement, C.dbcapi_u32(index))
	return res == 1
}

func (statement *APIPreparedStatement) DescribeBindParam(index int) (BindData, bool) {
	bindData := (*C.struct_dbcapi_bind_data)(cstd.Calloc(cstd.Size_t(1), cstd.Size_t(C.sizeof_struct_dbcapi_bind_data)))
	descRes := C.dbcapi_describe_bind_param(statement.APIStatement.apiStatement, C.dbcapi_u32(index),
		bindData)
	if descRes == 1 {
		// APIBindData takes ownership of bindData memory
		return newAPIBindData(bindData), true
	} else {
		cstd.Free(unsafe.Pointer(bindData))
		return nil, false
	}
}

func (statement *APIPreparedStatement) GetBindParamInfo(index int) (ParameterInfo, bool) {
	paramInfo := (*C.dbcapi_bind_param_info)(cstd.Calloc(cstd.Size_t(1), cstd.Size_t(C.sizeof_struct_dbcapi_bind_param_info)))
	paramInfoResult := C.dbcapi_get_bind_param_info(statement.APIStatement.apiStatement, C.dbcapi_u32(index), paramInfo)
	if paramInfoResult == 1 {
		// APIParameterInfo takes ownership of bindData memory
		return newAPIParameterInfo(paramInfo), true
	} else {
		cstd.Free(unsafe.Pointer(paramInfo))
		return nil, false
	}
}

func (statement *APIPreparedStatement) BindParam(index int, param BindData) bool {
	bindRes := C.dbcapi_bind_param(statement.APIStatement.apiStatement, C.dbcapi_u32(index), param.BoundData())
	return int(bindRes) == 1
}

func (statement *APIPreparedStatement) SetPacketSize(packetSize uint) {
	C.dbcapi_set_stmt_packet_size(statement.APIStatement.apiStatement, C.dbcapi_i32(packetSize))
}


func (statement *APIPreparedStatement) SetBatchSize(batchSize uint) bool {
	res := C.dbcapi_set_batch_size(statement.APIStatement.apiStatement, C.dbcapi_u32(batchSize))
	return res == 1
}

// func (statement *APIPreparedStatement) SetRowsetSize(rowsetFetchSize uint) bool {
// 	return statement.APIStatement.SetRowsetSize(rowsetFetchSize)
// }

func (statement *APIPreparedStatement) SetQueryTimeout(timeout time.Duration) bool {
	// NOTE: This is a carry-over from the initial implementation:
	//Add +1 since float64 to int32 will cause some loss in precision
	timeoutRes := C.dbcapi_set_query_timeout(statement.APIStatement.apiStatement, C.dbcapi_i32(timeout.Seconds()+1))
	return timeoutRes == 1
}

func (statement *APIPreparedStatement) UnsetQueryTimeout() bool {
	timeoutRes := C.dbcapi_set_query_timeout(statement.APIStatement.apiStatement, C.dbcapi_i32(0))
	return timeoutRes == 1
}
//^^ PreparedStatement Interface

// Explicitly delcare that the concrete type pointers implement the interfaces
var (
	_ Statement                     = (*APIStatement)(nil)
	_ Statement                     = (*APIPreparedStatement)(nil)
	_ PreparedStatement             = (*APIPreparedStatement)(nil)
)
