package BuildPackage::SplitTools;

use strict;
use warnings;
use Exporter;
use SDB::Install::Globals qw($gUstarMaxSize);
use BuildPackage::Tools;
use File::Basename        qw (basename);
use File::stat;
use IO::File;
use SDB::Common::BuiltIn;
use bigint qw(hex);

use parent qw (Exporter);

use constant DEFAULT_BLOCK_SIZE => 10048576;

our @EXPORT = qw (splitFileInArchives);

sub splitFileInArchives {
    my (
        $index,     $archive,       $file,  $pigz,
        $threads,   $pigzRsyncable, $pmask, $pData,
        $filesList, $splitSize 
    ) = @_;
    my ( $fileType, @fileProperties ) = @$file;
    my $actualFilePath  = $fileProperties[0];
    my $archiveFilePath = $fileProperties[1];

    if( !defined $archiveFilePath || length($archiveFilePath) == 0 ){
        BuildPackage::Tools::error("Archive file path cannot be empty");
        return undef;
    }

     if( !defined $actualFilePath || length($actualFilePath) == 0 ){
        BuildPackage::Tools::error("File path cannot be empty");
        return undef;
    }

    if ( $fileType != 0 ) {
        BuildPackage::Tools::error("'$archiveFilePath' is not a file");
        return undef;
    }

    my $originalFileSize = _getFileSize($actualFilePath, 1 );
    if(!defined $originalFileSize){
        return undef;
    }
    my $originalFileSizeInHex = sprintf( "%x", $originalFileSize );


    my $originalFileChecksum = BuildPackage::Tools::getMD5Sum($actualFilePath);
    if ( !defined $originalFileChecksum ) {
        return undef;
    }
    my $originalFileMode = _getFileMode( $archiveFilePath, $filesList );
    if ( !defined $originalFileMode ) {
        return undef;
    }

    my $fh = IO::File->new( $actualFilePath, 'r' );
    if ( !defined $fh ) {
        BuildPackage::Tools::error(
            "... Error, cannot open file '$actualFilePath': $!");
        return undef;
    }
    $fh->binmode();

    my $partIndex    = sprintf( "%04d", 1 );
    my $archiveIndex = sprintf( "%04d", $index );
    my $eof = 0;
    while (!$eof) {
        my $splitFileName = $actualFilePath . $partIndex;
        while ( !$eof && _getFileSize( $splitFileName, 0 ) < $splitSize ) {
            my $bufferSize = _getBlockSize( $splitFileName, $splitSize );
            my $buffer;
            my $bytesRead  = _read( $fh, \$buffer, $bufferSize );
            if ( !defined $bytesRead ) {
                BuildPackage::Tools::error(
                    "Cannot read binary data from '$actualFilePath'");
                return undef;
            }
            if ( $bytesRead == 0 ) {
                $eof = 1;
                last;
            }

        # Create temporary file for every split as gnutar requires existing file
        # in order to add it to the archive
            if ( !_write( $splitFileName, $buffer ) ) {
                BuildPackage::Tools::error(
                    "Cannot write binary data to '$splitFileName'");
                return undef;
            }
        }
        last if (_getFileSize( $splitFileName, 0 ) == 0);

        BuildPackage::Tools::info(
                "File $splitFileName has been created with size "
              . _getFileSize( $splitFileName, 1 )
              . " bytes" );

        my $gnutar = BuildPackage::Tools::createGnuTarFileHandle( $pigz, $threads,
            $pigzRsyncable );
        my $splitArchive = $archive . $archiveIndex;
        if ( !defined $gnutar->OpenArchive( $splitArchive, 'w', $pmask ) ) {
            BuildPackage::Tools::error( "... Error, cannot create archive $splitArchive:$!" );
            return undef;
        }

        my $splitArchiveLst =
          BuildPackage::Tools::createArchiveLst($splitArchive);
        if ( !defined $splitArchiveLst ) {
            BuildPackage::Tools::error( "... Error, cannot create  $splitArchive.lst :$!" );
            return undef;
        }
        my $lstFiles = [$splitArchiveLst];

        # Create metadata
        my $pDataForPart =
          _createPackageMetadataForPart( $pData, $actualFilePath, $partIndex,
            $originalFileSizeInHex, $originalFileChecksum, $originalFileMode, $splitSize );
        if ( !defined $pDataForPart
            || !BuildPackage::Tools::addPackageMetadata(
                $pDataForPart, $gnutar, $splitArchive, $lstFiles ) ) {
            BuildPackage::Tools::error( "... Error, cannot create PACKAGEDATA for $splitArchive:$!" );
            return undef;
        }

        # Create files.lst
        my $fileListForPart =
          _createFilesLstForPart( $actualFilePath, $archiveFilePath,
            $partIndex, $filesList );
        if ( !defined $fileListForPart
            || !BuildPackage::Tools::addFilesLst(
                $fileListForPart, $gnutar, $splitArchive, $lstFiles ) ) {
            BuildPackage::Tools::error( "... Error, cannot create files.lst for $splitArchive:$!" );
            return undef;
        }

        # Create empty script.pm
        my $scriptContent = "1;" . "\n";
        if ( !BuildPackage::Tools::addScriptPm(
                $scriptContent, $gnutar, $splitArchive, $lstFiles, 1 ) ) {
            BuildPackage::Tools::error( "... Error, cannot create script.pm for $splitArchive:$!" );
            return undef;
        }

        # Add split content
        my (@splitFileContent);
        push( @splitFileContent, $actualFilePath . $partIndex );
        push( @splitFileContent, $archiveFilePath . $partIndex );
        if ( !BuildPackage::Tools::addFile(
                \@splitFileContent, $gnutar, $splitArchive, $lstFiles ) ) {
            BuildPackage::Tools::error( "... Error, cannot add file in $splitArchive:$!" );
            return undef;
        }

        #delete temp file
        SDB::Common::BuiltIn->get_instance()->unlink($splitFileName);

        if ( !defined $gnutar->CloseArchive() ) {
            BuildPackage::Tools::error(
                "... Error, cannot close archive '$splitArchive': $!");
            return undef;
        }

        BuildPackage::Tools::info(
            "... OK, Created split archive $splitArchive with $archiveFilePath$partIndex"
        );

        $partIndex++;
        $archiveIndex++;
    }

    $fh->close();
    return $archiveIndex;
}

#Used for test isolation as FSMock cannot mock buffered reading
sub _read {
    my ( $fh, $buffer, $size ) = @_;
    return $fh->read( $$buffer, $size );
}

sub _write {
    my ( $splitFileName, $data ) = @_;
    my $fh = IO::File->new( $splitFileName, 'a' );
    if ( !defined $fh ) {
        BuildPackage::Tools::error(
            "... Error, cannot open file '$splitFileName': $!");
        return undef;
    }
    $fh->binmode();
    $fh->syswrite($data);
    $fh->close();
    return 1;
}


sub _createPackageMetadataForPart {
    my (
        $packageData,  $filePath, $partIndex, $originalFileSize,
        $originalFileChecksum, $originalFileMode, $splitSize
    ) = @_;

    my $fileName = basename($filePath);

    my $size = _getFileSize( $filePath . $partIndex , 1 );
    if ( !defined $size ) {
        return undef;
    }
    my $checksum = BuildPackage::Tools::getMD5Sum( $filePath . $partIndex );
    my $nextPart;
    if ( hex($originalFileSize) - $partIndex * $splitSize  > 0 ) {
        $nextPart = $fileName . sprintf( "%04d", $partIndex + 1 );
    }

    my @newPackageDataLines = ();
    foreach my $line ( split( "\n", $packageData ) ) {
        next if $line !~ /\S/;
        next if $line =~ /^\s*#/;
        my ( $key, $value ) = ( $line =~ /(\S+)\s+=\s+"(.*)"/ );
        if ( defined $key && $key eq "ID" ) {
            my $fileNameId =
              $fileName =~
              s/\.|-/_/gr;    # replace ./- with _ as . they are special characters

            my $idValue = $value . "_" . $fileNameId . sprintf( "%04d", $partIndex );
            my $id = 'ID = "' . $idValue . '"';
            push(@newPackageDataLines , $id);

            # If not first part add firstPart as conditional requirement to extract in correct order
            if ( $partIndex > 1 ) {
                my $previousPartPkgId = $value . "_" . $fileNameId . sprintf( "%04d", $partIndex - 1 );
                my $requireConditional =  'REQUIRE_CONDITIONAL = "'. $previousPartPkgId . '"';
                push(@newPackageDataLines , $requireConditional);
            }
        }

        # Add existing required packages
        if ( defined $key
            && $key eq "REQUIRE_CONDITIONAL" )
        {
            if ( $partIndex == 1 ) {
                my $requireConditional =  $key . ' = "' . $value . '"';
                push(@newPackageDataLines , $requireConditional);
            }
        }
        if ( defined $key && $key eq "NAME" ) {
            my $nameValue = $value . " ". $fileName. " part " . $partIndex;
            my $name = 'NAME = "' . $nameValue . '"';
            push(@newPackageDataLines , $name);
        }
        if ( defined $key && $key eq "SIZE" ) {
            my $sizeLine = 'SIZE = "' . $size . '"';
            push(@newPackageDataLines , $sizeLine);
        }
        if ( defined $key && $key eq "CHECKSUM" ) {
             my $checksumLine = 'CHECKSUM = "' . $checksum . '"';
             push(@newPackageDataLines , $checksumLine);
        }
        if ( defined $key
            && $key =~
/^(INTERFACE_VERSION|VERSION|BUILD_STRING|IS_GLOBAL|GIT_HASH|IS_CLIENT_PACKAGE|DESC|REQUIRE|)$/
          )
        {
            push(@newPackageDataLines , $line);
        }
    }
    if ( defined $nextPart ) {
        my $nextPartLine = 'NEXT_PART = "' . $nextPart . '"';
        push(@newPackageDataLines , $nextPartLine);
    }
    else {
        my $numberOfParts = 'NUMBER_OF_PARTS = "' . $partIndex . '"';
        push(@newPackageDataLines , $numberOfParts);
    }

    my $partLine = 'PART = "' . $fileName. sprintf( "%04d", $partIndex ) . '"';
    push(@newPackageDataLines , $partLine);

    push(@newPackageDataLines , 'IS_PART_ARCHIVE = "1"');
    push(@newPackageDataLines , 'ORIGINAL_FILE_SIZE =  "' . hex($originalFileSize) . '"');
    push(@newPackageDataLines , 'ORIGINAL_FILE_CHECKSUM =  "' . $originalFileChecksum . '"' );
    push(@newPackageDataLines , 'ORIGINAL_FILE_MODE =  "' . $originalFileMode .  '"' );

    return join("\n", @newPackageDataLines)."\n";
}

sub _createFilesLstForPart {
    my ( $actualFilePath, $archiveFilePath, $suffix, $list ) = @_;

    my $splitFilePath = $actualFilePath . $suffix;

    my $checksum = BuildPackage::Tools::getMD5Sum( $splitFilePath );
    if ( !defined $checksum ) {
        return undef;
    }
    my $mode = _getFileMode( $archiveFilePath, $list );
    if ( !defined $mode ) {
        return undef;
    }

    my $chunkStat = File::stat::stat( $splitFilePath );
    if ( !defined $chunkStat ) {
        BuildPackage::Tools::error(
            "... Error, cannot stat for '$splitFilePath': $!");
        return undef;
    }
    my $splitFileArchivePath = $archiveFilePath . $suffix;
    $splitFileArchivePath =~ s/\/{2,}/\//g;
    $splitFileArchivePath =~ s/^\///;

    my $listLine =
       '"' . $splitFileArchivePath . '"' . " "
      . $checksum . ','
      . sprintf( "%x", $chunkStat->size() ) . ','
      . sprintf( "%x",  $chunkStat->mtime() ) . ','
      . $mode . "\n";

    return $listLine;
}

sub _getFileSize {
    my ($filePath, $shouldFailOnStat) = @_;
    my $fileStat = File::stat::stat($filePath);
    if ( !defined $fileStat && $shouldFailOnStat ) {
        BuildPackage::Tools::error(
            "... Error, cannot stat for '$filePath': $!");
        return undef;
    }
    return defined $fileStat ? $fileStat->size() : 0;
}

sub _getFileMode {
    my ( $archiveFilePath, $filesLst ) = @_;
      # "fileName" checksum, size, mtime, mode
    return $1 if ( $filesLst =~ /.*"$archiveFilePath"\s+\w+,\w+,\w+,(\w+).*/gm );

    BuildPackage::Tools::error("... Error, cannot find '$archiveFilePath' in $filesLst");
    return undef;
}

sub _getBlockSize {
    my ($file , $splitSize) = @_;
    my $fileStat = File::stat::stat($file);
    my $prefferedBlockSize = defined $fileStat ? $fileStat->blksize() || DEFAULT_BLOCK_SIZE : DEFAULT_BLOCK_SIZE ;
    if( defined $fileStat && $fileStat->size() + $prefferedBlockSize  > $splitSize ){
        return $splitSize - $fileStat->size() ;
    }
    return $prefferedBlockSize;
}

sub calculateNumberOfSplits {
    my ($fileSize)   = @_;
    my $result   = int( $fileSize / $gUstarMaxSize );
    return $fileSize % $gUstarMaxSize != 0 ? $result + 1 : $result;
}

1;
