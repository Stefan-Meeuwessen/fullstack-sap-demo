#! /usr/bin/perl
#
#


package BuildPackage::Tools;

use Cwd;
use Exporter;
use Digest::SHA qw(sha256_hex);
use Time::Local;
use SDB::Install::DebugUtilities;
use File::Basename qw (dirname basename);
use BuildPackage::SplitTools;
use SDB::Install::Globals qw($gUstarMaxSize);

use strict;

our @ISA =('Exporter');
our @EXPORT = qw (getMD5Sum add_file insert_file remove_file getRealPathName
            do_cmd makedir find deltree copy readini
            normalizePath DecodeBoolTag enumFilesRecursively
            dataDeepCopy createTgz createInstallerPackage
            createGnuTarFileHandle createArchiveLst addFile
            addPackageMetadata addFilesLst addScriptPm
            info error
            );

#-----------------------------------------------------------------------------

sub setErrMsgHandler{
	my ($handler) = @_;
	*err = $handler;
}

#-----------------------------------------------------------------------------

sub setMsgHandler{
	my ($handler) = @_;
	*msg = $handler;
}

#-----------------------------------------------------------------------------

sub getMD5Sum{
	my ($file) = @_;
	-f $file || error("cannot get md5sum of $file: $!") && return undef;
	my $md5sum = `md5sum $file 2>&1`;
	chomp($md5sum);
      my $output = $md5sum;
	$md5sum =~ s/\s+\S+//;
      $md5sum =~ /^[a-f|0-9]{32}$/ || error ("cannot get md5sum of $file: $output") && return undef;
	return $md5sum;
}

#-----------------------------------------------------------------------------

sub copy{
	my ($src,$dst,$config)=@_;
	$src=~s/\\/\//g;
	$dst=~s/\\/\//g;
	if(not -f $src) {
	     error("ERR: System::copy(): file \"$src\" not found");
	     return 0;
	}
	my @statbuf = stat($src);
	if(not open(SRC,$src)) {
	    error("ERR: System::copy(): cannot open file \"$src\": $!");
	    return 0;
	}
	$config->{'binmode'} && binmode(SRC);
	my $dst_name;
	if(-d $dst){
		$src=~/([^\/]*)$/ and my $file=$1;
		my $dperm_changed = 0; 
		my @dstatbuf;
		if($^O !~ /mswin/i and $< != 0){
			@dstatbuf = stat($dst);
			if($< == $dstatbuf[4]){
				if(($dstatbuf[2] & 0200) == 0){
					chmod($dstatbuf[2] | 0200,$dst);
					$dperm_changed = 1;
				}
			}
		}
		if(not open(DST,">$dst/$file")) {
		    error("ERR: System::copy(): cannot create $dst/$file: $!");
		    return 0;
		}
		chmod($dstatbuf[2],$dst) if $dperm_changed;
		$dst_name = "$dst/$file";
	}
	elsif(-f $dst){
		if($^O !~ /mswin/i and $< != 0){
			my @dstatbuf = stat($dst);
			if($< == $dstatbuf[4]){
				if(($dstatbuf[2] & 0200) == 0){
					chmod($dstatbuf[2] | 0200,$dst);
				}
			}
		}
		if(not open(DST,">$dst")) {
		    error("ERR: System::copy(): cannot create $dst");
		    return 0;
		}
		$dst_name = $dst;
	}
	else{
		my $dir = $dst;
		$dir=~s/[^\/]*$//;
		$dst_name = $dst;
		unless(-d $dir){
			if($config->{'createdir'}){
				my $perm = 0775; #default
				$perm = $config->{'dir_perm'} if defined $config->{'dir_perm'}; 
				if(not makedir($dir,$perm)) {
				    error("ERR: Tools::copy(): cannot create directory $dir: $!");
				    return 0;
				}
			}
			else{
				error("ERR: Tools::copy(): cannot create $dst - parent dir missing");
				return 0;
			}
		}  
		my $dperm_changed = 0; 
		my @dstatbuf;
		if($^O !~ /mswin/i and $< != 0){
			@dstatbuf = stat($dir);
			if($< == $dstatbuf[4]){
				if(($dstatbuf[2] & 0200) == 0){
					chmod($dstatbuf[2] | 0200,$dir);
					$dperm_changed = 1;
				}
			}
		}
		if(not open(DST,">$dst")) {
		    error("ERR: System::copy(): cannot create $dst: $!");
		    return 0;
		}
		chmod($dstatbuf[2],$dir) if $dperm_changed;
	}
	$config->{'binmode'} && binmode(DST);
	my $bufSize=(stat SRC)[11] || 32768;
	my ($buf, $written);
	while(my $len = sysread(SRC,$buf,$bufSize)){
		unless(defined $len){
			next if $! =~ /^Interrupted/;
			error("ERR: Tools::copy(): read failure: $!");
			return 0;
		} 
		my $offset=0;
		while($len){
			$written=syswrite(DST,$buf,$len,$offset);
			if(not defined $written) {
			    error("ERR: Tools::copy(): write failure: $!");
			    return 0;
			}
			$len-=$written;
			$offset+=$written;
		}	
	}
	close(SRC);
	close(DST);
	
	my $atime = $statbuf[8] <= 0 ? undef : $statbuf[8];
	if(!utime($atime, $statbuf[9], $dst_name)) {
		#dumpThings(\@statbuf, 3, 2);
		error("cannot set time of copied file \"$dst_name\": $!");
		return 0;
	}

	unless($^O =~ /mswin/i){
		if (defined $config->{mode}){
			if(not chmod ($config->{mode},$dst_name)) {
			    error("cannot set mode of copied file \"$dst_name\": $!");
			    return 0;
			}
		}
		else{
			$statbuf[2] &= 0777;
			if (defined $config->{mask}){
				$statbuf[2] &= ~$config->{mask}	
			}
			if(not chmod($statbuf[2],$dst_name)) {
			    error("cannot set mode of copied file \"$dst_name\": $!");
			    return 0;
			}
		}
		unless($config->{'nochown'} || $>){
			if(not chown($statbuf[4],$statbuf[5],$dst_name)) {
			    error("cannot set uid/gid of copied file \"$dst_name\": $!");
			    return 0;
			}
		}
	}
	
	#msg("copied file \"$src\" to \"$dst\"\n");
	return 1;
}

#-----------------------------------------------------------------------------

sub add_file{
        my ($file,$target_dir,$target,$list) = @_;
        -f $file or return undef;
        -d $target_dir || return undef;
        $target =~/^\// and return undef;
        $file =~ s/\\/\//g;
        $target_dir =~ s/\\/\//g;
        $target_dir =~ s/\/$//g;
        $file =~ s/\\/\//g;
        my ($dir) = ($target =~ /^(.*)\/\w+$/);
        if ($dir =~ /\S/){
                makedir($target_dir.'/'.$dir) || return undef;
        }
        copy($file,$target_dir.'/'.$target) || return undef;
         my $md5sum = `md5sum $file`;
        $md5sum =~ s/\s+\S+//;
        $md5sum =~ /^[a-f|0-9]{32}$/ || return undef;
        my $list_file = $target_dir.'/'.$list;
        my @list_buf;
        open (LST,$list_file) || return undef;
        while(<LST>){
                chomp;
                /\S/ or next;
                /^"$target"/ and next;
                push @list_buf,$_;
        }
        close(LST);
        push @list_buf,"\"$target\" $md5sum";
        open (LST,'>'.$list_file) || return undef;
        foreach (sort @list_buf){
                print LST "$_\n";
        }
        close(LST);
        return 1;
}

#-----------------------------------------------------------------------------

sub insert_file {
        my ($buildroot,$file,$list)=@_;
        -d $buildroot || return undef;
        -f "$buildroot/$file" || return undef;
        -f "$buildroot/$list" || return undef;
        my @list_buf;
        open (LST,"$buildroot/$list") || return undef;
        while(<LST>){
                chomp;
                /\S/ or next;
                /^"$file"/ and next;
                push @list_buf,$_;
        }
        close(LST);
        my $md5sum = `md5sum $buildroot/$file`;
        $md5sum =~ s/\s+\S+//;
        $md5sum =~ /^[a-f|0-9]{32}$/ || return undef;
        push @list_buf,"\"$file\" $md5sum";
        open (LST,">$buildroot/$list") || return undef;
        foreach (sort @list_buf){
                print LST "$_\n";
        }
        close(LST);
        return 1;
}

#-----------------------------------------------------------------------------

sub remove_file{
        my ($buildroot,$file,$list) = @_;
        $buildroot =~ s/\\/\//g;
        $buildroot =~ s/\/$//;
        $file =~ s/\\/\//g;
        my $list_file = $buildroot.'/'.$list;
        -f $list_file || return undef;
        my $path = $buildroot.'/'.$file;
        -f $path || return undef;
        unlink($path) || return undef;
        open (LST,$list_file) || return undef;
        my $found = 0;
        my @list_buf;
        while(<LST>){
                chomp;
                /\S/ or next;
                unless(/"$file"/){
					$found = 1;
					next;
                }
                push @list_buf,$_;
        }
        close(LST);
        return undef unless $found;
        open (LST,'>'.$list_file) || return undef;
        foreach ( @list_buf){
                print LST "$_\n";
        }
        close(LST);
        return 1;
}

#-----------------------------------------------------------------------------

sub do_cmd{
        my ($cmd) = @_;
        msg("processing $cmd\n");
        my $outtxt = `$cmd 2>&1`;
        if($? != 0){
                error("$cmd: $outtxt");
                return;
        }
        return 1;
}

#-----------------------------------------------------------------------------

our $max_tries = 30;
sub deltree{
    my (
        $dir, $skip_toplevel
    ) = @_;
    if(not -d $dir) {
    	return 0;
    }
	my @statbuf = stat ($dir);
	if (($^O !~ /mswin/i) && ($> == $statbuf[4]) && (($statbuf[2] & 0700) != 0700)){
		chmod ($statbuf[2] | 0700, $dir);
	}
    opendir(DH,$dir) || return 0;
    my @content = readdir(DH);
    closedir(DH);
    my @files = grep { -f "$dir/$_" || (!-e "$dir/$_" && -l "$dir/$_")} @content;
    my @dirs = grep { -d "$dir/$_" && ! /^\.{1,2}$/} @content;
    #
    #  enable write permission in directory to delete entries:
	if($^O !~ /mswin/i) {
		if($#files > -1 || $#dirs > -1){
			my @statbuf = stat($dir);
			my $mask;
			if($> == $statbuf[4]){
				$mask = 0200;
			}
			else{
				my $found;
				foreach my $gid (split(' ',$) )){
					if($gid == $statbuf[5]){
						$found = 1;
						last;
					} 
				}
				if($found){
					$mask = 020;
				}
				else{
					$mask = 002;
				}
			}
			if(($statbuf[2] & $mask) == 0){
				chmod($statbuf[2] | $mask,$dir) || error("cannot enable write permissions for $dir");
			}
		}
	}
    foreach (@dirs){
        -l "$dir/$_" and (unlink("$dir/$_") || error("cannot delete symbolic link $dir/$_: $!") && return 0);
        deltree("$dir/$_") || return 0;
    }
	my $success;
    foreach (@files){
        -l "$dir/$_" and (unlink("$dir/$_") || error("cannot delete symbolic link $dir/$_: $!") && return 0);
		if (-f "$dir/$_" && !unlink("$dir/$_")){
			if ($^O =~ /mswin/i){
				$success = 0;
				my $f = $_;
				foreach (0..($max_tries - 1)){
					sleep (1);
					info("RETRYING ($_) delete file $dir/$f");
					if (unlink("$dir/$f")){
						$success = 1;
						last;
					}
				}
				if (!$success){
					error("cannot delete file $dir/$f (tried $max_tries times): $!");
					return 0;
				}
			}
			else{
				error("cannot delete file $dir/$_: $!");
				return 0;
			}
		}
			
    }
    if (!$skip_toplevel){
        chmod (0777, $dir);
        rmdir($dir) or error("cannot delete directory $dir: $!") and return 0;
    }
    return 1;
}

#-----------------------------------------------------------------------------

sub makedir{
        my ($dir,$mode,$ref_uid,$ref_gid) = @_;
        $dir =~ s/\\/\//g;
        $dir =~ s/\/$//;
        -d $dir && return 1;
		my ($parent) = ($dir =~ /^(.*)\/[^\/]+$/);
	    
		if($dir !~ /\// || -d $parent){
				
				my $pperm_changed = 0;
				my @pstatbuf;

				if($parent =~ /\S/){
					if($^O !~ /mswin/i and $< != 0){
						@pstatbuf = stat ($parent);
						my $dirmode = $pstatbuf[2] & 0777;	
						if($pstatbuf[4] == $<){
							if(($pstatbuf[2] & 0200) == 0){
								$pperm_changed = 1;
								chmod($pstatbuf[2] | 0200,$parent);
							}
						}
					}
				}

				mkdir($dir,$mode) || return 0;
                unless($^O =~ /mswin/i){
					#
					# workaround for perl bug
					#
					my @statbuf = stat ($dir);
					my $filemode = $statbuf[2] & 0777;
					if ($filemode != $mode) {
						chmod ($mode, $dir) || return 0;
					}
					if(defined $$ref_uid || defined $$ref_gid){
						my ($uid,$gid) = ($statbuf[4],$statbuf[5]);
						defined $$ref_uid and $uid = $$ref_uid;
						defined $$ref_gid and $gid = $$ref_gid;
						chown($uid,$gid,$dir) or $! = "cannot change ownership of directory $dir: $!" and return 0; 
					}	
				}
				chmod($pstatbuf[2],$parent) if ($pperm_changed);
				return 1;
        }
        makedir($parent,$mode) || return 0;
 		
		my $pperm_changed = 0;
		my @pstatbuf;

		if($parent =~ /\S/){
			if($^O !~ /mswin/i and $< != 0){
				@pstatbuf = stat ($parent);
				my $dirmode = $pstatbuf[2] & 0777;	
				if($pstatbuf[4] == $<){
					if(($pstatbuf[2] & 0200) == 0){
						$pperm_changed = 1;
						chmod($pstatbuf[2] | 0200,$parent);
					}
				}
			}

		}
		
		mkdir($dir,$mode) || return 0;
		unless($^O =~ /mswin/i){
			#
			# workaround for perl bug
			#
			my @statbuf = stat ($dir);
			my $filemode = $statbuf[2] & 0777;
			if ($filemode != $mode) {
				chmod ($mode, $dir) || return 0;
			}
		}
		chmod($pstatbuf[2],$parent) if ($pperm_changed);
		return 1;
}

#-----------------------------------------------------------------------------

sub readini{
	my ($file) = @_;
	my %returnvalue;
	open(FH,$file) or return undef;
	my $section = 'main';
	while(<FH>){
		chomp;
		if(/^\s*\[.+\]\s*$/){
			($section) = (/^\s*\[(.+)\]\s*$/);	
		}
		elsif(/^.+=.+$/){
			my ($key,$value) = (/^(.+)=(.+)$/);
			$key =~ s/^\s*//;
			$key =~ s/\s*$//;
			$value =~ s/^\s*//;
			$value =~ s/\s*$//;
			if(exists $returnvalue{$section} && ref($returnvalue{$section}) eq  'HASH'){
				$returnvalue{$section}->{$key} = $value;		
			}
			else{
				$returnvalue{$section} = {$key => $value}; 	
			}
		}
	}
	close(FH);
	return %returnvalue;
}

#-----------------------------------------------------------------------------

sub find {
        my ($dir,$type,$root) = @_;
        my @returnvalue;
        my $tdir = defined $root ? $root . '/' . $dir : $dir;
        $tdir =~ s/\/+$// if ($tdir =~ /[^\/]/);

        -d $tdir or return undef;
        opendir(DH,$tdir) || return undef;
        my @content = readdir(DH);
        closedir(DH);

        my @files = grep { -f "$tdir/$_" } @content;
        my @dirs = grep { -d "$tdir/$_" && ! /^\.{1,2}$/} @content;


        foreach(@dirs){
                -l "$dir/$_" and next;
                my @result = find( $dir ? "$dir/$_" : $_,$type,$root);
                $#result > -1 && push @returnvalue,@result;
        }

        if($type !~ /^d$/i){
                foreach (@files){
                        push @returnvalue, $dir ? "$dir/$_" : $_;
                }
        }
        if($type !~ /^f$/i){
                foreach (@dirs){
                        push @returnvalue, $dir ? "$dir/$_" : $_;
                }
        }
        return @returnvalue;
}

#-----------------------------------------------------------------------------

sub modeStr2Num{
	my ($modstr) = @_;
	$modstr =~ /^[rwxs-]{9}$/ or error("mode string \"$modstr\" has wrong format"); 
	$modstr =~ s/[wrx]/1/g;
	$modstr =~ s/-/0/g;
	return unpack("N", pack("B32", substr("0" x 32 . $modstr, -32)));
}


#-----------------------------------------------------------------------------

sub normalizePath{
    my ($rPath) = @_;
    $$rPath =~ s/\\/\//g;
    $$rPath =~ s/\/{2,}/\//g;
    $$rPath =~ s/\/$//;
    if ($^O =~ /mswin/i){
        $$rPath =~ tr/[A-Z]/[a-z]/;
    }
    return 1;
}

#-----------------------------------------------------------------------------

our %path_cache;

#-----------------------------------------------------------------------------

sub getRealPathName{
	my ($path,$root) = @_;
	if ($^O =~ /mswin/i){
		return $path;
	}
	my $rv = '';

	my $cache_key = "$root/$path";

	normalizePath (\$cache_key);

	if (exists $path_cache{$cache_key}){
		return $path_cache{$cache_key};
	}

	my ($parentpath,$node)  = ($path =~ /(.*)[\\\/]+([^\\\/]+)$/);
	
	if (defined $parentpath){
		$rv = getRealPathName ($parentpath,$root);
		if (opendir (PP,"$root/$parentpath")){
			my $pattern = '^'.$node.'$';
			my ($result) = grep {/$pattern/i} readdir (PP);
			if (defined $result){
				$rv .= '/'.$result; 
			}
			else{
				$rv .= '/'.$node; 
			}
			closedir (PP);
		}
		else{
			$rv .= '/'.$node; 
		}
	}
	else{
		if (opendir (PP,"$root")){
			my $pattern = '^'.$node.'$';
			my ($result) = grep {/$pattern/i} readdir (PP);
			if (defined $result){
				$rv = $result; 
			}
			else{
				$rv = $node; 
			}
			closedir (PP);
			
		}
		else{
			$rv = $node;
		}	
		
	}
	$path_cache{$cache_key} = $rv;
	return $rv;
}

#--------------------------------------------------------------------------------------------------

sub DecodeBoolTag{
    my (
        $entry
    ) = @_;
    my $retcode = 0;
    if(defined $entry) {
        if($entry eq 'yes' || $entry eq 'true' || $entry eq '1') {
            $retcode = 1;
        }
    }
    return $retcode;
}

#-----------------------------------------------------------------------------

sub enumFilesRecursively {
    my (
        $absolutePrefix, # an absolute path used to prefix $dir. Optional; if undef,
                         # $dir must be absolute.
        $dir,            # return value is relative to the parent directory of the highest directory
                         # given by $dir.
        $fileHashRef,    # return value, must be a hash ref.
        $lowerCaseOutput,
        $includeFileNamePattern,
        $excludeFileNamePattern,
        $includeOnlyWhenExtensionPatternExists,
        $packageInFiles,
        $errObj,         # error handler, typically the calling object, optional
        $depth           # max search depth
    ) = @_;
    $dir =~ s/(^\s*|\s*$)//g;
    my $fullPath = $dir;
    if(defined $absolutePrefix) {
	    $absolutePrefix =~ s/(^\s*|\s*$)//g;
	    if(!$absolutePrefix eq '') {
	    	$absolutePrefix =~ s/(\\$|\/$)//g;
	    	$fullPath = $absolutePrefix.'/'.$dir;
	    }
    }
    if(!-d $fullPath) {
    	if(defined $errObj) {
    	   $errObj->{'last_error'} = "$fullPath does not exist or is not a directory";
    	}
        return undef;
    }
    if(!defined $lowerCaseOutput) {
    	$lowerCaseOutput = 0;
    }
    my $rc = undef;
    $rc = opendir(DH, $fullPath);
    if(!$rc) {
        $errObj->{'last_error'} = "Could not open directory $fullPath";
        return undef;
    }
    my @content = readdir(DH);
    closedir(DH);
    my @files = grep { -f "$fullPath/$_" } @content;
    if (!defined $depth || $depth > 0){
        my @dirs = grep { -d "$fullPath/$_" && ! /^\.{1,2}$/} @content;
        if (defined $depth){
            $depth--;
        }
        foreach(@dirs){
            if(-l "$fullPath/$_") {
                # we don't follow symlinks
                next;
            }
            $rc = enumFilesRecursively($absolutePrefix,
                                       "$dir/$_",
                                       $fileHashRef,
                                       $lowerCaseOutput,
                                       $includeFileNamePattern,
                                       $excludeFileNamePattern,
                                       $includeOnlyWhenExtensionPatternExists,
                                       $packageInFiles,
                                       $errObj,
                                       $depth);
            if(!defined $rc) {
            	return undef;
            }
        }
    }
    foreach (@files){
    	my $file = "$dir/$_";
    	$file =~ s/\\/\//g;
    	my $include = 1;
    	my $exclude = 0;
        if(defined $includeFileNamePattern) {
        	$include = 0;
        	if($file =~ /$includeFileNamePattern/) {
                if(defined $includeOnlyWhenExtensionPatternExists) {
                    my $basename = basename($file);
                    $basename =~ s/(.*)\..*$/$1/;
                    # grepping the "in_files" structure for each file again and again is inefficient
                    # for very large packages, using a hash could improve it:
                    my @exts = grep { $_->{'path'} =~ /$basename$includeOnlyWhenExtensionPatternExists$/ } @{$packageInFiles};
                    if(@exts) {
                        $include = 1;
                    }
                }
                else {
                    $include = 1;
                }
        	}
        }
        if(defined $excludeFileNamePattern && $file =~ /$excludeFileNamePattern/) {
            $exclude = 1;
        }
        if($include && not $exclude) {
	    	if($lowerCaseOutput) {
	    		$file = lc $file;
	    	}
	        $fileHashRef->{$file} = $file;
        }
    }
    return $fileHashRef;
}

#----------------------------------------------------------------------------

=functionComment

performs a deep copy of the data structure referenced by the parameter.
Returns a reference to the copy.
self-referential structures will cause infinite recursions, and
cross-referential structures will cause duplications!

=cut

sub dataDeepCopy {
    my (
        $p_srcRef
    ) = @_;
    my $refType = ref($p_srcRef);
    my $tgtRef = undef;
    if($refType eq "ARRAY") {
    	$tgtRef = [];
        foreach my $value (@$p_srcRef) {
                push(@$tgtRef, dataDeepCopy($value));
        }
    }
    elsif($refType eq "HASH") {
    	$tgtRef = {};
        while (my ($key,$value) = each %$p_srcRef) {
                $tgtRef->{$key} = dataDeepCopy($value);
        }
    }
    elsif($refType eq "SCALAR") {
    	my $value = $$p_srcRef;
    	$tgtRef = \$value;
    }
    elsif($refType =~ /^(CODE|REF|GLOB|LVALUE|FORMAT|IO|VSTRING|Regexp)$/) {
    	$tgtRef = $p_srcRef;
    }
    elsif($refType =~ /\S/) { 
    	$tgtRef = {};
        while (my ($key,$value) = each %$p_srcRef) {
                $tgtRef->{$key} = dataDeepCopy($value);
        }
    }
    else {
        $tgtRef = $p_srcRef;
    }
    return $tgtRef;
}

#--------------------------------------------------------------------------------------------------

sub createTgz{
    my ($archive, $rootDir, $tarFileList) = @_;
    require SAPDB::Install::GnuTar;
    my $gnutar = new SAPDB::Install::GnuTar ();
    $gnutar->OpenArchive ($archive, 'w');
    my $fh;
    if (!open ($fh, $tarFileList)){
        $gnutar->CloseArchive ();
       error ("... Error, cannot open tar file list  '$tarFileList': $!");
       next;
    }
    my $error = 0;
    my @expand;
    my ($fileName, $filePath);
    while ($fileName = <$fh>){
        if (!$fileName){
            next;
        }
        chomp ($fileName);
        $filePath = $rootDir . '/'. $fileName;
        if (!-e $filePath){
            error ("... Error, cannot add file '$filePath' to archive '$archive': $!");
            return undef;
        }
        if (-d _ ){
            @expand = find ('', 'f', $filePath);
        }
        else{
            @expand = ();
        }
        if (!defined $gnutar->Add($filePath, $fileName)){
            error ("... Error, cannot add file '$filePath' to archive '$archive': $!");
            $error = 1;
            last;
        }
        foreach my $foundFile (@expand){
            if (!defined $gnutar->Add($filePath . '/' . $foundFile, $fileName . '/' . $foundFile)){
                error ("... Error, cannot add file '$filePath/$foundFile' to archive '$archive': $!");
                $error = 1;
                last;
            }
        }
        if ($error){
            last;
        }
    }
    close ($fh);
    $gnutar->CloseArchive ();
    if ($error){
        return undef;
    }
    return 1;
}

sub createInstallerPackage{
    my (
        $archive,             # 1
        $pData,               # 2
        $list,                # 3
        $script,              # 4
        $content,             # 5
        $pmask,               # 6
        $pigz,                # 7
        $threads,             # 8
        $pigzRsyncable,       # 9
        $shouldSplitBigFiles  # 10
    ) = @_;

    my $lstFiles = [];
    my $splitFiles;

    #create lst for archive
    my $packageListFile = createArchiveLst($archive);
    if(! defined $packageListFile){
        return undef;
    }
    push(@$lstFiles, $packageListFile);


    if ($shouldSplitBigFiles) {
        $splitFiles = _collectBigFiles($content);

        if ( scalar(@$splitFiles) > 0 ) {
            my $nextAfterLastArchiveIndex = splitPackageInstallerContent(
                $archive,          # 1
                $splitFiles,       # 2
                $pmask,            # 3
                $pigz,             # 4
                $threads,          # 5
                $pigzRsyncable,    # 6
                $pData,            #7 PACKAGEDATA content
                $list              #8 files.lst content
            );

            if(!defined $nextAfterLastArchiveIndex){
                return undef;
            }
            # handle the final package of the split, that has also an index and contains script.pm 
            # and all the original unsplit package handling
            my $lastButOnePackage = $archive . sprintf( "%04d", $nextAfterLastArchiveIndex - 1 );
            $pData = addDependencyToLastPartArchive( $pData, $lastButOnePackage );
            if(!defined $pData){
                return undef;
            }

            #remove split parts from file.lst content
            $list = removeSplitFilesFromFileList($list,  "files.lst" , $splitFiles);

            #rename archive name to the last part
            my $lastPackage = sprintf( "%04d", $nextAfterLastArchiveIndex );
            $archive .= $lastPackage;
            my $lastPackageArchiveLst = createArchiveLst($archive);
            if(! defined $lastPackageArchiveLst){
                return undef;
            }
            push (@$lstFiles , $lastPackageArchiveLst );

            info("Creating last archive part $archive");
        }
    }

    my $gnutar = createGnuTarFileHandle($pigz , $threads, $pigzRsyncable);
    if (!defined $gnutar->OpenArchive ($archive, 'w', $pmask)){
      error ("... Error, cannot create archive '$archive': $!");
      return undef;
    }

    if ( defined $pData
        && !addPackageMetadata( $pData, $gnutar, $archive, $lstFiles ) ) {
        return undef;
    }

    if ( defined $list
        && !addFilesLst( $list, $gnutar, $archive, $lstFiles ) ) {
        return undef;
    }

    if ( defined $script
        && !addScriptPm( $script, $gnutar, $archive, $lstFiles) )
    {
        return undef;
    }

    my (@filePaths, $type);

    foreach my $filePathsRef (@$content) {
        my ( $type, @filePaths ) = @$filePathsRef;
        if ( $type == 0 ) {
            my $archiveFilePath = $filePaths[1];
            if (   !_checkContentContainsArchiveFilePath( $archiveFilePath, $splitFiles )
                && !addFile( \@filePaths, $gnutar, $archive, $lstFiles ) ) {
                return undef;
            }
        }
        elsif ( $type == 1
            && !addLink( \@filePaths, $gnutar, $archive, $lstFiles ) ) {
            return undef;
        }
    }

    if (!defined $gnutar->CloseArchive ()){
        error ("... Error, cannot close archive '$archive': $!");
        return undef;
    }

    return 1;
}

sub createGnuTarFileHandle {
    my ($pigz, $threads, $pigzRsyncable ) = @_;

    require SAPDB::Install::GnuTar;
    my $gnutar = new SAPDB::Install::GnuTar ();
    if (defined $pigz && $threads > 1){
        my @compressorArgs = ('-p',$threads, '-9', '-c');
        if ($pigzRsyncable){
            push @compressorArgs, '--rsyncable';
        }
        my $rc = $gnutar->setCompressor ($pigz, \@compressorArgs);
    }
    return $gnutar;
}

sub addLink {
    my ( $link, $gnutar, $archive, $lstFiles ) = @_;
    my $archiveFilePath    = $link->[0];
    my $linkTarget = $link->[1];
    if ( !defined $gnutar->AddLink(@$link) ) {
        error("... Error, add link '$archiveFilePath' to archive '$archive': $!");
        return undef;
    }

    my $entry = createPackageListEntry( $archiveFilePath, undef, $linkTarget );
    if ( !addLstEntry( $entry, $lstFiles ) ) {
        return undef;
    }
    return 1;
}

sub addFile {
    my ( $filePaths, $gnutar, $archive, $lstFiles ) = @_;
    my $actualFilePath = $filePaths->[0];
    my $archiveFilePath  = $filePaths->[1];

    if ( !defined $gnutar->Add(@$filePaths) ) {
        error("... Error, add file '$actualFilePath' to archive '$archive': $!");
        return undef;
    }

    my $entry = createPackageListEntry( $archiveFilePath, $actualFilePath );
    if ( !addLstEntry( $entry, $lstFiles ) ) {
        return undef;
    }

    return 1;
}

sub createArchiveLst {
    my ($archive) = @_;
    my $lstFile = "$archive.lst";
    my $hdr = "LSS-HASHES\nHash: SHA256\n\n";
    if ( !addLstEntry( $hdr, [ $lstFile ] ) ) {
        return undef;
    }
    return $lstFile;
}

sub addPackageMetadata {
    my ( $pData, $gnutar, $archive, $lstFiles ) = @_;
    my $archiveFilePath = 'PACKAGEDATA';
    if ( !defined $gnutar->AddScalar( $archiveFilePath, $pData ) ) {
        error("... Error, add PACKAGEDATA to archive  '$archive': $!");
        return undef;
    }
    my $entry = createPackageListEntry( $archiveFilePath, undef, $pData );
    if ( !addLstEntry( $entry, $lstFiles ) ) {
        return undef;
    }
    return 1;
}

sub addFilesLst {
    my ( $list, $gnutar, $archive, $lstFiles ) = @_;
    my $archiveFilePath = 'files.lst';
    if ( !defined $gnutar->AddScalar( $archiveFilePath, $list ) ) {
        error("... Error, add file list to archive '$archive': $!");
        return undef;
    }
    my $entry = createPackageListEntry( $archiveFilePath, undef, $list );
    if ( !addLstEntry( $entry, $lstFiles ) ) {
        return undef;
    }
    return 1;
}

sub addScriptPm {
    my ( $script, $gnutar, $archive, $lstFiles, $addScalar ) = @_;
    my $archiveFilePath = 'script.pm';
    my $entry;
    if ($addScalar) {
        if ( !defined $script ) {
            error("... Error, add script to archive '$archive': content is empty"
            );
            return undef;
        }
        if ( !defined $gnutar->AddScalar( $archiveFilePath , $script) ) {
            error("... Error, add script to archive '$archive': $!");
            return undef;
        }

        $entry = createPackageListEntry( $archiveFilePath, undef, $script );
    }
    else {
        if ( !defined $gnutar->Add( $script, $archiveFilePath, 1, 0440 ) ) {
            error("... Error, add script to archive '$archive': $!");
            return undef;
        }
        $entry = createPackageListEntry( $archiveFilePath, $script );
    }

    if ( !addLstEntry( $entry, $lstFiles ) ) {
        return undef;
    }
    return 1;
}

sub _getFileShaHashCode {
    my ($filepath) = @_;

    my $sha = Digest::SHA->new(256);
    $sha->addfile($filepath);
    return $sha->hexdigest();
}

sub createPackageListEntry {
    my ($archiveFilePath, $actualFilePath, $content) = @_;

    my $checksum;
    my $isExecutable;
    if (defined $actualFilePath) {
        $checksum = _getFileShaHashCode($actualFilePath);
        $isExecutable = isExecutable($actualFilePath);
        return undef if (! defined $isExecutable);
    } else {
        $checksum = sha256_hex($content);
        $isExecutable = 0;
    }
    my $execChar = $isExecutable ? 'X' : ' ';
    return "$checksum $execChar $archiveFilePath\n";
}

our @ELF = ('7F', '45', '4C', '46' );
sub isExecutable {
    my ($actualFilePath) = @_;

    my ($fh, $buffer);
    if (!open($fh, $actualFilePath)) {
       error ("... Error, cannot open file '$actualFilePath': $!");
       return undef;
    }
    binmode($fh);
    if (!eof($fh) && !read($fh, $buffer, 4)) {
       error ("... Error, cannot read from file '$actualFilePath': $!");
       return undef;
    };
    return 0 if (length $buffer < 4);
    my $rc = 1;
    for (0 .. 3) {
        my $hex = sprintf('%02X', ord(substr($buffer, $_, 1)));
        if ($hex ne $ELF[$_]) {
            $rc = 0;
            last;
        }

    }
    if (!close($fh)) {
       error ("... Error, cannot close file '$actualFilePath': $!");
       return undef;
    }
    return $rc;
}

sub addLstEntry {
    my ( $entry, $lstFiles ) = @_;
    if ( !defined $entry ) {
        return undef;
    }
    foreach my $lstFile (@$lstFiles) {
        my $fh;
        if ( !open( $fh, '>>', $lstFile ) ) {
            error("... Error, cannot open file '$lstFile': $!");
            return undef;
        }
        print $fh $entry;
        if ( !close($fh) ) {
            error("... Error, cannot close file '$lstFile': $!");
            return undef;
        }
    }
    return 1;
}

sub shouldSplitFile {
    my ($file)   = @_;
    require File::stat;
    my $fileSize = File::stat::stat($file)->size();
    if ( $fileSize > $gUstarMaxSize ) {
        return 1;
    }
    return 0;
}

sub splitPackageInstallerContent {
    my (
        $archive,          # 1
        $content,          # 2 bigFiles
        $pmask,            # 3
        $pigz,             # 4
        $threads,          # 5
        $pigzRsyncable,    # 6
        $pData,            # packageData
        $filesList         # files.lst entries for bigFiles
    ) = @_;

    my $nextAfterLastArchiveIndex = 1;
    foreach my $file (@$content)  {
        my $newIndex = BuildPackage::SplitTools::splitFileInArchives(
            $nextAfterLastArchiveIndex, $archive, $file,
            $pigz,                $threads, $pigzRsyncable,
            $pmask,               $pData,   $filesList, $gUstarMaxSize
        );

        if ( !defined $newIndex ) {
            return undef;
        }
        my $packageListFile = "$archive.lst";
        my ( $type, @filePath ) = @$file;
        my $actualFilePath = $filePath[0];
        my $archiveFilePath  = $filePath[1];
        my $entry    = createPackageListEntry( $archiveFilePath, $actualFilePath );
        addLstEntry( $entry, [$packageListFile] );

        $nextAfterLastArchiveIndex = $newIndex;
    }

    return $nextAfterLastArchiveIndex;
}



sub removeSplitFilesFromFileList {
    my ( $listString, $filesLstFilename, $bigFilesContent ) = @_;

    my $newListString = "";
    foreach my $line ( split "\n", $listString ) {
        next if $line !~ /\S/ or $line =~ /^\s*#/;
        my ( $file, $stat ) = ( $line =~ /\"(.+)\"\s+(\S+)/ );
        if(_checkContentContainsArchiveFilePath($file , $bigFilesContent)){
            info(
                "File $file will be removed from $filesLstFilename as size exceeds ustar file size limit of $gUstarMaxSize bytes"
            );
            next;
        }
        $newListString .= $line . "\n";
    }

    return $newListString;
}

sub _collectBigFiles {
    my ($content) = @_;

    my @bigFiles;
    foreach my $file (@$content) {
        my ( $type, @filePaths ) = @$file;
        if ( $type == 0 ) {
            my $actualFilePath    = $filePaths[0];
            my $archiveFilePath = $filePaths[1];

            if ( shouldSplitFile($actualFilePath) ) {
                info("File $actualFilePath exceeds $gUstarMaxSize bytes and will be split");
                push( @bigFiles, $file );
                next;
            }
        }
    }
    return \@bigFiles;
}

sub _checkContentContainsArchiveFilePath {
    my ( $archiveFilePath, $content ) =  @_;

    if(!defined $content) {
        return 0;
    }
     foreach my $file (@$content) {
        my ( $type, @filePaths ) = @$file;
        return 1 if($archiveFilePath eq $filePaths[1]);
     }

    return 0;
}

sub addDependencyToLastPartArchive {
    my ( $pData, $lastPackagePath ) = @_;

    my $lastPackageMetadata = _readArchiveMetadata($lastPackagePath);
    if(!defined $lastPackageMetadata) {
        return undef;
    }
    my $lastPackageId = $lastPackageMetadata->{ID};

    if ( !defined $lastPackageId ) {
        error("...Error, No ID found in $lastPackagePath PACKAGEDATA");
        return undef;
    }

    #add require to lastPkgId
    $pData .= 'REQUIRE_CONDITIONAL = "' . $lastPackageId . "\"\n";
    $pData .= "IS_LAST_SPLIT_PACKAGE = \"1\"\n";

    return $pData;
}

sub _readArchiveMetadata(){
    my ( $archivePath ) = @_;

    require SDB::Install::Archive;
    my $packageArchive = SDB::Install::Archive->new($archivePath);

    unless ( defined $packageArchive->open() ) {
        error("...Error,Cannot open archive $archivePath ");
        return undef;
    }

    my $packageDataFile = $packageArchive->next();

    if ( !defined $packageDataFile ) {
        error("...Error, No files in archive $archivePath");
        return undef;
    }

    if ( $packageDataFile->{name} ne 'PACKAGEDATA' ) {
        error("...Error, No PACKAGEDATA found in archive $archivePath");
        return undef;
    }

    return $packageArchive->read_meta();
}
#--------------------------------------------------------------------------------------------------

sub info {
    my ($text) = @_;
    print "$text\n";
}

sub error {
    my ($text) = @_;
    err("$text\n");
}
1;






