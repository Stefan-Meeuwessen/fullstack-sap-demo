package LCM::ConfigurationFinalizationStep;

use strict;

sub new { return bless {executor => $_[1]}, $_[0]; }

sub getStatus { return $_[0]->{executor}->getStatus(); }

sub getName { return $_[0]->{executor}->getName(); }

sub getLogLocation { return $_[0]->{executor}->getLogLocation(); }

sub getWarnings {
	# TODO: FIX AFTER REFACTORING END: remove
	if($_[0]->{executor}->can('getWarningMessages')){ # the new name after refactoring
		return $_[0]->{executor}->getWarningMessages();
	}
	else{
		return $_[0]->{executor}->getWarnings();
	}
}

1;