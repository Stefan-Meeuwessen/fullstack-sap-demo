package LCM::Configuration::ListSystemsActionConfiguration;
use SDB::Install::Globals qw ($gFlavourPlatform);

use parent qw(LCM::Configuration::ActionConfiguration);

sub getFlavour {
    my $self = shift;
    return $gFlavourPlatform;
}

1;