package LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::Scenario::Install;
use strict;
use base qw ( LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::Scenario );
use LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::SkippedComponentsManager;
use LCM::Component;

sub detectSkippedComponents{
    my($self) = @_;
    my $componentsManager = $self->{oComponentsManager};
    my @components = @{$componentsManager->{aSelectedComponents}};
    my $installedComponents = $componentsManager->{aInstalledComponents};
    if(defined $installedComponents){
        foreach my $installedComponent(@$installedComponents){
           $componentsManager->skipComponent($installedComponent);  
        }
     }
    foreach my $component(@components){
        if($componentsManager->shallSkipComponent($component)){
            $componentsManager->skipComponent($component);
        }
    }
}

return 1;