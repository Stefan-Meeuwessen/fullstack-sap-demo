package LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::Scenario::Uninstall;
use strict;
use base qw ( LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::Scenario );
use LCM::Component;
use LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::SkippedComponentsManager;

sub detectSkippedComponents{
    my($self) = @_;
    my $componentsManager = $self->{oComponentsManager};
    my $installedComponents = $componentsManager->{aInstalledComponents};
    if ( ! defined $installedComponents ) {
        return;
    }
    
    for my $installedComponent( @$installedComponents ) {
    	if ( $componentsManager->isComponentSelected($installedComponent) ){
        	if($componentsManager->shallSkipComponent($installedComponent) ) {
                $componentsManager->skipComponent($installedComponent);
        	}
        } else {
            $componentsManager->skipComponent($installedComponent);
        }
    } 
}


return 1;