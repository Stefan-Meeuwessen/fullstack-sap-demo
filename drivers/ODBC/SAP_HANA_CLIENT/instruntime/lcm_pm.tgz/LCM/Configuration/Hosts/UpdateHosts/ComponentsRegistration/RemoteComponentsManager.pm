package LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::RemoteComponentsManager;

use strict;
use LCM::Component;

use base qw ( LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::SkippedComponentsManager );

sub getRegistrableComponents {
    my ($self, ) = @_;
    return $self->{oScenario}->getRemoteRegistrableComponents();
}

return 1;