package LCM::Configuration::Hosts::AddHosts::Validators::LSS::InstallationPathCheck;

use strict;
use warnings;
use parent qw(LCM::Configuration::Hosts::AddHosts::Validators::LSS::BaseCheck);
use File::stat;
use SDB::Install::Globals qw($gShortProductNameLSS);
use LCM::FileUtils qw(listDirectory);

sub check {
    my($self, $hostNames) = @_;
    foreach my $host( @$hostNames ){
        if(!$self->checkHost($host)){
            return 0;
        }
    }
    return 1;
}

sub checkHost {
    my($self, $hostName) = @_;
    my $cfg = $self->getConfiguration();
    my $localHost = $cfg->getLocalHanaHost();
    if($localHost eq $hostName){
        return $self->_existsLssPathOnLocalHost($hostName);
    } else {
        return $self->_existsLssPathOnHost($hostName)
    }
}

sub _existsLssPathOnHost {
    my($self,$host) = @_;
    my $cfg = $self->getConfiguration();
    return 1 if(!defined $cfg->{lssPathExistenceHostmap}); #CollectOtherHostInfo hasn't collected information yet

    if(!$cfg->{lssPathExistenceHostmap}->{$host}){
        $self->appendErrorMessage("$gShortProductNameLSS installation path is not shared with '$host'");
        return 0;
    }
    return 1;
}

sub _existsLssPathOnLocalHost {
    my($self, $hostName) = @_;
    my $cfg = $self->getConfiguration();
    my $lssInstance = $cfg->getLssInstance();
    my $exePath = $lssInstance->getLssExeDir();
    my $exePathContents = listDirectory($exePath, $self->getMsgLst());

    if(!defined $exePathContents){
        $self->appendErrorMessage("$gShortProductNameLSS installation path doesn't exist on '$hostName'. Make sure that the directory is shared with '$hostName'");
        return 0;
    }

    if(!@{$exePathContents}){
        $self->appendErrorMessage("Could not list $gShortProductNameLSS installation path's contents on host '$hostName'. Make sure that the directory is shared with '$hostName'");
        return 0;
    }
    return 1;
}

1;