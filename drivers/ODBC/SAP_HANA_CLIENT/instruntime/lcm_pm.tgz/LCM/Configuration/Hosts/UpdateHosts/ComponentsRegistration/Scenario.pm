package LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::Scenario;

use strict;
use LCM::Component;
use SDB::Install::Globals qw ($gKeynameStudio $gKeynameClient $gKeynameHLM);

our $localComponentsForRegistration = [  $gKeynameStudio,
                                         $gKeynameClient,
                                         $gKeynameHLM ];
                                    
our $remoteComponentsForRegistration = [  $gKeynameClient ];


sub new {
    my ($class,$componentsManager) = @_;
    my $self = {};
    bless $self, $class;
    $self->{oComponentsManager} = $componentsManager;
    return $self;
}

sub getLocalRegistrableComponents{ return $localComponentsForRegistration }

sub getRemoteRegistrableComponents{ return $remoteComponentsForRegistration }

sub detectSkippedComponents{}

return 1;