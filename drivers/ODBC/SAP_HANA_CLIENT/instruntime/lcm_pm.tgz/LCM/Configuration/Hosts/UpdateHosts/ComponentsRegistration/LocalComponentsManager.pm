package LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::LocalComponentsManager;

use strict;
use LCM::Component;

use base qw ( LCM::Configuration::Hosts::UpdateHosts::ComponentsRegistration::SkippedComponentsManager );

sub getRegistrableComponents {
	my ($self, ) = @_;
	return $self->{oScenario}->getLocalRegistrableComponents();
}
return 1;