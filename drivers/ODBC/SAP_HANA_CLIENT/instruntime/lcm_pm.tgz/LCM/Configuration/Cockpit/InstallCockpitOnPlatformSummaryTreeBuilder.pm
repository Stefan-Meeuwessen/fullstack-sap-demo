package LCM::Configuration::Cockpit::InstallCockpitOnPlatformSummaryTreeBuilder;

use strict;
use warnings;
use SDB::Install::Globals qw($gProductNameCockpit);

use parent qw(LCM::SummaryTreeBuilder);

sub getTitle {
    my ($self,$instconfig) = @_;
    return 'Installation Parameters';
}

sub getRootText{
    my($self,$instconfig) = @_;
    return "$gProductNameCockpit System Installation";
}

1;