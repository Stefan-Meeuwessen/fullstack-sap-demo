# Dummy configuration used to provide file browsing capabilities for the webUI's Update System scenario
package LCM::Configuration::Web::FileBrowserConfiguration;

use strict;
use parent qw(SDB::Install::Configuration::AnyConfig);

sub new {
	my $self = shift()->SUPER::new (@_);
	$self->{params} = {};
	return $self;
}

sub getProductName { return "file_browser"; }

sub getAction { return "file_browser"; }

sub getWarnings { return []; }

1;
