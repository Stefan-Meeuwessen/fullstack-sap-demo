package LCM::Configuration::Web::InternalNetworkConfiguration;

use base qw(LCM::Configuration::InternalNetworkConfiguration);

use strict;

sub new{    
	my $class = shift;
	my $self = $class->SUPER::new(@_);

	$self->setValue('RemoteExecution', 'saphostagent');
	$self->setValue('Scope', 'system');

	for my $paramID ('RemoteExecution', 'Scope'){
		if(exists($self->{params}->{$paramID})){
			$self->setSkip($paramID, 1);
			$self->{params}->{$paramID}->{hidden} = 1;
		}
	}
	return $self;
}

1;