package LCM::Configuration::ValueChangeListeners::Update::LSSTrustUnsignedInstalledComponentsListener;

use strict;
use warnings;

use parent qw(LCM::Configuration::ValueChangeListeners::InstallUpdate::LSSTrustUnsignedComponentsListenerBase);

sub new {
    my ($class, $paramToSetNoRetryFor) = @_;
    my $self = $class->SUPER::new();
    $self->{shouldCheckInstalledComponents} = 1;
    $self->{shouldUseBatchValue} = 1;
    $self->{paramToSetNoRetryFor} = $paramToSetNoRetryFor;
    return $self;
}

1;