package LCM::Configuration::ValueChangeListeners::Rename::ShouldAskDBSystemPasswordListener;

sub new {
	my ( $class ) = @_;

	my $self = {};
	bless $self, $class;

	return $self;
}

sub onValueChange {
	my ( $self, $value, $instconfig ) = @_;
	if($instconfig->getValue('NoStart')) {
        $instconfig->setSkip('ChangeSystemPasswd');
    }
	return 1;
}

1;
