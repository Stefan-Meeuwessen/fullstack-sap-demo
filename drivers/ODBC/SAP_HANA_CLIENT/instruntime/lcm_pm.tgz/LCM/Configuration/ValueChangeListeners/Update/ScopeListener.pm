package LCM::Configuration::ValueChangeListeners::Update::ScopeListener;

sub new {
    my ($class, ) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
    my ($self, $value, $instconfig) = @_;

    if ( defined $value && ( $value eq 'instance' ) ) {
        if ( exists $instconfig->{params}->{RootUser} ) {
            $self->{params}->{RootUser}->{skip} = 1;
        }
    } else {
        $instconfig->{params}->{Scope}->{hidden} = 1;
    }    

    return 1;
}

1;


