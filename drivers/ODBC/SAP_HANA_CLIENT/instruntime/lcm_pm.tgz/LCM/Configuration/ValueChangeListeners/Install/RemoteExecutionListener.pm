package LCM::Configuration::ValueChangeListeners::Install::RemoteExecutionListener;

use strict;

sub new {
    my ($class, ) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
	my ($self, $value, $instconfig) = @_;

	if ($value eq 'saphostagent') {
		$instconfig->setUseSidadmUserForRemoteHostctrlHosts(0);
	}

	return 1;
}

1;
