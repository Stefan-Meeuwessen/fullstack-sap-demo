package LCM::Configuration::ValueChangeListeners::FillingRolesHostmapListener;

use strict;

sub new { return bless({}, shift()); }

sub onValueChange {
    my ($self, $value, $instconfig) = @_;
    my $systemHosts = $instconfig->getSystemHosts();
    
    if( defined $instconfig->{params}->{AddRoles} ){
        $instconfig->{params}->{AddRoles}->{origin_values} = [ @{$systemHosts} ];
        $instconfig->{params}->{AddRoles}->{default_map} = undef;
    }
    
    return 1;
}

1;
