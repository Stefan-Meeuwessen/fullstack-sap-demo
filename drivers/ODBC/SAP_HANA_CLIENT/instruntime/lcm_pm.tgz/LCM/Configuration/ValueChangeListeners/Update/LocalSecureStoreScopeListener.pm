package LCM::Configuration::ValueChangeListeners::Update::LocalSecureStoreScopeListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gSecureStoreTypeLSS);

use parent qw(SDB::Install::Base);

sub new {
    my ($class) = @_;
    bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $hdbInstance = $config->getOwnInstance();
    return 1 if !defined $value || $value ne $gSecureStoreTypeLSS || !$config->isScopeInstance() || !defined $hdbInstance || $hdbInstance->hostIsActiveMaster();

    my $activeMasterHost = $hdbInstance->getActiveMaster();
    if(!defined $activeMasterHost) {
        return $self->_exitWithSecureStoreScopeListenerError(
            $config,
            'The active nameserver master hostname cannot be determined. Ensure that it is set in nameserver.ini.'
        );
    }

    my $secureStoreParamStr = $config->getString('SecureStore');
    return $self->_exitWithSecureStoreScopeListenerError(
        $config,
        "$secureStoreParamStr migration to $gSecureStoreTypeLSS cannot be performed when using scope 'instance' on the local host. " .
        "Run hdblcm on host '$activeMasterHost'."
    );
}

sub _exitWithSecureStoreScopeListenerError {
    my ($self, $config, $message) = @_;
    $config->setErrorMessage($message);
    $config->setNoRetry('SecureStore', 1);
    return 0;
}

1;