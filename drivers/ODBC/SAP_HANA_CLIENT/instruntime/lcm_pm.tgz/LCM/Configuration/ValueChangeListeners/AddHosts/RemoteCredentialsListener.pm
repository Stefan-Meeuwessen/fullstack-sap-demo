package LCM::Configuration::ValueChangeListeners::AddHosts::RemoteCredentialsListener;
use strict;

use SDB::Install::Globals qw($gHostRoleXS2Worker);

sub new {
    my ($class) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange{
    my ($self, $value, $configuration) = @_;
    $configuration->unskipLoadInitialContentParamsIfNecessary($value);
    return 1;
}

1;
