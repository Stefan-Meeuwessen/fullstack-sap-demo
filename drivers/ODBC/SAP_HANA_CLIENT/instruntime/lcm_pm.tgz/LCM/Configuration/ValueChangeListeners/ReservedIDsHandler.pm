package LCM::Configuration::ValueChangeListeners::ReservedIDsHandler;

use strict;
use SDB::Install::Globals qw($gKeynameLSS);

sub new {
    my ($class, $paramId, $isUID) = @_;
    my $self = bless( {}, shift );
    $self->{paramID} = $paramId;
    $self->{isUID} = $isUID;
    return $self;
}

sub onValueChange {
    my ($self, $value, $config) = @_;

    my $paramID = $self->{paramID};
    my $isUID = $self->{isUID};
    if ($isUID){
        $config->addReservedUserID($paramID, $value);
    } else {
        $config->addReservedGroupID($paramID, $value);
    }

    my $isLSSPartOfSystem = $self->_isLSSPartOfSystem($config);
    my $hasLSSUserID = defined $config->getValue('LSSUserID') || $paramID eq 'LSSUserID';
    if ($isUID && !$hasLSSUserID && $isLSSPartOfSystem){
        $config->initLSSUserID();
    }

    if ($paramID eq 'GID' && $isLSSPartOfSystem){
        $config->initLSSGroupID();
    }

    #we attach handling for the next parameter when the previous one's listener is called
    if ($paramID eq 'LSSGroupID' || ($paramID eq 'GID' && !$isLSSPartOfSystem)) {
        $config->initSHMGroupID();
    }

    return 1;
}

sub _isLSSPartOfSystem {
    my ($self, $config) = @_;
    return $config->isComponentSelected($gKeynameLSS);
}

sub configurationChanged {
    my ($self, $event) = @_;
    return 1 if (! defined $event || $event->{property} ne 'skip');

    my $userPattern = '(^UID$|UserI[dD])';
    my $groupPattern = '(^GID$|GroupI[dD])';
    if($event->{newValue} == 1 && $event->{paramId} =~ /$userPattern/){
        $event->{config}->deleteUnnesessaryReservedUserIDs();
    } elsif($event->{newValue} == 1 && $event->{paramId} =~ /$groupPattern/) {
        $event->{config}->deleteUnnesessaryReservedGroupIDs();
    }
    return 1;
}

1;
