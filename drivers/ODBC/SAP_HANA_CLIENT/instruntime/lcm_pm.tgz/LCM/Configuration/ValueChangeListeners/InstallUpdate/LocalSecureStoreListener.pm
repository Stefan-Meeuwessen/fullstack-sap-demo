package LCM::Configuration::ValueChangeListeners::InstallUpdate::LocalSecureStoreListener;

use strict;
use warnings;

sub new { return bless({}, shift()); }

sub onValueChange {
    my ($self, $value, $config) = @_;
    if ($value) {
        my $deprecatedParam = $config->getOpt('LSSTrustUnsignedServer');
        my $newParam = $config->getOpt('LSSTrustUnsignedComponents');
        my $deprecationMessage = "${deprecatedParam} parameter is deprecated and will be ignored. " .
                                 "The new parameter ${newParam} will be used instead.";
        $config->addParameterWarning('LSSTrustUnsignedServer', $deprecationMessage);
        $config->setValue('LSSTrustUnsignedComponents', $value);
    }
    return 1;
}

1;