package LCM::Configuration::ValueChangeListeners::RemoveLSSCompatibleRolesListener;

use strict;
use warnings;

use SDB::Install::Globals qw(GetLssCompatibleHostRoles $gShortProductNameLSS);

use parent qw(SDB::Install::Base);

sub new {
    my ($class, $paramId) = @_;
    my $self = $class->SUPER::new();
    $self->{_paramId} = $paramId;
    return $self;
}

sub onMapValueChange {
    my ($self, $valKey, $value, $configuration) = @_;
    $self->_setConfiguration($configuration);
    return 1 if !defined $configuration->getOwnInstance()->getLssInstance();
    return $self->_canRolesBeRemovedFromHost($valKey, $value);
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;
    $self->_setConfiguration($configuration);
    return 1 if !$value; # do not force role removal, attached to ForceRemoveHosts in GenericStackUninstallation
    return 1 if !defined $configuration->getOwnInstance()->getLssInstance(); # avoid LSS checks for each host

    my $hostsWithRolesToRemove = $configuration->getValue('RemoveRoles') // {};
    foreach my $host (sort keys %{$hostsWithRolesToRemove}) {
        return 0 if !$self->_canRolesBeRemovedFromHost($host, $hostsWithRolesToRemove->{$host});
    }

    return 1;
}

sub _canRolesBeRemovedFromHost {
    my ($self, $host, $rolesCsv) = @_;
    my $configuration = $self->_getConfiguration();
    my $instance = $configuration->getOwnInstance();
    my $lssCompatibleSystemHosts = $configuration->getLssCompatibleSystemHosts($instance);
    return 1 if !grep { $_ eq $host } @{$lssCompatibleSystemHosts};

    my $currentRolesMap = $instance->getHostRolesInfo() // {};
    my @currentHostRoles = split(/\s/, $currentRolesMap->{$host} // '');

    if(!@currentHostRoles) {
        $self->_throwError("Cannot determine the roles of host '$host'");
        return 0;
    }

    my @rolesToRemove = split(',', $rolesCsv // '');
    my @targetLssCompatibleHostRoles = ();
    my @lssCompatibleHostRolesToRemove = ();
    my @lssCompatibleHostRoles = GetLssCompatibleHostRoles();

    foreach my $currentRole (@currentHostRoles) {
        # C-style logical or doesn't work with two greps with 'eq' comparison, so we use the lower-precedence 'or'
        # Sending regards to Larry, look up his name in the code for similar cases
        if (grep { $_ eq $currentRole } @rolesToRemove or !grep { $_ eq $currentRole } @lssCompatibleHostRoles) {
            next;
        }
        push(@targetLssCompatibleHostRoles, $currentRole);
    }

    return 1 if @targetLssCompatibleHostRoles;

    foreach my $roleToRemove (@rolesToRemove) {
        next if !grep { $_ eq $roleToRemove } @lssCompatibleHostRoles;
        push(@lssCompatibleHostRolesToRemove, $roleToRemove);
    }

    $self->_throwError(
        'Role' . (@lssCompatibleHostRolesToRemove > 1 ? 's' : '') . " '" . join(', ', @lssCompatibleHostRolesToRemove) .
        "' cannot be removed from host '$host' due to additional $gShortProductNameLSS configuration requirements. " .
        "To proceed, remove the selected host and add it again with the desired roles."
    );
    return 0;
}

sub _throwError {
    my ($self, $errorMessage) = @_;
    my $configuration = $self->_getConfiguration();
    $configuration->setErrorMessage($errorMessage);
    $configuration->setNoRetry($self->_getParamId(), 1) if defined $self->_getParamId();
    return 1;
}

sub _getParamId {
    my ($self) = @_;
    return $self->{_paramId};
}

sub _setConfiguration {
    my ($self, $configuration) = @_;
    $self->{_configuration} = $configuration;
}

sub _getConfiguration {
    my ($self) = @_;
    return $self->{_configuration};
}

1;