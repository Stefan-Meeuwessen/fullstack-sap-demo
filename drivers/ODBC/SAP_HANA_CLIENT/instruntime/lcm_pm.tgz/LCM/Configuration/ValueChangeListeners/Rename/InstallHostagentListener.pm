package LCM::Configuration::ValueChangeListeners::Rename::InstallHostagentListener;

use strict;

sub new{
     my ( $class ) = @_;
     my $self = {};
     bless $self, $class;
     return $self;
}

sub onValueChange{
    my ( $self, $value, $instconfig ) = @_;
    return 1 if !$value || !$instconfig->isRegisterScenario();
    if(!$instconfig->isUseSAPHostagent()) {
        $instconfig->enableHostagentPasswordIfRequired();
    }

    return 1;
}

1;
