package LCM::Configuration::ValueChangeListeners::Cockpit::Uninstall::TenantDBNameListener;

use strict;

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;
    my $keepCockpitTenantParam = $configuration->{params}->{KeepCockpitTenant};
    my $paramString = sprintf($keepCockpitTenantParam->{str_templ}, $value);
    $keepCockpitTenantParam->{str} = $paramString;

    return 1;
}

1;