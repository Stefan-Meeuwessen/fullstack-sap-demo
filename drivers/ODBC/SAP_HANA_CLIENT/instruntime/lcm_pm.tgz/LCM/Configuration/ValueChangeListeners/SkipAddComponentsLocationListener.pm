package LCM::Configuration::ValueChangeListeners::SkipAddComponentsLocationListener;

use strict;
use warnings;

sub new {
    my ($class) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    $config->setInteractive('AddComponentsLocation', 0);
    return 1;
}

1;