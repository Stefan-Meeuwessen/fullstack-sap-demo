package LCM::Configuration::ValueChangeListeners::InstallUpdate::SecureStoreListener;

use strict;
use warnings;

sub new {
    my ($class) = @_;
    return bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $unsignedComponentsParamValue = $config->getValue('LSSTrustUnsignedComponents');
    my $systemUsage = $config->getSystemUsage();
    return 1 if !$unsignedComponentsParamValue || $systemUsage !~ /development|custom/;
    $config->setSkip('LSSTrustUnsignedComponents', 1, "It is not applicable for the current system usage '$systemUsage'.");
    return 1;
}

1;