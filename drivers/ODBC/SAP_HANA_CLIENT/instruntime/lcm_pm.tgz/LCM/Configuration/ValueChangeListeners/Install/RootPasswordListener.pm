package LCM::Configuration::ValueChangeListeners::Install::RootPasswordListener;

use strict;

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    $config->checkSslCiphersConfig();
}

1;
