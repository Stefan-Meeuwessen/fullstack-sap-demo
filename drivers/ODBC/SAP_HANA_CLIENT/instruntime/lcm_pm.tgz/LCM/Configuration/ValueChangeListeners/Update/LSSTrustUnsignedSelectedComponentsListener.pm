package LCM::Configuration::ValueChangeListeners::Update::LSSTrustUnsignedSelectedComponentsListener;

use strict;
use warnings;

use SDB::Install::System qw(isAdmin);

use parent qw(LCM::Configuration::ValueChangeListeners::InstallUpdate::LSSTrustUnsignedComponentsListenerBase);

sub new {
    my ($class, $paramToSetNoRetryFor) = @_;
    my $self = $class->SUPER::new();
    $self->{shouldCheckInstalledComponents} = 0;

    # Both installed and selected components are checked during 'SelectedComponents' when update is ran as root.
    $self->{shouldCheckBothInstalledAndSelected} = isAdmin();

    $self->{shouldUseBatchValue} = 1;
    $self->{paramToSetNoRetryFor} = $paramToSetNoRetryFor;
    return $self;
}

1;