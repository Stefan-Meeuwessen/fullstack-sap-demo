package LCM::Configuration::ValueChangeListeners::SIDHelperBase;

use LCM::Configuration::NewDBUser::NewDBUser;

sub ConfigUsername {
	my ($config, $user) = @_;

	if ( !defined $config || !defined $user) {
		return 0;
	}

	$config->{user} = $user->getSidAdm();
	$config->{username} = $user->getSidAdmName();
	$config->{params}->{Password}->{'str'} = "System Administrator ($config->{username}) Password";

    return 1;
}

1;
