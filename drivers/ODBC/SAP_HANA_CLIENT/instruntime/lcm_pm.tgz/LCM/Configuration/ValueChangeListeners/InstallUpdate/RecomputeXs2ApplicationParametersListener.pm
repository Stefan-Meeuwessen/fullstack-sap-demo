package LCM::Configuration::ValueChangeListeners::InstallUpdate::RecomputeXs2ApplicationParametersListener;

use strict;

sub new {
	return bless({}, shift());
}

sub onValueChange {
	my ($self, undef, $configuration) = @_;
	$configuration->_recomputeXs2ApplicationParameters();
	return 1;
}

sub onMapValueChange {
	my ($self, undef, undef, $configuration) = @_;
	return $self->onValueChange(undef, $configuration);
}

1;
