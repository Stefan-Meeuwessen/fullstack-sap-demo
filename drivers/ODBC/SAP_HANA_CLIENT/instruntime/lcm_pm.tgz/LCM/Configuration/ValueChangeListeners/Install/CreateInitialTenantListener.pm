package LCM::Configuration::ValueChangeListeners::Install::CreateInitialTenantListener;

sub new {
	return bless {}, shift;
}

sub onValueChange {
	my ($self, $value, $instconfig) = @_;
	if($value){
	    $instconfig->{params}->{TenantUser}->{value} = 'SYSTEM';
	}
	return 1;
}

1;