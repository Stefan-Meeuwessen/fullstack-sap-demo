package LCM::Configuration::ValueChangeListeners::Update::XS::XsRequireRestartListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gKeynameXS2);

use parent qw(SDB::Install::Base);

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $xsaComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameXS2);
    return 1 if !defined $xsaComponent;

    my $selectedISCMode = $config->getValueOrBatchValue('ISCMode');
    $selectedISCMode //= 'ssl'; # During XSA installation if the ISCMode is not set we default to 'ssl'.

    my $saveContext = $config->setMsgLstContext($self->getMsgLstContext());
    my $requiresRestart = $config->isISCModeChangeNeeded($selectedISCMode);
    $config->setMsgLstContext($saveContext);
    return 1 if !$requiresRestart;

    $xsaComponent->{requireSystemRestart} = 1;
    return 1;
}

1;