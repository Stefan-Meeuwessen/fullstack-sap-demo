package LCM::Configuration::ValueChangeListeners::Cockpit::Uninstall::OrgnameStringListener;

use strict;

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $xsSpace, $configuration) = @_;
    my $orgNameParam = $configuration->{params}->{OrgName};
    my $paramString = sprintf($orgNameParam->{str_templ}, $xsSpace);
    $orgNameParam->{str} = $paramString;

    return 1;
}

1;