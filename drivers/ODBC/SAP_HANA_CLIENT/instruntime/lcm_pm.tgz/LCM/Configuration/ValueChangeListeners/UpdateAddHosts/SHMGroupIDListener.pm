package LCM::Configuration::ValueChangeListeners::UpdateAddHosts::SHMGroupIDListener;

use strict;
use warnings;

use SDB::Common::Utils qw(getSHMGroupName checkOsGroupID);
use SDB::Common::BuiltIn;

use parent qw(SDB::Install::Base);

sub new {
    my ($class, $paramId) = @_;
    my $self = {
        _paramId => $paramId
    };
    bless $self, $class;
}

sub _getParamId{
    my ($self) = @_;
    return $self->{_paramId};
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    $self->setMsgLstContext($config->getMsgLstContext());
    my $paramID = $self->_getParamId();
    return 0 if !defined $paramID;

    my $sapsys = $config->getSAPSystem();
    my $userConfig = $sapsys->getUserConfig();

    #sidshm is created with the user cfg information later in createuserfromconfig
    #if user cfg does not hold sidshm value, we try to collect it from local host for backward compatibility
    #in such case, the group creation will work like it did before
    my $shmGroupID = $userConfig->{sidshm_groupid} if defined $userConfig;

    my $targetSID = $config->getValue('newSID') // $config->getValue('SID');
    my $sidshmGroupName = getSHMGroupName($targetSID);
    $shmGroupID //= SDB::Common::BuiltIn->get_instance()->getgrnam($sidshmGroupName);

    if (!defined $shmGroupID) {
        $self->setErrorMessage("Cannot determine the '${sidshmGroupName}' group ID. Make sure that '${sidshmGroupName}' exists with the same ID on every host.");
        $config->setNoRetry($paramID, 1);
        return 0;
    }

    my $rc = 1;
    $rc &&= checkOsGroupID($config, 'SHMGroupID', $sidshmGroupName, $shmGroupID, 0);
    $rc &&= $config->checkReservedOSGroupIDs($shmGroupID, 'SHMGroupID');

    $config->setNoRetry($paramID, 1) if !$rc;
    return $rc;
}

1;