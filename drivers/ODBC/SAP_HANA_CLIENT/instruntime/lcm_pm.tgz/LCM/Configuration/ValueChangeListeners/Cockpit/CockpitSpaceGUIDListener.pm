package LCM::Configuration::ValueChangeListeners::Cockpit::CockpitSpaceGUIDListener;

use strict;

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $guid, $configuration) = @_;
    my $scm = $configuration->getSystemComponentManager();
# Here explicitly leave the possibility to set the Component registry to undef
# Otherwise it may turn out that the component registry is set to sap and this
# may not be the desired behaviour
    $scm->switchXSComponentRegistry($guid);

    return $configuration->fillValidSelectedXs2ApplicationsValues();
}

1;