package LCM::Configuration::ValueChangeListeners::Update::HandleLSSUserAndGroupListener;

use strict;

sub new {
    my ($class) = @_;
    my $self = bless({}, shift());
    return $self;
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;
    return $configuration->initLSSGroupAndUserID();
}

1;
