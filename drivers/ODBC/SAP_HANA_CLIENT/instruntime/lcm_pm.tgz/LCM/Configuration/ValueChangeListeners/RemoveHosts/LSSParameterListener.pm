package LCM::Configuration::ValueChangeListeners::RemoveHosts::LSSParameterListener;

use strict;
use warnings;

use parent qw( LCM::Configuration::ValueChangeListeners::LSSParameterListener );
use SDB::Install::Globals qw(GetLssCompatibleHostRoles);

sub shouldSkipLssParams {
    my ($self, $value, $configuration) = @_;
    return 1 if($self->SUPER::shouldSkipLssParams($value, $configuration));
    my $detector = $configuration->getRemoveHostsDetector();
    my $removeHosts = $detector->getHostsFromUserInput($value) // [];
    return $self->isRemovingLssCompatibleHost($removeHosts, $detector) ? 0 : 1;
}

sub isRemovingLssCompatibleHost {
    my ($self, $removeHosts, $detector) = @_;
    foreach my $role (GetLssCompatibleHostRoles()) {
        if (grep { $detector->isHostInRole($_, $role) } @$removeHosts) {
            return 1;
        }
    }
    return 0;
}

1;
