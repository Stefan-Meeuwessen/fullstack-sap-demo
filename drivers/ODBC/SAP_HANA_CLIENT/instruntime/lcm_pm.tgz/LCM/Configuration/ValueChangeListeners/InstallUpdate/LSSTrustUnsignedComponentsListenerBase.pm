package LCM::Configuration::ValueChangeListeners::InstallUpdate::LSSTrustUnsignedComponentsListenerBase;

use strict;
use warnings;

use LCM::App::ApplicationContext;

use parent qw(LCM::Configuration::ValueChangeListeners::AnyLSSTrustUnsignedComponentsListener);

sub new {
    my ($class) = @_;
    return $class->SUPER::new();
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $appContext = LCM::App::ApplicationContext::getInstance();
    return 1 if $appContext->isSLP();
    return $self->SUPER::onValueChange($value, $config);
}

sub getErrorInstructionPostfix {
    my ($self, $config) = @_;
    my $option = $config->getOpt('LSSTrustUnsignedComponents');
    return "use the option '${option}'";
}

1;