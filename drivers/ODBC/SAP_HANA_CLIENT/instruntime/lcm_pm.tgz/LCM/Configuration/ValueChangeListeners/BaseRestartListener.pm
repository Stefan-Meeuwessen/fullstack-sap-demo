package LCM::Configuration::ValueChangeListeners::BaseRestartListener;

use strict;
use warnings;

use LCM::App::ApplicationContext;

sub new { return bless({}, shift()); }

sub onValueChange {
    ...
}

sub getRestartRequiredMessage {
    my ($self, $isScopeInstance) = @_;
    my $flavourProductName = LCM::App::ApplicationContext::getFlavourProductName();
    my $scope = $isScopeInstance ? 'instance' : 'system';
    return "The $flavourProductName $scope will be restarted";
}

sub getStopRequiredMessage {
    my ($self, $flavourProductName, $isScopeInstance) = @_;
    $flavourProductName //= LCM::App::ApplicationContext::getFlavourProductName();
    my $scope = $isScopeInstance ? 'instance' : 'system';
    return "The $flavourProductName $scope will be stopped";
}

1;