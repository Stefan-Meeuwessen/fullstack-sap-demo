package LCM::Configuration::ValueChangeListeners::InstallUpdate::SelectedXs2ComponentsListener;

use strict;
use SDB::Install::Version;
use SDB::Install::Globals qw($gShortProductNameXS2);

my $KEY_NAME_ALL = 'all';
my $KEY_NAME_NONE = 'none';
my $ERROR_MESSAGE_SELECTION_CONFLICT = 'Some of the provided values are conflicting with each other';

sub new {
	return bless({}, shift());
}

sub onValueChange {
	my ($self, $value, $configuration) = @_;
	my $selectedComponentKeyNames = [ split(/\s*,\s*/, $value) ];
	my $hasConflictingSelection = $self->_hasConflictingSelection($selectedComponentKeyNames);

	if($hasConflictingSelection){
		$configuration->setErrorMessage($ERROR_MESSAGE_SELECTION_CONFLICT);
		return undef;
	}

	$self->_selectComponentsBasedOnUserInput($selectedComponentKeyNames, $configuration);
	my $rc = $configuration->validateXs2ComponentDependencies() &&
			 $configuration->validateDependenciesToXs2Components();

	return $rc ? 1 : undef;
}

sub _selectComponentsBasedOnUserInput {
	my ($self, $selectedComponentKeyNames, $configuration) = @_;
	my $componentManager = $configuration->getMediumComponentManager();
	my $allComponents = $componentManager->getXs2ApplicationComponents();

	for my $component (@{$allComponents}){
		my $shouldSelectComponent = $self->_shouldSelectComponent($component, $selectedComponentKeyNames);
		$component->selectComponent($shouldSelectComponent);
	}
}

sub _shouldSelectComponent {
	my ($self, $component, $selectedComponentKeyNames) = @_;
	my $componentKey = $component->getComponentKeyName();
	my $isSelectingAll = grep { $_ eq $KEY_NAME_ALL } @{$selectedComponentKeyNames};
	my $isSelectingComponent = grep { $_ eq $componentKey } @{$selectedComponentKeyNames};

	return ($isSelectingAll || $isSelectingComponent) ? 1 : 0;
}

sub _hasConflictingSelection {
	my ($self, $selectedComponentKeyNames) = @_;
	my $hasSelectedMultipleComponents = scalar(@{$selectedComponentKeyNames}) > 1;
	my $hasSelectedAllComponents = grep { $_ eq $KEY_NAME_ALL } @{$selectedComponentKeyNames};
	my $hasSelectedNoneComponents = grep { $_ eq $KEY_NAME_NONE } @{$selectedComponentKeyNames};
	my $isConflictingSelection = $hasSelectedMultipleComponents && ($hasSelectedAllComponents || $hasSelectedNoneComponents);

	return $isConflictingSelection ? 1 : 0;
}

1;