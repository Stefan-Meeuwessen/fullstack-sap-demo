package LCM::Configuration::ValueChangeListeners::AddHostSIDListener;

sub new {
    my ($class, ) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}


sub onValueChange {
    my ($self, $value, $instconfig) = @_;
    my $sidAdmName = $instconfig->getSysAdminUserName($value);
    $instconfig->{params}->{Password}->{'str'} = "System Administrator ($sidAdmName) Password";
    return 1;
}

1;