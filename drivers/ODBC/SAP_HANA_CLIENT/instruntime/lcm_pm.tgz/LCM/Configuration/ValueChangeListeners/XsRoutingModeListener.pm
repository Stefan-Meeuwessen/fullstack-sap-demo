package LCM::Configuration::ValueChangeListeners::XsRoutingModeListener;

use strict;
use warnings;
use SDB::Install::Globals qw($gHostRoleXS2Worker $gXsRoutingModePorts $gXsRoutingModeHostnames);

our $XS_DOMAIN_NAME_PARAM = 'XsDomainName';
our $XS_ROUTING_MODE_PARAM = 'RoutingMode';

sub new {
    my ($class) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
    my ($self, $value, $instconfig) = @_;
    my $appContext = LCM::App::ApplicationContext::getInstance();
    my $isCLIorBatch = $appContext->isCLIorBatch();

    if(!$isCLIorBatch){
        my $oldRoutingModeValue = $instconfig->getValue($XS_ROUTING_MODE_PARAM);
        return 1 if defined $oldRoutingModeValue && $oldRoutingModeValue eq $value;
    }

    if ($value eq $gXsRoutingModeHostnames) {
        $instconfig->setDefault($XS_DOMAIN_NAME_PARAM, undef, 0);
        $self->_setXsDomainNameMandatoryIfNeeded($instconfig);
        return 1;
    }

    if ($value eq $gXsRoutingModePorts) {
        $instconfig->setMandatory($XS_DOMAIN_NAME_PARAM, 0);
        $instconfig->setDefault($XS_DOMAIN_NAME_PARAM, $instconfig->getDefaultXsControllerHost());
        return 1;
    }

    $instconfig->appendErrorMessage("Invalid value '$value' of RoutingMode parameter.");
    return 0;
}

sub _setXsDomainNameMandatoryIfNeeded {
    my ($self, $instconfig) = @_;
    my $addHostsWithRoleXsWorker = $instconfig->getAddHostsWithRole($gHostRoleXS2Worker);
    my $isAutoAssignEnabled = $instconfig->getValue('AutoAddXS2Roles') && !$instconfig->isSkipped('AutoAddXS2Roles');

    if ($isAutoAssignEnabled || @{$addHostsWithRoleXsWorker}) {
        $instconfig->setMandatory($XS_DOMAIN_NAME_PARAM, 1);
    }
    return 1;
}

1;