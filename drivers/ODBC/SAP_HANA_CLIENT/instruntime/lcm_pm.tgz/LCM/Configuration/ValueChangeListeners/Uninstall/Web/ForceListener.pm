package LCM::Configuration::ValueChangeListeners::Uninstall::Web::ForceListener;

use strict;
use parent qw(LCM::Configuration::ValueChangeListeners::Uninstall::ForceListener);

# Override
# Always show KeepUser & KeepUserHomeDir in the Advanced Configuration dialog
# of the web user interface
sub _shallSkipUserParameters {
    return 0;
}

1;