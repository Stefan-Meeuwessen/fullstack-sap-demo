package LCM::Configuration::ValueChangeListeners::AddHosts::AddHostRootCredentialsListener;
use parent qw (LCM::Configuration::ValueChangeListeners::PostCollectHostInfoChecksListener);

sub new {
    my ($class) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    return 0 if (!$self->checkCollectedHostInfo($config));
    $config->fillInternalNetworkAndListenInterfaceValidValues();
    return 1;
}

1;
