package LCM::Configuration::ValueChangeListeners::ExtractComponents::SelectedArchivesListener;

use strict;
use LCM::Installer;
use LCM::Utils::CommonUtils qw(getHdblcmUploadDirectory);

sub new {
    my $class = shift();
    return bless({}, $class);
}

sub onValueChange {
    my ($self, undef, $configuration) = @_;
    my $installer = new LCM::Installer();
    my $sid = $installer->getSid();
    my $uploadRoot = getHdblcmUploadDirectory($sid);

    return $configuration->setValue('ComponentArchivesPath', $uploadRoot);
}

1;