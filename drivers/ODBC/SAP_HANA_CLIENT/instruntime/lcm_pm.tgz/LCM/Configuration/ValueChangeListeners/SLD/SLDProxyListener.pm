package LCM::Configuration::ValueChangeListeners::SLD::SLDProxyListener;

use strict;
use warnings;

our @SLD_PROXY_PARAMETERS = ('SLDProxyUser', 'SLDProxyPassword', 'SLDProxyHost', 'SLDProxyPort');

sub new {
    my ($class) = @_;
    bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;

    if ($value) {
        foreach my $proxyParam (@SLD_PROXY_PARAMETERS) {
            $config->setSkip($proxyParam, 0);
        }
    }

    return 1;
}

1;