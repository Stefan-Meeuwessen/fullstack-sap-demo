package LCM::Configuration::ValueChangeListeners::InstallUpdate::SelectedComponentsListenerBase;

use strict;
use LCM::Component qw($componentKeynameToBatchKey);
use LCM::Utils::CommonUtils;
use LCM::SignatureFileChecker;
use SDB::Install::System qw(isAdmin);
use SDB::Install::Globals qw(
    $gSignatureManifestName
    $gProductNameEngine
    $gProductNameClient
    $gProductNameStudio
    $gKeynameXS2
    $gKeynameEngine
    $gKeynameInstaller
    $gOptionOptimizedExecutionMode
    $gOptionStandardExecutionMode
    $gKeynameLSS
    $gSecureStoreTypeLSS
    $gKeynameClient
    $gKeynameStudio
    $gParameterUnsupportedByEngine
    $gParameterAvailableDuringComponentInstallationUpdateWarning
);
use LCM::FeatureManager::GenericFeatureManager qw(LSS_TRUST_UNSIGNED_COMPONENTS);
use LCM::FeatureManager::Feature;
use SDB::Install::Version;
use LCM::Configuration::GenericStackAny qw(
    $ini_section_client
    $ini_section_plugin
    $ini_section_server
    $ini_section_studio
);

sub new {
	return bless({}, shift());
}

sub onValueChange {
	my ($self, $selectedCmpsValue, $instconfig) = @_;

	return undef if(!$instconfig->fillSelectedComponents($selectedCmpsValue));

	$self->_handleExecutionModeDefaultValue($instconfig); # can only be handled after selected components are filled

	return undef if(!$instconfig->handleSelectionOfResidentInstaller());
	return undef if(!$instconfig->validateDependencies());
	return undef if(!$instconfig->validateLSSDependency());
	return undef if(!$self->_checkSignatureFile($instconfig));

	#_recomputeRequiredParameters skips all Client/Studio parameters, even the pass through parameters without a specific warning if the respective component is not selected
	# we need specific skip messages for the pass through parameters so those have to be skipped first
	$self->_handlePassThroughParameters($instconfig);
	$instconfig->_recomputeRequiredParameters();
	$instconfig->fillCertificatesHostmapDefaultValuesAndLocalData();
	$instconfig->setSkip('AutoAddXS2Roles', $self->_shallSkipAutoAddXs2Roles($instconfig));
	$instconfig->setSkip('ImportContentXS2', $self->_shallSkipImportContentXS2($instconfig));
	$instconfig->setSkip('ISCMode', $self->_shallSkipISCMode($instconfig));
	$instconfig->setSkip('XSComponentsCfg', $self->_shallSkipXSComponentsCfg($instconfig));
	$self->_initISCModeDefaultValue($instconfig);

	my $skipReferenceDataPath = $self->_shallSkipReferenceDataPath($instconfig);
	$instconfig->setSkip('ReferenceDataPath', $skipReferenceDataPath);
	$self->_skipUnsupportedParams($instconfig);
	$self->_handleLssRelatedFeatures($instconfig);
	$self->handleServerRelatedParameters($instconfig);
	$self->_handleSecureStoreDefaultValue($instconfig);
	$self->_handleEncryptionAlgorithmSkipping($instconfig);
	$instconfig->handleNecessarilyFROInstallOrUpgradeParams();

	return 1;
}

sub addResumeActionProgressMsg {
	my ($self, $configuration) = @_;

	if ($configuration->getComponentManager()->existsSelectedComponentInPendingState($configuration)) {
		my $persistenceData = $configuration->pers_load();
		return if (!defined $persistenceData);
		my $pendingStepName = $configuration->pers_getstepname($persistenceData->{step});
		$configuration->AddProgressMessage ("Resuming pending " . $configuration->getAction() . " at step '${pendingStepName}'");
	}
}

sub _shallSkipAutoAddXs2Roles {
	my ($self, $configuration) = @_;
	my $componentManager = $configuration->getComponentManager();
	my $xs2Component = $componentManager->getComponentByKeyName($gKeynameXS2);

	my $hasAutoAddXS2RolesPersistedValue = defined $configuration->getPersistedValue('AutoAddXS2Roles');
	my $isPendingInstall = ! $configuration->isUpdate() && $configuration->isPostServerResumeInstallation();
	return 0 if $isPendingInstall && $hasAutoAddXS2RolesPersistedValue;

	my $isPendingUpdate = $configuration->isUpdate() && $configuration->isPendingUpdate();
	return 0 if $isPendingUpdate && $hasAutoAddXS2RolesPersistedValue;

	return defined($xs2Component) && $xs2Component->isComponentSelected() && ! $xs2Component->isUpdate() ? 0 : 1;
}

sub _shallSkipImportContentXS2 {
    my ($self, $configuration) = @_;
    my $componentManager = $configuration->getComponentManager();
    my $xs2Component = $componentManager->getComponentByKeyName($gKeynameXS2);

    return defined($xs2Component) && $xs2Component->isComponentSelected() ? 0 : 1;
}

sub _shallSkipISCMode {
    my ($self, $configuration) = @_;
    my $componentManager = $configuration->getComponentManager();

    for my $componentKeyname ($gKeynameXS2, $gKeynameEngine){
        my $component = $componentManager->getComponentByKeyName($componentKeyname);
        return 0 if(defined($component) && $component->isComponentSelected())
    }
    return 1;
}

sub _shallSkipXSComponentsCfg {
    my ($self, $configuration) = @_;
    my $componentManager = $configuration->getComponentManager();
    my $xs2Component = $componentManager->getComponentByKeyName($gKeynameXS2);
    return defined($xs2Component) && $xs2Component->isComponentSelected() ? 0 : 1;
}

sub _checkSignatureFile {
	my ($self, $instconfig) = @_;
	my $componentManager = $instconfig->getComponentManager();
	my $installerComponent = $componentManager->getComponentByKeyName($gKeynameInstaller);

	return 1 if(! defined($installerComponent));
	return 1 if(! $installerComponent->isComponentSelected());
	if($instconfig->getIgnore('check_signature_file') && isAdmin()){
		$instconfig->getMsgLst()->addMessage("Ignoring $gSignatureManifestName file check due to --ignore command line switch");
		return 1;
	}

	if($instconfig->getIgnore('check_signature_file')){
		$instconfig->getErrMsgLst()->addError("Ignore option 'check_signature_file' can only be used when the tool is started with root privileges");
		$instconfig->setNoRetry('SelectedComponents', 1);
		return undef;
	}

	my $signaturePathCandidate = $installerComponent->getPath();
	my $sapEnvironment = $instconfig->isSAPEnvironment();
	my $signatureChecker = new LCM::SignatureFileChecker($signaturePathCandidate, $sapEnvironment);
	my $signatureCheckResult = $signatureChecker->checkFile();

    if  (!$signatureCheckResult) {
        $instconfig->getErrMsgLst()->appendMsgLst($signatureChecker->getErrMsgLst());
        return undef;
    } elsif (!$signatureChecker->getMsgLst()->isEmpty()) {
        my $msgLst = $signatureChecker->getMsgLst();
        $instconfig->getMsgLst()->appendMsgLst($msgLst);
        my $message = $msgLst->getMsgLstString();
        $instconfig->addParameterWarning("SelectedComponents", $$message);
        return 1;
    }
    return 1;
}

sub _handleExecutionModeDefaultValue {
    my ($self, $instconfig) = @_;
    my $executionMode = $instconfig->shouldUseOptimizedExecution() ? $gOptionOptimizedExecutionMode : $gOptionStandardExecutionMode;

    $instconfig->setDefault('ExecutionMode', $executionMode);
}

sub _shallSkipReferenceDataPath {
    my ($self, $configuration) = @_;

    my $selectedComponents = $configuration->getComponentManager()->getSelectedComponents();
    
    for my $component ( @$selectedComponents ) {
        if ( $component->getManifest()->isReferenceData() ) {
            return 0;
        }
    }
    return 1;
}

sub _initISCModeDefaultValue {
	...
}

sub _handleDefaultTenantUserCredentials{
    my ($self, $instconfig) = @_;
    return if (!$instconfig->isSystemInCompatibilityMode());

    my $mcm = $instconfig->getComponentManager();
    my $willInstallXS2 = $mcm->willInstallComponent($gKeynameXS2, $instconfig);

    $instconfig->setSkip('TenantUser', !$willInstallXS2);
    $instconfig->setSkip('SQLTenantUserPassword', !$willInstallXS2);

    my $systemUser = $instconfig->getValue('SystemUser');
    $instconfig->setDefault('TenantUser', $systemUser) if $systemUser && $willInstallXS2;
}

# Skip these parameters if the feature is not supported by the HANA, which will be installed
# This will prevent the underlying hdbinst/hdbupd to fail with Unknown option: --secure_store/--volume_encryption
sub _skipUnsupportedParams {
    my ($self, $config) = @_;
    $self->_skipUnsupportedSecureStore($config);

    if(!$config->isUpdate()){
        $self->_skipUnsupportedVolumeAndBackupEncryptionParams($config);
    }
    return 1;
}

sub _skipUnsupportedSecureStore {
    my ($self, $config) = @_;
    my $featureManager = $config->getFeatureManager();
    my $isLssSelected = $config->isComponentSelected($gKeynameLSS);
    my $isInstallingLSS = $isLssSelected && !$config->_isComponentUpdate($gKeynameLSS);
    my $shouldSkipSecureStoreParam = !$featureManager->isSecureStoreSupported() || !$isInstallingLSS;

    $config->setSkip('SecureStore', $shouldSkipSecureStoreParam);
    return 1;
}

sub _skipUnsupportedVolumeAndBackupEncryptionParams {
    my ($self, $config) = @_;
    my $serverComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameEngine);
    return 1 if !defined $serverComponent;

    my @encryptionParams = ('BackupEncryption', 'VolumeEncryption');
    foreach my $param (@encryptionParams){
        my $isParamSupported = $serverComponent->isParamSupported($param);
        if(!$isParamSupported) {
            $config->setSkip($param, 1, $gParameterUnsupportedByEngine);
        }
    }
    return 1;
}

sub _handleLssRelatedFeatures {
    my ($self, $config) = @_;
    $self->_addTrustUnsignedComponentsFeature($config);

    my $skipTrustFeatures = $self->_areLssTrustFeaturesApplicable($config) ? 0 : 1;
    for my $param (qw(LSSTrustUnsignedServer LSSTrustUnsignedComponents)) {
        $config->setSkip($param, $skipTrustFeatures);
    }

    my $lssSkipValidationParamId = 'LSSSkipServerLibraryValidation';
    my $skipLibValidation = $self->_canSkipLssLibraryValidation($config, $lssSkipValidationParamId) ? 0 : 1;
    $config->setSkip($lssSkipValidationParamId, $skipLibValidation);

    return 1;
}

sub _areLssTrustFeaturesApplicable {
    my ($self, $config) = @_;
    return 0 if $config->isCockpitOnPlatformAction();
    return 1 if $config->isInstallingLSS();
    return 0 if !$config->isUpdate();

    my $isServerOrPluginSelected = $config->getComponentManager()->isHDBServerOrPluginSelected();
    return 1 if ($self->_isLssInstalled($config) && $isServerOrPluginSelected);
}

sub _canSkipLssLibraryValidation {
    my ($self, $config, $lssSkipValidationParamId) = @_;
    my $componentManager = $config->getComponentManager();
    my $serverComponent = $componentManager->getComponentByKeyName($gKeynameEngine);

    return 0 if defined $serverComponent && !$serverComponent->isParamSupported($lssSkipValidationParamId);
    return 1 if $config->isInstallingLSS() || $config->isUpdatingLSS();
    return 0 if !$config->isUpdate();

    return $self->_isLssInstalled($config) && $componentManager->isHDBServerComponentSelected();
}

sub _isLssInstalled {
    my ($self, $config) = @_;
    my $hdbInstance = $config->getOwnInstance();
    return defined $hdbInstance && defined $hdbInstance->getLssInstance();
}

sub _handleSecureStoreDefaultValue {
    my ($self, $configuration) = @_;
    my $paramName = 'SecureStore';

    $configuration->setDefault($paramName, $gSecureStoreTypeLSS) if $configuration->isInstallingLSS();
    return 1;
}

sub _handleEncryptionAlgorithmSkipping {
    my ($self, $configuration) = @_;
    $configuration->setSkip('EncryptionAlgorithm', 1) if !$configuration->isInstallingLSS();
    return 1;
}

sub _addTrustUnsignedComponentsFeature {
    my ($self, $config) = @_;
    my $lssComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameLSS);
    my $isLssSelected = defined($lssComponent) && $lssComponent->isComponentSelected();
    my $hdbInstance = $config->getOwnInstance();
    my $lssInstance = defined $hdbInstance ? $hdbInstance->getLssInstance() : undef;
    return 1 if !$isLssSelected && !defined $lssInstance;

    my $lssExecutable;
    if (!$isLssSelected){
        $lssComponent = $config->getSystemComponentManager()->getComponentByKeyName($gKeynameLSS);
        $lssExecutable = File::Spec->catfile($lssInstance->getLssSidDir(), 'install', 'hdbinst');
    } else {
        $lssExecutable = $lssComponent->getExecutable();
    }

    $lssComponent->setMsgLstContext($config->getMsgLstContext());
    my $featureManager = $config->getFeatureManager();
    my $sourceVersion = SDB::Install::Version->new(split(/\.|-/, $lssComponent->getLcmSdkVersion($lssExecutable)));
    $featureManager->addFeature(LCM::FeatureManager::Feature->new(LSS_TRUST_UNSIGNED_COMPONENTS,  ['2','5','30'], undef, $sourceVersion));
    return 1;
}

sub handleIncompatibleServerParameter {
    my ($self, $config, $paramId)  = @_;
    my $componentManager = $config->getComponentManager();
    my $serverComponent  = $componentManager->getComponentByKeyName($gKeynameEngine);

    if (!defined $serverComponent || !$serverComponent->isComponentSelected()) {
        my $skipWarning = $self->_getComponentNotSelectedMessageByProductName($gProductNameEngine);
        $config->setSkip($paramId, 1, $skipWarning);
        return 1;
    }

    if (!$serverComponent->isParamSupported($paramId)) {
        $config->setSkip($paramId, 1, $gParameterUnsupportedByEngine);
        return 1;
    }

    $config->setSkip($paramId, 0);
    return 0;
}

sub handleServerRelatedParameters {
    my ($self, $config) = @_;
    my @paramIds = qw(ApplyResourceLimits ConfigurePython ConfigureFastRestartOption SHMGroupID);
    foreach my $paramId (@paramIds) {
        $self->handleIncompatibleServerParameter($config, $paramId);
    }
}

sub _handlePassThroughParameters {
    my ($self, $config) = @_;
    my $passThroughParams = $config->getHdbinstHdbupdPassThroughParams();
    return 1 if !defined $passThroughParams || !@{$passThroughParams};

    my $passThroughParamsWithValues = $self->_getPassThroughParamsWithValues($config, $passThroughParams);

    foreach my $paramId (@{$passThroughParamsWithValues}) {
        $self->_skipPassThroughParamIfNeeded($config, $paramId);
    }

    return 1;
}

sub _getPassThroughParamsWithValues {
    my ($self, $config, $passThroughParamsIds) = @_;
    my $passThroughParamsWithValues = [];

    foreach my $paramId (@{$passThroughParamsIds}) {
        next if !defined $config->getValueOrBatchValue($paramId);
        push @{$passThroughParamsWithValues}, $paramId;
    }

    return $passThroughParamsWithValues;
}

sub _skipPassThroughParamIfNeeded {
    my ($self, $config, $paramId) = @_;
    my $paramSection = $config->getSection($paramId);
    return 0 if !defined $paramSection || $self->_checkComponentSelectedByIniSectionName($config, $paramSection);

    my $skipWarning = $self->_getComponentNotSelectedMessageByIniSectionName($paramSection);
    $config->setSkip($paramId, 1, $skipWarning, 1);
    return 1;
}

sub _checkComponentSelectedByIniSectionName {
    my ($self, $config, $section) = @_;
    my $componentManager = $config->getComponentManager();

    # the sections are handled according to the ones in addPassThroughParameters in GenericStackAny
    if($section eq $ini_section_client) {
        my $clientComponent = $componentManager->getComponentByKeyName($gKeynameClient);
        return defined $clientComponent && $clientComponent->isComponentSelected();
    }

    if($section eq $ini_section_server) {
        my $serverComponent = $componentManager->getComponentByKeyName($gKeynameEngine);
        return defined $serverComponent && $serverComponent->isComponentSelected();
    }

    if($section eq $ini_section_studio) {
        my $studioComponent = $componentManager->getComponentByKeyName($gKeynameStudio);
        return defined $studioComponent && $studioComponent->isComponentSelected();
    }

    if($section eq $ini_section_plugin) {
        my $selectedServerPlugins = $componentManager->getSelectedServerPluginComponents();
        return @{$selectedServerPlugins} > 0;
    }

    return undef;
}

sub _getComponentNotSelectedMessageByProductName {
    my ($self, $productName) = @_;
    return sprintf($gParameterAvailableDuringComponentInstallationUpdateWarning, $productName);
}

sub _getComponentNotSelectedMessageByIniSectionName {
    my ($self, $section) = @_;
    my $iniSectionNamesToProductNames = {
        $ini_section_client => $gProductNameClient,
        $ini_section_server => $gProductNameEngine,
        $ini_section_studio => $gProductNameStudio,
        $ini_section_plugin => 'a server plugin',
    };

    return undef if !exists $iniSectionNamesToProductNames->{$section};

    return $self->_getComponentNotSelectedMessageByProductName($iniSectionNamesToProductNames->{$section});
}

1;
