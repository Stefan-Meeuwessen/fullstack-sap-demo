package LCM::Configuration::ValueChangeListeners::Rename::XsSpaceIsolationListener;

use strict;
use base qw (LCM::Configuration::ValueChangeListeners::Rename::XsSpaceIsolation);


sub onValueChange {
    my ($self, $value, $configuration) = @_;
    return $self->handleOsUsers($configuration);
}

1;
