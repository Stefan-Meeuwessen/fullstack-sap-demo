package LCM::Configuration::ValueChangeListeners::RootUserListener;

sub new {
    my ($class) = @_;

    my $self = {};
    bless $self, $class;

    return $self;
}

sub onValueChange {
    my ($self, $value, $instconfig) = @_;

    if ( $instconfig->{params}->{RootPassword}->{skip} ) {
        $instconfig->fillCertificatesHostmapDefaultValuesAndLocalData();
    }

    return 1;
}

1;