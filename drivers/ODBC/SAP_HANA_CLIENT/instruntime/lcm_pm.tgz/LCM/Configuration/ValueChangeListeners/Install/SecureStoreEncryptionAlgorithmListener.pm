package LCM::Configuration::ValueChangeListeners::Install::SecureStoreEncryptionAlgorithmListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gSecureStoreTypeLSS);

use parent qw(SDB::Install::Base);

our $DEFAULT_ENCRYPTION_ALGORITHM = 'AES-256-CTR';

sub onValueChange {
    my ($self, $value, $config) = @_;
    return 1 if !defined $value || $value ne $gSecureStoreTypeLSS;

    $config->setDefault('EncryptionAlgorithm', $DEFAULT_ENCRYPTION_ALGORITHM, 1);
    return 1;
}

1;