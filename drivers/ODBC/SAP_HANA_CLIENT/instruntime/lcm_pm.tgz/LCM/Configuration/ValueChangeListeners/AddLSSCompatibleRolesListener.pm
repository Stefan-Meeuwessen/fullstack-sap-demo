package LCM::Configuration::ValueChangeListeners::AddLSSCompatibleRolesListener;

use strict;
use warnings;

use SDB::Install::Globals qw(GetLssCompatibleHostRoles $gShortProductNameLSS);

use parent qw(SDB::Install::Base);

sub onMapValueChange {
    my ($self, $valKey, $value, $configuration) = @_;
    my $instance = $configuration->getOwnInstance();
    return 1 if !defined $instance->getLssInstance();

    my $lssCompatibleSystemHosts = $configuration->getLssCompatibleSystemHosts($instance);
    return 1 if grep { $_ eq $valKey } @{$lssCompatibleSystemHosts};

    my @additionalRoles = split(',', $value // '');
    my @lssCompatibleHostRoles = GetLssCompatibleHostRoles();

    foreach my $additionalRole (@additionalRoles) {
        next if !grep { $_ eq $additionalRole } @lssCompatibleHostRoles;

        $configuration->setErrorMessage(
            "Role '$additionalRole' cannot be added to host '$valKey' due to additional $gShortProductNameLSS configuration requirements. " .
            "To proceed, either remove the host and add it again with the desired roles, or add a new host with role '$additionalRole'."
        );
        return 0;
    }
    return 1;
}

1;