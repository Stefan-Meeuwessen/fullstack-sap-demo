package LCM::Configuration::ValueChangeListeners::Update::ContinueUpdateListener;
use SDB::Install::Configuration qw($bool_false_pattern $bool_true_pattern);

sub new { return bless({}, $_[0]); }

sub onValueChange {
    my ($self, $value, $instconfig) = @_;

    if($value =~ /$bool_false_pattern/){
        $instconfig->handleHostsPropertiesSkipValue(0); # isPendingUpdate=0
    } elsif ($value =~ /$bool_true_pattern/) {
        $instconfig->setInteractive('AddComponentsLocation', 0);
    }
    return 1;
}

1;