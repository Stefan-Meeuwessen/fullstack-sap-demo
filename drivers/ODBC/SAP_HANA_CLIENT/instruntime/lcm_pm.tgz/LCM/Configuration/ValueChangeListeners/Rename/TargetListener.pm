package LCM::Configuration::ValueChangeListeners::Rename::TargetListener;
use SDB::Install::SysVars qw($path_separator $isWin);

sub new {
	my ( $class ) = @_;

	my $self = {};
	bless $self, $class;

	return $self;
}

sub onValueChange {
	my ( $self, $value, $instconfig ) = @_;
	my $rc = 1;
	my $isSidMountpoint = $instconfig->isSidMountpointScenario($value);
	my $originallyDetectedSourceSid = $instconfig->getInstaller()->getSid();
	my $actualSourceSid = $instconfig->readSIDFromProfileFile($value, $originallyDetectedSourceSid);
	return 0 if !defined $actualSourceSid;

	if ( $isSidMountpoint ) {
		$rc = $instconfig->setCorrectSidValuesInSidMountpointScenario ( $value, $originallyDetectedSourceSid, $actualSourceSid );
	}

	if (!$instconfig->isUseSAPHostagent()){
	   $instconfig->ensureRootCredentialsIfNeeded() if (defined $rc);
	}

	return $rc;
}

1;
