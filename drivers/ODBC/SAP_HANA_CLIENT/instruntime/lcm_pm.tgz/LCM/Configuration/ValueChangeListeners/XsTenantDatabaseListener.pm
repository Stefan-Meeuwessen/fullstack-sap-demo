package LCM::Configuration::ValueChangeListeners::XsTenantDatabaseListener;

use strict;

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;

    $configuration->setDatabaseToTenantUserCredentialsParameter($configuration->{params}->{'TenantUser'}, $value);
    $configuration->setDatabaseToTenantUserCredentialsParameter($configuration->{params}->{'SQLTenantUserPassword'}, $value);

    return 1;
}

1;
