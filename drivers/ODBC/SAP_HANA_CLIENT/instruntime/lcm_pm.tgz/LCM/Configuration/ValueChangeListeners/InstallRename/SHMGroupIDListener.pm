package LCM::Configuration::ValueChangeListeners::InstallRename::SHMGroupIDListener;

use strict;
use warnings;

use SDB::Common::Utils qw(getSHMGroupName checkOsGroupID);

sub new {
    my ($class) = @_;
    return bless({}, $class);
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $targetSID = $config->getValue('newSID') // $config->getValue('SID');
    my $sidshmGroupName = getSHMGroupName($targetSID);

    return 0 if !checkOsGroupID($config, 'SHMGroupID', $sidshmGroupName, $value, 0);
    return $config->checkReservedOSGroupIDs($value, 'SHMGroupID');
}

1;