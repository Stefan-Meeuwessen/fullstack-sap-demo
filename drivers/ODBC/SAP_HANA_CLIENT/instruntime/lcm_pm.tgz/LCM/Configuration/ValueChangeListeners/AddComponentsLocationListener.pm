package LCM::Configuration::ValueChangeListeners::AddComponentsLocationListener;

use strict;
use warnings;

sub new {
    my ($class) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange() {
    my ($self, $value, $config) = @_;
    $config->setInteractive('ComponentFsRoot', $value);
    return 1;
}

1;