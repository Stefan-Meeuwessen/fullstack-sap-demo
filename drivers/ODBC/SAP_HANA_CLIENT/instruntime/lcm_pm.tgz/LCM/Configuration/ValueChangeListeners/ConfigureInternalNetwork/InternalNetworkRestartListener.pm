package LCM::Configuration::ValueChangeListeners::ConfigureInternalNetwork::InternalNetworkRestartListener;
use parent qw(LCM::Configuration::ValueChangeListeners::BaseRestartListener);
use strict;
use warnings;

sub onValueChange {
    my ($self, $value, $config) = @_;

    $config->clearParameterWarnings('InternalNetwork');
	if ($config->isNetworkReconfigRestartRequired($value)) {
		$config->addParameterWarning('InternalNetwork', $self->getRestartRequiredMessage());
	}
	return 1;
}

1;
