package LCM::Configuration::ValueChangeListeners::Update::XS::OrgManagerUserDetectionListener;

use strict;
use parent 'LCM::Configuration::ValueChangeListeners::Update::XS::BaseUpdateXSDetectionListener'; 

sub new {
    return bless({}, shift());
}

sub getConfigParameter{
    return 'OrgManagerUser';
}

sub getAdminLoginParameter{
    return 'org-manager-user';
}

1;
