package LCM::Configuration::ValueChangeListeners::ExternalActionConfigComponentsLocationListener;

use strict;
use warnings;
use parent qw(LCM::Configuration::ValueChangeListeners::ComponentListener);

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $componentManager = $config->getComponentManager();
    $componentManager->setPrintAllDetectedComponents(1);

    if ( !$self->SUPER::onValueChange($value, $config)) {
        return 0;
    }
    $config->createFlavouredConfigurationFactory();
    $config->setValidActions();

    return 1;
}

1;