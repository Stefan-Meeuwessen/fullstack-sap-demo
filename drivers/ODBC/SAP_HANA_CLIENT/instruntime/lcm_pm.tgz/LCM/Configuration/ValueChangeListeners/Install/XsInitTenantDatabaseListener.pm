package LCM::Configuration::ValueChangeListeners::Install::XsInitTenantDatabaseListener;

use strict;
use parent qw(LCM::Configuration::ValueChangeListeners::XsInitTenantDatabaseListener);

sub new {
    return bless({}, shift());
}

sub setValidValues{
    my ($self, $cfg) = @_;
    push( @{$cfg->getValidValues('XSTenantDatabaseName')}, $cfg->getValue('SID')) if($cfg->isSystemInCompatibilityMode()) ;
}

1;