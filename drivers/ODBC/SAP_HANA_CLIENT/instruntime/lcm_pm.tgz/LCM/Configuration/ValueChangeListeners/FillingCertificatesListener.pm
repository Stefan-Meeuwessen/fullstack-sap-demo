package LCM::Configuration::ValueChangeListeners::FillingCertificatesListener;

sub new {
    my ($class, ) = @_;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub onValueChange {
    my ($self, $value, $instconfig) = @_;

    $instconfig->fillCertificatesHostmapDefaultValuesAndLocalData();

    return 1;
}

1;
