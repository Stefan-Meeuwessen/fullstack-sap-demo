package LCM::Configuration::ValueChangeListeners::SystemdSELinuxListener;

use strict;
use warnings;

use SDB::Install::SysInfo;

use parent qw(SDB::Install::Base);

sub new {
    my ($class) = @_;
    return bless({}, $class);
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $sysinfo = SDB::Install::SysInfo->new();
    return 1 if !$value || !$sysinfo->isRedHat() || !$sysinfo->isSELinuxEnforced();

    my $message = "SELinux is set in Enforcing mode. Ensure that it is configured properly. For more information, see SAP note 2009879.";
    $config->getMsgLst()->addWarning($message);
    $config->addParameterWarning('UseSystemd', $message);
    return 1;
}

1;