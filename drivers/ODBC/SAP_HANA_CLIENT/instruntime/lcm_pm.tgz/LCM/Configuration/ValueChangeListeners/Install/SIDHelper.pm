package LCM::Configuration::ValueChangeListeners::Install::SIDHelper;

use strict;
use LCM::Configuration::NewDBUser::NewDBUser;
use base qw(LCM::Configuration::ValueChangeListeners::SIDHelperBase);

sub InitConfigUsername {
	my ($config, $sid) = @_;

	my $user = new LCM::Configuration::NewDBUser::NewDBUser($sid);

	return LCM::Configuration::ValueChangeListeners::SIDHelperBase::ConfigUsername($config, $user);
}

1;
