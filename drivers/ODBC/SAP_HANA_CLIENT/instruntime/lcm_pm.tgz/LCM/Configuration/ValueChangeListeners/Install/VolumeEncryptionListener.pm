package LCM::Configuration::ValueChangeListeners::Install::VolumeEncryptionListener;

use strict;
use warnings;
use SDB::Install::Globals qw($gEncryptionNoteSuffix);

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    if($value){
        my $backupRootKeysNote = "Volume $gEncryptionNoteSuffix";
        $config->getMsgLst()->addMessage($backupRootKeysNote);
        $config->addParameterWarning('VolumeEncryption', $backupRootKeysNote);
    }
    return 1;
}

1;