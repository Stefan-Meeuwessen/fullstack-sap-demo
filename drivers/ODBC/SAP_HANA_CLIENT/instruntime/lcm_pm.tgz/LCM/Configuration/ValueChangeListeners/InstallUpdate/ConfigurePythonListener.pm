package LCM::Configuration::ValueChangeListeners::InstallUpdate::ConfigurePythonListener;

use strict;
use warnings;

sub new {
    my ($class) = @_;
    bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    $config->unskipConfirmPython2ToPython3SwitchIfNeeded($value);
    return 1;
}

1;