package LCM::Configuration::ValueChangeListeners::Rename::ReservedIDsHandler;
use parent qw(LCM::Configuration::ValueChangeListeners::ReservedIDsHandler);
use strict;
use warnings;

sub _isLSSPartOfSystem {
    my ($self, $config) = @_;
    my $instance = $config->getOwnInstance();
    return (defined $instance->getLssInstance());
}

1;
