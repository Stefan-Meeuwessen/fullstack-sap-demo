package LCM::Configuration::ValueChangeListeners::Rename::CertificatesHostmapListener;

use strict;

my $ERROR_MESSAGE = 'Failed to detect external host names default values';

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $value, $instconfig) = @_;
    return $self->handleFillingOfCertficatesHostmapDefaultValues($instconfig);
}

sub onMapValueChange {
    my ($self, $key, $value, $instconfig) = @_;
    return $self->handleFillingOfCertficatesHostmapDefaultValues($instconfig);
}

sub handleFillingOfCertficatesHostmapDefaultValues {
    my ($self, $instconfig) = @_;
    if (!$instconfig->fillCertificatesHostmapDefaultValuesAndLocalData()) {
        $instconfig->getErrMsgLst()->addMessage($ERROR_MESSAGE);
        return undef;
    }
    return 1;
}

1;
