package LCM::Configuration::ValueChangeListeners::InstallUpdate::SQLSystemUserPasswordListener;

sub new {
	my ($class) = @_;

	my $self = {};
	bless $self, $class;

	return $self;
}

sub onValueChange {
	my ($self, $value, $instconfig) = @_;
	if(!$instconfig->isUpdate() || ($instconfig->isUpdate() && $instconfig->isConvertToMultiDbRequired())){
	    $instconfig->{params}->{SQLTenantUserPassword}->{value} = $value;
	}
	return 1;
}

1;
