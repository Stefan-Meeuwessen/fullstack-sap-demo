package LCM::Configuration::ValueChangeListeners::Uninstall::Web::SelectedComponentsListener;

use strict;
use parent qw(LCM::Configuration::ValueChangeListeners::Uninstall::SelectedComponentsListener);

# Override
# Always show Force in the Advanced Configuration dialog of the web user interface
sub _shallSkipForce {
    return 0;
}

1;
