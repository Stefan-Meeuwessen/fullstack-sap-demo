package LCM::Configuration::ValueChangeListeners::SHAVersionListener;

use strict;
use warnings;

use SAPDB::Install::Hostname qw(hostname);
use SDB::Install::Version;
use SDB::Install::Saphostagent qw(getSHAVersion);
use SDB::Install::System qw(isSidadmin);
use SDB::Install::Globals qw($gProductNameSHA);
use List::Util qw(first);

my $REQUIRED_SHA_VERSION = '7.22.61';

sub new {
    my ($class, $paramToSetNoRetryFor) = @_;
    my $self = {
        _paramToSetNoRetryFor => $paramToSetNoRetryFor,
        _requiredSHAVersion => SDB::Install::Version->new(split('\.', $REQUIRED_SHA_VERSION))
    };
    bless $self, $class;
}

# during install: if SHA will remain older than 7.22.61, warn that some SHA executions might not work later (namely update, add hosts)
# during update, add hosts as SSH: warn if SHA will remain older than 7.22.61
# during update, add hosts as SHA: throw an error if SHA is older than 7.22.61, the operations exceed 1024 symbols and we update/install SHA only after calling them
# during register_rename, remote_execution SHA: throw an error if SHA is older than 7.22.61
# during register_rename, remote_execution SSH: if older than 7.22.61, warn that some SHA executions might not work later (namely update, add hosts)

sub onValueChange {
    my ($self, $value, $config) = @_;
    $self->_setConfig($config);
    $self->_warnIfNotUpdatingOutdatedSHA();
    return $self->_isActionExecutionPossibleViaSHA();
}

sub _warnIfNotUpdatingOutdatedSHA {
    my ($self) = @_;
    my $config = $self->_getConfig();
    my $warningHolderParam = 'InstallHostagent';
    my $isRemoteExecutionSHA = $config->isUseSAPHostagent();

    return 1 if $isRemoteExecutionSHA || $config->willInstallOrUpdateSHA();

    my $affectedHosts = $self->_getHostsWithUnmetSHAVersionRequirement(1);
    return 1 if !@{$affectedHosts};

    my $shaWarningParamHolderWarnings = $config->getParameterWarnings($warningHolderParam);
    my $shaVersionWarningMessagePrefixEscaped = quotemeta($self->_getSHAVersionWarningMessagePrefix());
    my $shaVersionWarningMessage = $self->_getWarningMessage($affectedHosts);
    my $indexOfOutdatedSHAWarning = first { $shaWarningParamHolderWarnings->[$_] =~ /^$shaVersionWarningMessagePrefixEscaped/ } 0..$#$shaWarningParamHolderWarnings;

    if(defined $indexOfOutdatedSHAWarning) {
        $shaWarningParamHolderWarnings->[$indexOfOutdatedSHAWarning] = $shaVersionWarningMessage;
        return 1;
    }

    $config->addParameterWarning($warningHolderParam, $shaVersionWarningMessage);
    return 1;
}

sub _getWarningMessage {
    my ($self, $affectedHosts) = @_;
    my $affectedHostsString = join(', ', @{$affectedHosts});
    return $self->_getSHAVersionWarningMessagePrefix() . "$affectedHostsString. Executions via $gProductNameSHA might not work later on.";
}

sub _isActionExecutionPossibleViaSHA {
    my ($self) = @_;
    my $config = $self->_getConfig();
    my $isRemoteExecutionSHA = $config->isUseSAPHostagent();

    return 1 if !$isRemoteExecutionSHA;

    my $sid = $config->getSID();
    my $isSidAdmUserExecution = isSidadmin($sid) ? 1 : 0;
    my $affectedHosts = $self->_getHostsWithUnmetSHAVersionRequirement($isSidAdmUserExecution);

    return 1 if !@{$affectedHosts};

    my $action = $config->getProductName();
    my $affectedHostsString = join(', ', @{$affectedHosts});
    my $appContext = LCM::App::ApplicationContext::getInstance();
    my $isWebUI = $appContext->isSLP();
    my $scopeSupported = exists $config->{params}->{Scope};

    my $errorMsg = "$action cannot be executed with the current $gProductNameSHA version";
    $errorMsg .= " via the Web UI" if $isWebUI;
    $errorMsg .= ($isWebUI ? ', ' : ' ') . 'as ' . lc($sid) . 'adm user' if $isSidAdmUserExecution;
    $errorMsg .= ($isWebUI || $isSidAdmUserExecution ? ', or ' : ' ') . "with remote execution via $gProductNameSHA";
    $errorMsg .= '. Do one of the following:';
    $errorMsg .= "\n - Start hdblcm or hdblcmgui as root user. ";
    $errorMsg .= $scopeSupported ? 'Use either remote execution via SSH or execute the operation decentralized using scope \'instance\'.' : 'Use remote execution via SSH.';
    $errorMsg .= "\n - Upgrade $gProductNameSHA manually on host(s) $affectedHostsString to version $REQUIRED_SHA_VERSION or newer and repeat the operation with hdblcm.";

    $config->setErrorMessage($errorMsg);

    my $paramToSetNoRetryFor = $self->_getParamToSetNoRetryFor();
    $config->setNoRetry($paramToSetNoRetryFor, 1) if defined $paramToSetNoRetryFor;
    return 0;
}

sub _getHostsWithUnmetSHAVersionRequirement {
    my ($self, $shouldCheckLocalSHA) = @_;
    my $affectedHosts = $self->_getRemoteHostsWithUnmetSHAVersionRequirement();
    push(@{$affectedHosts}, hostname()) if $shouldCheckLocalSHA && $self->_isLocalHostWithUnmetSHAVersionRequirement();
    return $affectedHosts;
}

sub _getRemoteHostsWithUnmetSHAVersionRequirement {
    my ($self) = @_;
    my $config = $self->_getConfig();
    my $remoteHostnames = $self->_getRemoteHostnames();
    my $requiredSHAVersion = $self->_getRequiredSHAVersion();
    my @affectedRemoteHosts = ();

    foreach my $hostname (@{$remoteHostnames}) {
        last if !exists $config->{remoteSaphostagents};

        my $remoteSHAVersionString = $config->{remoteSaphostagents}->{$hostname}->{version};
        next if !defined $remoteSHAVersionString;

        my $remoteSHAVersion = SDB::Install::Version->new(split('\.', $remoteSHAVersionString));
        push(@affectedRemoteHosts, $hostname) if $remoteSHAVersion->isOlderThan($requiredSHAVersion);
    }

    return \@affectedRemoteHosts;
}

sub _getRemoteHostnames {
    my ($self) = @_;
    my $config = $self->_getConfig();
    my $remoteHostsObjects = $config->getRemoteHostsObjects() // [];
    my @remoteHostnames = ();

    foreach my $remoteHosts (@{$remoteHostsObjects}){
        push(@remoteHostnames, @{$remoteHosts->getHostNames()});
    }

    return \@remoteHostnames;
}

sub _isLocalHostWithUnmetSHAVersionRequirement {
    my ($self) = @_;
    my $config = $self->_getConfig();
    my $requiredSHAVersion = $self->_getRequiredSHAVersion();

    $config->{localSHAVersionString} //= getSHAVersion($config, 1);
    return 0 if !defined $config->{localSHAVersionString};

    my $localSHAVersion = SDB::Install::Version->new(split('\.', $config->{localSHAVersionString}));
    return $localSHAVersion->isOlderThan($requiredSHAVersion);
}

sub _getConfig {
    my ($self) = @_;
    return $self->{_config};
}

sub _setConfig {
    my ($self, $config) = @_;
    $self->{_config} = $config;
}

sub _getSHAVersionWarningMessagePrefix {
    my ($self) = @_;
    return "$gProductNameSHA will not be upgraded past the required version of $REQUIRED_SHA_VERSION on host(s) ";
}

sub _getParamToSetNoRetryFor {
    my ($self) = @_;
    return $self->{_paramToSetNoRetryFor};
}

sub _getRequiredSHAVersion {
    my ($self) = @_;
    return $self->{_requiredSHAVersion};
}

1;