package LCM::Configuration::ValueChangeListeners::XsUpdateOrgManagerPasswordString;

use strict;
use warnings;

sub new {
    my($class,$passwordParamId) = @_;
    my $self =  bless({}, $class);
    $self->{passwordParamId} = $passwordParamId;
    return $self;
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;
    $configuration->setUsernameToSQLUserPassword($self->{passwordParamId},$value);
    return 1;
}

1;
