package LCM::Configuration::ValueChangeListeners::Install::BackupEncryptionListener;

use strict;
use warnings;
use SDB::Install::Globals qw($gEncryptionNoteSuffix);

sub new {
    my ($class) = @_;
    bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;

    if($value){
        my $backupRootKeysNote = "Backup $gEncryptionNoteSuffix";
        $config->getMsgLst()->addMessage($backupRootKeysNote);
        $config->addParameterWarning('BackupEncryption', $backupRootKeysNote);
    }
    return 1;
}

1;