package LCM::Configuration::ValueChangeListeners::Cockpit::CockpitSpaceListener;

use strict;
use SDB::Install::Globals qw($gShortProductNameXS2);


my $FAILED_XS_LOGIN_WARNING = "Failed to login into $gShortProductNameXS2. Database might be offline. ".
                              "If the specified space '%s' already exists, it will be used and won't be modified. ".
                              "Make sure it is configured properly.";

my $SPACE_EXISTS_WARNING    = "The $gShortProductNameXS2 space '%s' already exists and it will not be modified. ".
                              "Make sure it is configured properly.";

my $HAS_XSA_FAILED_LOGIN    = "Could not check if Cockpit space '%s' exists. ".
                              "Either the database is offline or there is a problem logging into $gShortProductNameXS2. ".
                              "The parameters for Cockpit tenant will be required.";

sub new {
    return bless({}, shift());
}

sub onValueChange {
    my ($self, $cockpitSpace, $configuration) = @_;
    my $hasXSA      = $configuration->hasXSA();
    my $xsClient    = $hasXSA ? $configuration->getXSClient() : undef;
    my $oldContext = $xsClient->setMsgLstContext($configuration->getMsgLstContext()) if defined $xsClient;
    my $xsLogged    = $xsClient ? $xsClient->login() : 0;
    my $spaceExists = $xsLogged ? $xsClient->spaceExists($cockpitSpace) : 0;
    my $isUpdate    = $configuration->isCockpitStackUpdate();
    my $msgLst = $configuration->getMsgLst();

    if ($isUpdate && $xsLogged && !$spaceExists) {
# Update case where the xs login was successful and the space does not exist => we must blow up
        $configuration->setErrorMessage("Provided space '$cockpitSpace does not exist");
        $xsClient->setMsgLstContext($oldContext);
        return 0;
    }

    if ($hasXSA && !$xsLogged) {
        $msgLst->addWarning(sprintf($HAS_XSA_FAILED_LOGIN, $cockpitSpace));
        $configuration->addParameterWarning('CockpitXSSpace', sprintf($FAILED_XS_LOGIN_WARNING, $cockpitSpace));
    }

    if ($spaceExists) {
        my $spaceGUID = $xsClient->retrieveSpaceGUID($cockpitSpace);
        $configuration->setValue('CockpitSpaceGUID', $spaceGUID);

        $configuration->addParameterWarning('CockpitXSSpace', sprintf($SPACE_EXISTS_WARNING, $cockpitSpace)) if !$isUpdate;
    }
    $msgLst->addMessage('Cockpit space does not exist. The parameters for Cockpit tenant will be required.') if !$spaceExists;
    $configuration->setSkip('CockpitTenant', $spaceExists);

    $xsClient->logout() if $xsLogged;
    $xsClient->setMsgLstContext($oldContext) if defined $xsClient;
    return 1;
}

1;
