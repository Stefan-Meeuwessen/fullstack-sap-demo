package LCM::Configuration::ValueChangeListeners::AnyLSSTrustUnsignedComponentsListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gProductNameLSS $gProductName);
use SDB::Install::Configuration qw($bool_true_pattern);

sub new {
    my ($class) = @_;
    return bless({}, $class);
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    return 1 if $config->isSkipped('LSSTrustUnsignedComponents');

    my $ignoreSignatureCheck = $config->getSystemUsage() =~ /development|custom/ ? 1 : 0;
    return 1 if $ignoreSignatureCheck;

    my $trustUnsignedValue = $self->{shouldUseBatchValue} ? $self->_getTrustUnsignedBatchValue($config) : $value;
    my $isFeatureSupported = $config->getFeatureManager()->isLssTrustUnsignedComponentsSupported();
    my $option = $config->getOpt('LSSTrustUnsignedComponents');
    if ($trustUnsignedValue && !$isFeatureSupported) {
        $config->setErrorMessage("The option '${option}' is not supported for the current version of ${gProductNameLSS}. Use newer version of ${gProductNameLSS}.");
        $self->_setNoRetryIfNeeded($config);
        return 0;
    }

    $self->_setUnsignedComponents($config);
    my $errorMsg = $self->_getUnsignedComponentsErrorMessage();
    return 1 if $errorMsg eq '';

    if ($isFeatureSupported) {
        my $unsignedComponents = $self->_getUnsignedComponents();
        my $instructionPostfix = $self->getErrorInstructionPostfix($config);
        $errorMsg .= "\nTo trust the '${unsignedComponents}' component(s) without signature ${instructionPostfix}.";
    }

    $config->setErrorMessage($errorMsg);
    if ($trustUnsignedValue) {
        $config->getMsgLst()->addMessage("Ignoring error due to command line switch '${option}'");
        return 1;
    }

    $self->_setNoRetryIfNeeded($config);
    return 0;
}

sub _setUnsignedComponents {
    my ($self, $config) = @_;
    $self->{unsignedInstalledComponents} = join(', ', @{$self->_getInstalledUnsignedHDBComponentsBatchKeyName($config)}) if ($self->{shouldCheckInstalledComponents} || $self->{shouldCheckBothInstalledAndSelected});
    $self->{unsignedSelectedComponents} = join(', ', @{$self->_getSelectedUnsignedHDBComponentsBatchKeyName($config)}) if !$self->{shouldCheckInstalledComponents};
}

sub _getUnsignedComponents {
    my ($self) = @_;
    my $selectedComponents = $self->{unsignedSelectedComponents} // '';
    my $installedComponents = $self->{unsignedInstalledComponents} // '';

    my @selectedArray = $selectedComponents ? split(/,\s*/, $selectedComponents) : ();
    my @installedArray = $installedComponents ? split(/,\s*/, $installedComponents) : ();

    my @combinedComponents = (@selectedArray, @installedArray);

    my %seenComponents;
    my @uniqueComponents = grep { ! $seenComponents{$_}++ } @combinedComponents;
    my @sortedUniqueComponents = sort @uniqueComponents;

    return join(', ', @sortedUniqueComponents);
}

sub _getUnsignedComponentsErrorMessage {
    my ($self) = @_;
    my $shouldIncludeUnsignedSelectedComponentsMessage = defined $self->{unsignedSelectedComponents} && $self->{unsignedSelectedComponents} ne '';
    my $shouldIncludeUnsignedInstalledComponentsMessage = defined $self->{unsignedInstalledComponents} && $self->{unsignedInstalledComponents} ne '';
    return '' if !$shouldIncludeUnsignedSelectedComponentsMessage && !$shouldIncludeUnsignedInstalledComponentsMessage;

    my $errorMsg = "${gProductNameLSS} requires that the";
    $errorMsg .= " selected component(s) '$self->{unsignedSelectedComponents}'" if $shouldIncludeUnsignedSelectedComponentsMessage;
    $errorMsg .= " and" if $shouldIncludeUnsignedSelectedComponentsMessage && $shouldIncludeUnsignedInstalledComponentsMessage;
    $errorMsg .= " installed component(s) '$self->{unsignedInstalledComponents}'" if $shouldIncludeUnsignedInstalledComponentsMessage;
    $errorMsg .= " have a valid signature.";
    $errorMsg .= " See SAP note 2078425,";
    $errorMsg .= " section 'How to prepare ${gProductName} packages for installation or update' for instructions how to prepare packages for update or implications of ignoring this error" if $shouldIncludeUnsignedSelectedComponentsMessage;
    $errorMsg .= "." if !$shouldIncludeUnsignedInstalledComponentsMessage;
    $errorMsg .= " and" if $shouldIncludeUnsignedSelectedComponentsMessage && $shouldIncludeUnsignedInstalledComponentsMessage;
    $errorMsg .= " section 'Repairing installations with missing signature' for instructions how to repair an installed system with missing signature." if $shouldIncludeUnsignedInstalledComponentsMessage;
    return $errorMsg;
}

sub _getSelectedUnsignedHDBComponentsBatchKeyName {
    my ($self, $config) = @_;
    my $componentManager = $config->getComponentManager();
    return $componentManager->getSelectedUnsignedHDBComponentsBatchKeyName();
}

sub _getInstalledUnsignedHDBComponentsBatchKeyName {
    my ($self, $config) = @_;
    my $componentManager = $config->getComponentManager();
    return $self->_filterByUntrustedProducts($componentManager->getInstalledUnsignedHDBComponents($config), $config);
}

sub _filterByUntrustedProducts {
    my ($self, $installedComponentsWithNoSignature, $config) = @_;
    my $instance = $config->getOwnInstance();
    my $lssInstance = (defined $instance) ? $instance->getLssInstance() : undef;
    return $self->_getComponentsBySortedBatchKeyNames($installedComponentsWithNoSignature) if !defined $lssInstance;

    my $untrustedProducts = $lssInstance->getParser()->getUntrustedLssProducts($config);
    return $self->_getComponentsBySortedBatchKeyNames($installedComponentsWithNoSignature) if !defined $untrustedProducts;

    my @filteredComponents = ();
    foreach my $component (@{$installedComponentsWithNoSignature}) {
        my $componentKeyName = $component->getComponentKeyName();
        my $componentVersion = $component->getVersion();

        next if !defined $untrustedProducts->{$componentKeyName};
        next if !(grep { $_ eq $componentVersion } @{$untrustedProducts->{$componentKeyName}});

        push @filteredComponents, $component;
    }

    return $self->_getComponentsBySortedBatchKeyNames(\@filteredComponents);
}

sub _getComponentsBySortedBatchKeyNames {
    my ($self, $components) = @_;
    my @batchKeyNames = map { $_->getComponentBatchKey() } @{$components};
    my @sortedBatchKeyNames = sort @batchKeyNames;
    return \@sortedBatchKeyNames;
}

sub _setNoRetryIfNeeded {
    my ($self, $config) = @_;
    my $paramForNoRetry = $self->{paramToSetNoRetryFor};
    $config->setNoRetry($paramForNoRetry, 1) if defined $paramForNoRetry;
    return 1;
}

sub _getTrustUnsignedBatchValue {
    my ($self, $config) = @_;
    my $trustUnsignedComponentsBatchValue = $config->getValueOrBatchValue('LSSTrustUnsignedComponents');
    return $trustUnsignedComponentsBatchValue =~ /$bool_true_pattern/ ? 1 : 0 if defined $trustUnsignedComponentsBatchValue;

    my $trustUnsignedServerBatchValue = $config->getValueOrBatchValue('LSSTrustUnsignedServer');
    return $trustUnsignedServerBatchValue =~ /$bool_true_pattern/ ? 1 : 0 if defined $trustUnsignedServerBatchValue;

    return 0;
}

sub getErrorInstructionPostfix {
    ...
}

1;