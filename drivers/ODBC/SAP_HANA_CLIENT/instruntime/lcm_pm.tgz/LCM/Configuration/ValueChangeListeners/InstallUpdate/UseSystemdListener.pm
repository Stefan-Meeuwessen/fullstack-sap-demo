package LCM::Configuration::ValueChangeListeners::InstallUpdate::UseSystemdListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gProductNameSystem $gKeynameEngine $gParameterAvailableDuringRealServerUpdateWarning $gParameterUnsupportedByEngine);
use SDB::Common::Utils qw(isSystemRegisteredInSystemd);

my $USE_SYSTEMD_PARAM_NAME = 'UseSystemd';

sub new {
    my ($class) = @_;
    bless {}, $class;
}

sub onValueChange {
    my ($self, $value, $config) = @_;

    return 1 if !defined $config->{params}->{$USE_SYSTEMD_PARAM_NAME}; # the UseSystemd parameter is deleted for some update configs, but the listener will be triggered

    my $serverComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameEngine);
    return 1 if !defined $serverComponent; # for example, in the case of update with --components=hdblcm the server component is not defined

    my $isParamSupported = $serverComponent->isParamSupported($USE_SYSTEMD_PARAM_NAME);
    if(!$isParamSupported) {
        $config->setSkip($USE_SYSTEMD_PARAM_NAME, 1, $gParameterUnsupportedByEngine);
        return 1;
    }

    return 1 if !$config->isUpdate(); # serverComponent's isRealUpdate returns 1 during installation

    my $isRealServerUpdate = $serverComponent->isRealUpdate($config);
    if(!$isRealServerUpdate) {
        $config->setSkip($USE_SYSTEMD_PARAM_NAME, 1, $gParameterAvailableDuringRealServerUpdateWarning);
        return 1;
    }

    $config->setSkip($USE_SYSTEMD_PARAM_NAME, 0) if $config->isSkipped($USE_SYSTEMD_PARAM_NAME);
    $self->displaySystemdWarningDuringUpdateIfNeeded($config);
    return 1;
}

sub displaySystemdWarningDuringUpdateIfNeeded {
    my ($self, $config) = @_;

    my $shouldUseSystemd = $config->getValue($USE_SYSTEMD_PARAM_NAME);
    my $useSystemdParamWarnings = $config->getParameterWarnings($USE_SYSTEMD_PARAM_NAME);
    my $sapSys = $config->getSAPSystem();
    my $isSystemRegisteredInSystemd = isSystemRegisteredInSystemd($sapSys);
    my $shouldAddSystemdWarning = $shouldUseSystemd && !$isSystemRegisteredInSystemd;

    if(@{$useSystemdParamWarnings}) {
        $config->clearParameterWarnings($USE_SYSTEMD_PARAM_NAME);
    }

    if($shouldAddSystemdWarning) {
        my $systemdUpdateWarning = "During update the $gProductNameSystem will be registered with systemd. Any software depending on that should be properly adapted.";
        $config->addWarning($systemdUpdateWarning);
        $config->addParameterWarning($USE_SYSTEMD_PARAM_NAME, $systemdUpdateWarning);
    }
    return 1;
}

1;