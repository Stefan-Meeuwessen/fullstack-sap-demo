package LCM::Configuration::ValueChangeListeners::Update::SystemUserListener;

sub new {
	my ($class) = @_;

	my $self = {};
	bless $self, $class;

	return $self;
}

sub onValueChange {
	my ($self, $value, $instconfig) = @_;

	$instconfig->setUsernameToSQLSysPasswd($value);
    if($instconfig->isConvertToMultiDbRequired()){
       $instconfig->setValue('TenantUser',$value);
    }
	return 1;
}

1;
