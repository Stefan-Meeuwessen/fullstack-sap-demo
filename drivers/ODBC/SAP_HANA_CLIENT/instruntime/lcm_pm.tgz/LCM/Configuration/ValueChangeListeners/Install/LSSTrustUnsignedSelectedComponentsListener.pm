package LCM::Configuration::ValueChangeListeners::Install::LSSTrustUnsignedSelectedComponentsListener;

use strict;
use warnings;

use parent qw(LCM::Configuration::ValueChangeListeners::InstallUpdate::LSSTrustUnsignedComponentsListenerBase);

sub new {
    my ($class) = @_;
    my $self = $class->SUPER::new();
    $self->{shouldCheckInstalledComponents} = 0;
    $self->{shouldUseBatchValue} = 0;
    return $self;
}

1;