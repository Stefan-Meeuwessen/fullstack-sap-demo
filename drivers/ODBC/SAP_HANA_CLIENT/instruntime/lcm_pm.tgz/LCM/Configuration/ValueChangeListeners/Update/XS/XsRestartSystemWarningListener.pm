package LCM::Configuration::ValueChangeListeners::Update::XS::XsRestartSystemWarningListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gKeynameXS2 $gKeynameEngine);
use LCM::App::ApplicationContext;

use parent qw(LCM::Configuration::ValueChangeListeners::BaseRestartListener);

sub onValueChange {
    my ($self, $value, $config) = @_;
    return 1 if !$self->_isWarningApplicable($value, $config);

    $config->getComponentManager()->getComponentByKeyName($gKeynameXS2)->{requireSystemRestart} = 1;
    $config->addParameterWarning('ISCMode', $self->getRestartRequiredMessage());

    return 1;
}

sub _isWarningApplicable {
    my ($self, $value, $config) = @_;

    my $appContext = LCM::App::ApplicationContext::getInstance();
    return 0 if $appContext->isSLP();

    my $xsaComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameXS2);

    return 0 if !defined $xsaComponent;
    my $isXSASelectedForInstall = $xsaComponent->isComponentSelected() && !$xsaComponent->isInstalled();
    return 0 if !$isXSASelectedForInstall;
    return 0 if !$config->isISCModeChangeNeeded($value);

    my $serverComponent = $config->getComponentManager()->getComponentByKeyName($gKeynameEngine);
    return 0 if defined $serverComponent;

    return 1;
}

1;