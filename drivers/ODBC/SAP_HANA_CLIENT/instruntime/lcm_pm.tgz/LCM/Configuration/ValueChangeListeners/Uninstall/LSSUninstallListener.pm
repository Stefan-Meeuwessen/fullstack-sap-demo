package LCM::Configuration::ValueChangeListeners::Uninstall::LSSUninstallListener;

use strict;
use warnings;

use SDB::Install::Globals qw (
    $gKeynameLSS
    $gShortProductNameLSS
    $gProductNameLSS
    $gSecureStoreTypeSSFS
    $gSSFSEncryptionAlgorithm
);

use parent qw(SDB::Install::Base);

our $SSFS_KEY = uc($gSecureStoreTypeSSFS);
our $SAP_NOTE_MSG = "For more information, see SAP Note 3656193";

our $CANNOT_DETERMINE_SECURE_STORE_ERR = "The current secure store cannot be determined. The uninstallation of $gProductNameLSS will fail if the current encryption algorithm is not '$gSSFSEncryptionAlgorithm'. $SAP_NOTE_MSG.";
our $CANNOT_MIGRATE_SECURE_STORE_ERR = "$gProductNameLSS cannot be uninstalled. The target secure store '$SSFS_KEY' is incompatible with the current encryption algorithm. $SAP_NOTE_MSG.";

our $CHECK_PROGRESS_MSG = "Checking if the secure store can be migrated to '$SSFS_KEY'...";
our $NO_MIGRATION_NEEDED_MSG = "No secure store migration needed.";
our $MIGRATION_POSSIBLE_MSG = "Secure store migration to '$SSFS_KEY' is possible.";

sub new {
    my ($class, $paramId) = @_;
    my $self = $class->SUPER::new();
    $self->{paramId} = $paramId;
    return $self;
}

sub getParamId {
    my ($self) = @_;
    return $self->{paramId};
}

sub onValueChange {
    my ($self, $value, $configuration) = @_;
    return 1 if !$self->_isLssSelected($configuration);
    return 1 if $self->_isServerSelected($configuration);

    my $canMigrateToSsfs = $self->_canMigrateToSsfs($configuration);
    return 1 if $canMigrateToSsfs;

    return $self->_handleError($configuration, $canMigrateToSsfs);
}

sub _isLssSelected {
    my ($self, $configuration) = @_;
    return $configuration->getSystemComponentManager()->isComponentSelected($gKeynameLSS);
}

sub _isServerSelected {
    my ($self, $configuration) = @_;
    return $configuration->getSystemComponentManager()->isHDBServerComponentSelected();
}

sub _canMigrateToSsfs {
    my ($self, $configuration) = @_;
    my $instance = $configuration->getOwnInstance();
    my $outputBuffer;

    $configuration->getMsgLst()->addProgressMessage($CHECK_PROGRESS_MSG);
    my $rc = $instance->testMigrateToSsfs(\$outputBuffer);

    if (!$rc) {
        return 0 if $self->_isTargetRootKeyStoreError($outputBuffer);
        return undef;
    }

    my $currentSecureStore = $self->_parseCurrentSecureStore($outputBuffer);
    if (defined $currentSecureStore && $currentSecureStore eq $SSFS_KEY) {
        $configuration->getMsgLst()->addProgressMessage($NO_MIGRATION_NEEDED_MSG);
        return 1;
    }

    $configuration->getMsgLst()->addProgressMessage($MIGRATION_POSSIBLE_MSG);
    return 1;
}

sub _isTargetRootKeyStoreError {
    my ($self, $outputBuffer) = @_;
    my $pattern = qr/the target root key store is incompatible with the keys in the source root key store/;
    return $outputBuffer =~ $pattern;
}

sub _parseCurrentSecureStore {
    my ($self, $outputBuffer) = @_;
    my $pattern = qr/^current root key store:\s*(\S+)/m;
    my ($currentSecureStore) = ($outputBuffer =~ $pattern);
    return $currentSecureStore;
}

sub _handleError {
    my ($self, $configuration, $canMigrateToSsfs) = @_;
    if (!defined $canMigrateToSsfs) {
        $configuration->addParameterWarning($self->getParamId(), $CANNOT_DETERMINE_SECURE_STORE_ERR);
        return 1; # warn only, migrateSecureStore is the first task after stop, so no damage done yet
    }

    if (!$canMigrateToSsfs) {
        $configuration->setErrorMessage($CANNOT_MIGRATE_SECURE_STORE_ERR);
        $configuration->setNoRetry($self->getParamId(), 1);
    }
    return 0;
}

1;