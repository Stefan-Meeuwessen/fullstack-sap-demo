package LCM::Configuration::ValueChangeListeners::Install::XsTenantInstallationListener;

use strict;
use base 'LCM::Configuration::ValueChangeListeners::InstallUpdate::XsTenantInstallationListenerBase';

sub shouldEnableRelevantParameters {
    my ($self, $instconfig) = @_;
    if (!$instconfig->getValue('CreateInitialTenant')) {
        return 0;
    }

    return $self->SUPER::shouldEnableRelevantParameters($instconfig);
}

sub getRelevantParameterID {
    my ($self, $instconfig) = @_;
    return 'InstallXSInDefaultTenant';
}

1;