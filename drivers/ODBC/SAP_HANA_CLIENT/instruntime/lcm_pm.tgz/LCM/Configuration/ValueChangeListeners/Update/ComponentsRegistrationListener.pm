package LCM::Configuration::ValueChangeListeners::Update::ComponentsRegistrationListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gBoolTruePattern);

use parent qw(LCM::Configuration::ValueChangeListeners::BaseRestartListener);

sub new {
    my ($class) = @_;
    return bless({}, $class);
}

sub onValueChange {
    my ($self, $value, $config) = @_;
    my $skippedComponents = $config->getValue('SkippedComponents') // '';
    my $isServerRegister = !grep { $_ eq 'server' } split ',', $skippedComponents;

    if ($value eq 'register' && $isServerRegister) {
        #no restart/stop action if the instance is already stopped
        my $shouldWarn = $config->isInstanceRunning();
        $config->addParameterWarning('ComponentsRegistration', $self->_getWarning($config)) if $shouldWarn;
        $config->setSkip('Password', 0);
    }
    return 1;
}

sub _getWarning {
    my ($self, $config) = @_;
    my $noStartValue = $config->getValue('NoStart');
    my $isNoStart = defined $noStartValue && $noStartValue =~ /$gBoolTruePattern/i;
    return $isNoStart ? $self->getStopRequiredMessage(undef, 1) : $self->getRestartRequiredMessage(1);
}

1;
