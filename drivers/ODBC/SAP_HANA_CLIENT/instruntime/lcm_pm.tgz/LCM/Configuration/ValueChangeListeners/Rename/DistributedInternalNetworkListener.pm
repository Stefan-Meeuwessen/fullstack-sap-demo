package LCM::Configuration::ValueChangeListeners::Rename::DistributedInternalNetworkListener;

sub new {
	my ( $class ) = @_;

	my $self = {};
	bless $self, $class;

	return $self;
}

sub onValueChange {
	my ( $self, $value, $instconfig ) = @_;	
    $instconfig->fillInternalNetworkAndListenInterfaceValidValues ();
    return 1;
}

1;
