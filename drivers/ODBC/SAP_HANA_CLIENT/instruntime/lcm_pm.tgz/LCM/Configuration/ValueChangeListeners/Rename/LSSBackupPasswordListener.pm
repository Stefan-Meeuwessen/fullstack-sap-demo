package LCM::Configuration::ValueChangeListeners::Rename::LSSBackupPasswordListener;

use strict;
use warnings;

use SDB::Install::Globals qw($gShortProductNameLSS);

use parent qw(SDB::Install::Base);

our $LSS_BACKUP_PASSWORD_CHECK_WARNING = "Cannot verify $gShortProductNameLSS Auto Backup Password in advance. Make sure that it is correct.";

sub onValueChange {
    my ($self, $value, $config) = @_;
    if ($config->getValue('IsRegisterLSS')) {
        $config->addParameterWarning('LSSBackupPassword', $LSS_BACKUP_PASSWORD_CHECK_WARNING);
    }
    return 1;
}

1;