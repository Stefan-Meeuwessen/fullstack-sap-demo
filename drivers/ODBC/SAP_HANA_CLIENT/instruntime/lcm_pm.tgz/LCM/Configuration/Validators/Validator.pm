package LCM::Configuration::Validators::Validator;

use strict;

sub new {
	return bless({},shift);
}

sub isValid {
	...
}

1;