package LCM::Configuration::LSS::LSSConfiguration;

use strict;
use SDB::Install::SysVars qw($isWin);
use SDB::Install::Globals qw(
    $gShortProductNameLSS
    $gKeynameLSS
    $gProductName
    $gOperationCheckLssPath
    $gOperationFileExists
    $gKeynameEngine
    $gSapsysGroupName
    $gSAPLocation
    GetLssCompatibleHostRoles
);
use SDB::Common::Utils qw(getSidcryptName checkOsUserID createUsername createGroupname checkOsGroupID);
use LCM::Utils::CommonUtils qw(getSidadmName getLocalHostSidadmUid);
use SDB::Install::LSS::LssSidcryptUser;
use SAPDB::Install::Hostname;
use File::Basename qw(dirname);
use SDB::Common::BuiltIn;
use SDB::Install::Tools qw(arrayToHash);
use SDB::Install::System qw(normalizeRelativePath isLink);
use Path::Class;
use LCM::FileUtils qw(getDirectoryOwnerUid);

use parent qw(SDB::Install::Configuration::LSSConfiguration LCM::Configuration::GenericStackAny);

sub defineLSSParams {
    my ($self) = @_;
    my $order = scalar keys %{ $self->{params} };
    my $section = 'lss';
    my $lssParams = {
        'LSSInstPath'    => $self->getParamLSSInstPath( $order++, $section ),
        'LSSPassword'    => $self->getParamLSSPassword( $order++, $section),
        'LSSUserID'      => $self->getParamLSSUserID( $order++, $section),
        'LSSGroupID'     => $self->getParamLSSGroupID( $order++, $section ),
        'LSSUserHomeDir' => $self->getParamLSSUserHomeDir( $order++, $section, '/usr/sap/$SID/lss/home' ),
        'LSSUserShell'   => $self->getParamLSSUserShell( $order++, $section ),
        'LSSBackupPassword' => $self->getParamLSSBackupPassword( $order++, $section ),
    };
    map { $self->{params}->{$_} = $lssParams->{$_} } keys %$lssParams;
    return 1;
}

sub enableLSSParams {
    my ($self) = @_;
    my $shouldEnable = $self->isInstallingLSS();

    foreach my $paramId (@{$self->getLSSParams()}) {
        $self->setSkip($paramId, !$shouldEnable);
    }
}

sub initLSSUserID {
    my ($self) = @_;
    my $freeUID = $self->getFreeOsUserID(undef, $self->getReservedUserIDs());

    if (!defined $self->getBatchValue('LSSUserID')) {
        $self->setDefault('LSSUserID', $freeUID);
    }
    return 1;
}

sub initLSSGroupID {
    my ($self) = @_;
    my $freeGID = $self->getFreeGroupID(undef, $self->getReservedGroupIDs());

    if (!defined $self->getBatchValue('LSSGroupID')) {
        $self->setDefault('LSSGroupID', $freeGID);
    }
    return 1;
}

sub checkLSSUserID {
    my ($self, $value) = @_;
    my $userName = getSidcryptName($self->getTargetLssSid());
    return 0 if(!checkOsUserID($self, 'LSSUserID' ,$userName, $value, 0, 0, $self->getRemoteLssCompatibleHosts()));
    return $self->checkReservedOSUserIDs($value, 'LSSUserID');
}

sub checkLSSGroupID {
    my ($self, $value) = @_;
    return 0 if(!$self->checkLSSGroupName($value));

    my $groupName = $self->getSidcryptGroupName();
    if($groupName eq $gSapsysGroupName){
        my $userName = getSidcryptName($self->getTargetLssSid());
        $self->appendErrorMessage("Primary group of user '$userName' cannot be '$gSapsysGroupName' (GID: $value)");
        $self->setSidcryptGroupName(undef); #undo set from the check method above
        return 0;
    }
    return 0 if !$self->checkIsLssUserInSapsysGroup();
    return 0 if (!checkOsGroupID($self, 'LSSGroupID', $groupName, $value, 0, $self->getRemoteLssCompatibleHosts()));
    return $self->checkReservedOSGroupIDs($value, 'LSSGroupID');
}

sub getExistingLssUserId {
    my ($self) = @_;
    my $userName = getSidcryptName($self->getTargetLssSid());
    return $self->getExistingUserId($userName);
}

sub checkLSSGroupName {
    my ($self, $groupId) = @_;
    my $userId = $self->getExistingLssUserId();
    if(defined $userId){
        return $self->checkExistingSidcryptUserGroupName($userId);
    }

    if($self->isDistributedSystem()){
        return $self->checkLSSGroupIDOnRemoteHosts($groupId);
    }

    my $localGroupName = SDB::Common::BuiltIn->get_instance()->getgrgid($groupId);
    if(defined($localGroupName)){
        $self->setSidcryptGroupName($localGroupName);
    }

    return 1;
}

sub checkLSSGroupIDOnRemoteHosts {
    my ($self, $groupId) = @_;
    return 1 if(!defined $self->{remoteGids});

    my @lssCompatibleHosts = @{$self->getAllLssCompatibleHosts()};
    my $remoteGroups = $self->{remoteGids}->{$groupId} // [];
    my @existingGroups = ();
    foreach my $host (@lssCompatibleHosts) {
        push @existingGroups, map($_->[1], grep{ $_->[0] eq $host} @{$remoteGroups});
    }
    my $localGroupName = SDB::Common::BuiltIn->get_instance()->getgrgid($groupId);
    my @existingGroupsInfo = @{$remoteGroups};

    my $localHost = $self->getLocalHanaHost();
    my $isLocalHostLssCompatible = (grep{ $_ eq $localHost} @lssCompatibleHosts);
    if($isLocalHostLssCompatible && defined($localGroupName)){
        push @existingGroups, $localGroupName;
        push @existingGroupsInfo, [$localHost, $localGroupName];
    }

    my $numberOfExistingGroups = scalar(@existingGroups);
    return 1 if($numberOfExistingGroups == 0);

    my $lssRolesString = join(', ', GetLssCompatibleHostRoles());
    my $namesOfExistingGroups = arrayToHash(\@existingGroups);
    if(scalar(keys %{$namesOfExistingGroups}) > 1){
        $self->appendErrorMessage("Name of the group with ID '$groupId' is not the same on all hosts with roles: $lssRolesString.");
        return 0;
    }

    if(scalar(@lssCompatibleHosts) == $numberOfExistingGroups){
        $self->setSidcryptGroupName($existingGroups[0]);
        return 1;
    }

    my $defaultName = getSidcryptName($self->getTargetLssSid());
    if($existingGroups[0] ne $defaultName){
        my @hostsWithMissingGroup = ();
        foreach my $host (@lssCompatibleHosts) {
            push @hostsWithMissingGroup, $host if(grep { $_->[0] ne $host } @existingGroupsInfo);
        }
        $self->appendErrorMessage("If you want to use group different from '$defaultName', ensure that it exists on all hosts with roles: $lssRolesString.");
        $self->appendErrorMessage("Group '$existingGroups[0]' with group ID $groupId does not exist on host(s) @hostsWithMissingGroup");
        return 0;
    }
    $self->setSidcryptGroupName($defaultName);
    return 1;

}

sub checkExistingSidcryptUserGroupName {
    my ($self, $userId) = @_;
    my $userName = getSidcryptName($self->getTargetLssSid());
    my $localSidcryptUser = SDB::Install::LSS::LssSidcryptUser->new($userName);

    my ($existingGroupId, $existingGroupName);
    if($localSidcryptUser->exists()){
        $existingGroupId = $localSidcryptUser->gid();
        $existingGroupName = $localSidcryptUser->group();
    } else {
        $existingGroupId = $self->{remoteUids}->{$userId}->[0]->[2];
        $existingGroupName = $self->{remoteGids}->{$existingGroupId}->[0]->[1];
    }

    my $batchValue = $self->getBatchValue('LSSGroupID');
    if(defined $batchValue && $existingGroupId != $batchValue){
        $self->appendErrorMessage("Group ID $batchValue cannot be used. User '$userName' already belongs to group '$existingGroupName' with group ID $existingGroupId");
        return 0;
    }
    $self->setSidcryptGroupName($existingGroupName);
    return 1;
}

sub getRemoteLssCompatibleHosts {
    my ($self) = @_;
    my $lssCompatibleHosts = $self->getAllLssCompatibleHosts();
    my @remoteHosts = grep {$self->getLocalHanaHost() !~ /$_/} @{$lssCompatibleHosts};
    return \@remoteHosts;
}

sub getAllLssCompatibleHosts {
    my ($self) = @_;
    my @lssCompatibleHosts = ();
    foreach my $role (GetLssCompatibleHostRoles()){
        push @lssCompatibleHosts, @{$self->getSystemHostsWithRole($role)};
        push @lssCompatibleHosts, @{$self->getAddHostsWithRole($role)};
    }
    my $server = $self->getComponentManager()->getComponentByKeyName($gKeynameEngine);
    if(defined $server && $server->isComponentSelected() && !$server->isUpdate()){
        push @lssCompatibleHosts, $self->getLocalHanaHost();
    }
    return \@lssCompatibleHosts;
}

sub checkLSSUserShell {
    my ($self, $shell) = @_;
    return $self->checkShell($shell);
}

sub isLSSInstalled {
    my ($self) = @_;
    my $targetLssSid = $self->getTargetLssSid();
    return 0 if !defined $targetLssSid;
    my $lssInstance = SDB::Install::LSS::LssInstance->new(undef, $targetLssSid);
    return $lssInstance->isConfiguredOnHost();
}

sub handleLssUser {
    my ($self) = @_;
    my $targetSid = $self->getTargetLssSid();
    $self->setDefault('LSSUserHomeDir', "/usr/sap/$targetSid/lss/home");
    my $existingId = $self->getExistingLssUserId();
    my $rc;
    if(defined($existingId)){
        $rc = $self->handleExistingOsID($existingId, 'LSSUserID');
        $rc &&= $self->setExistingLSSGroupID($existingId);
    } else {
        $rc = $self->initLSSUserID();
    }
    return $rc;
}

sub checkIsLssUserInSapsysGroup {
    my ($self) = @_;
    my $sidcryptName = getSidcryptName($self->getTargetLssSid());
    my $sidcryptUser = SDB::Install::LSS::LssSidcryptUser->new($sidcryptName);

    if($sidcryptUser->hasgroup($gSapsysGroupName)){
        $self->appendErrorMessage("Existing user '$sidcryptName' is not valid as it belongs to the '$gSapsysGroupName' group. Remove '$gSapsysGroupName' from the user's groups.");
        return 0;
    }
    return 1;
}

sub setExistingLSSGroupID {
    my ($self, $sidcrypUID) = @_;
    my $sidcryptName = getSidcryptName($self->getTargetLssSid());
    my $sidcryptUser = SDB::Install::LSS::LssSidcryptUser->new($sidcryptName);
    my $gid = $sidcryptUser->exists() ? $sidcryptUser->gid() : $self->{remoteUids}->{$sidcrypUID}->[0]->[2];

    my $rc = $self->setValue('LSSGroupID', $gid);
    $self->setHidden('LSSGroupID', 1) if($rc);
    return $rc;
}

sub handleLssGroup {
    my ($self) = @_;
    my $batchValue = $self->getBatchValue('LSSGroupID');
    return 0 if(defined $batchValue && !$self->checkLSSGroupName($batchValue));

    my $groupName = $self->getSidcryptGroupName();
    my $existingId = $self->getExistingGroupId($groupName);
    if(defined($existingId)){
        return $self->handleExistingOsID($existingId, 'LSSGroupID');
    } else {
        return $self->initLSSGroupID();
    }
}

sub getSidcryptGroupName {
    my ($self) = @_;
    my $defaultName = getSidcryptName($self->getTargetLssSid());
    return $self->{sidcryptGroupName} // $defaultName;
}

sub setSidcryptGroupName {
    my ($self, $groupName) = @_;
    $self->{sidcryptGroupName} = $groupName;
}

sub getLSSParams {
    return [ 'LSSInstPath', 'LSSPassword', 'LSSUserID', 'LSSGroupID',
        'LSSUserHomeDir', 'LSSUserShell', 'LSSBackupPassword'];
}

sub isInstallingLSS {
    my ($self) = @_;
    my $isLssSelected = $self->isComponentSelected($gKeynameLSS);
    my $isLssUpdate   = $self->isUpdatingComponent($gKeynameLSS);
    return $isLssSelected && !$isLssUpdate;
}

sub isUpdatingLSS {
    my ($self) = @_;
    return $self->isUpdatingComponent($gKeynameLSS);
}

sub initLSSGroupAndUserID {
    my ($self) = @_;
    return 1 if !$self->isInstallingLSS();

    my $rc = $self->handleLssUser();
    if(!defined $self->getExistingLssUserId()){
        $rc &&= $self->handleLssGroup();
    }
    return $rc;
}

sub isLSSPasswordRequired {
    my ($self) = @_;
    my $lssCompatibleHostsToBeAdded = $self->getAdditionalLssCompatibleHosts();
    return $self->isInstallingLSS() || ($self->isLSSInstalled() && @$lssCompatibleHostsToBeAdded > 0);
}

sub checkLSSInstPath {
    my ($self, $lssInstPath) = @_;
    return 0 if !$self->_isLssInstPathBlocklisted($lssInstPath);

    my @remoteLssHosts = @{$self->getRemoteLssCompatibleHosts()};
    return 1 if(! scalar(@remoteLssHosts) > 0 );

    if($self->getValue('Scope') eq 'instance'){
        $self->getMsgLst()->addMessage("$gShortProductNameLSS installation path cannot be checked on remote hosts, because scope parameter is set to instance.");
        $self->getMsgLst()->addMessage("Ensure that $lssInstPath is accessible on ".join(', ', @remoteLssHosts));
        return 1;
    }

    if(!File::stat::stat($lssInstPath)){
        $self->setErrorMessage ("Directory '$lssInstPath' doesn't exist");
        return undef;
    }

    my $errorList = SDB::Install::MsgLst->new();
    if(!$self->checkLssInstPathOnRemoteHosts($lssInstPath, $errorList)){
        my $sidMountPoint = File::Spec->catdir($lssInstPath, $self->getTargetLssSid());
        if(!$self->checkLssInstPathOnRemoteHosts($sidMountPoint)){
# We need to add only the messages from the check of $lssInstPath as this is what the user
# has really provided. The errors from the $sidMountPoint shouldn't be visualized.
            $self->setErrorMessage(undef, $errorList);
            return undef;
        };
    }
    return 1;
}

sub _isLssInstPathBlocklisted {
    my ($self, $instPath) = @_;
    my $normalizedInstPath = $self->_normalizeAndResolveInstPath($instPath);

    if (defined $normalizedInstPath){
        return 0 if !$self->_isLssInstPathExcluded($normalizedInstPath, $instPath);
        my $instDir = Path::Class::Dir->new($normalizedInstPath);
        return 0 if !$self->_checkTreeOwnership($instDir);
        return 1;
    }
    return 0;
}

sub _normalizeAndResolveInstPath {
    my ($self, $instPath) = @_;
    my ($normalizedInstPath, $success) = normalizeRelativePath($instPath, undef, 5);
    if(!$success){
        $self->setErrorMessage("$gShortProductNameLSS installation path '$instPath' is not absolute or has more than 5 links.");
        return undef;
    }
    return $normalizedInstPath;
}

sub _isLssInstPathExcluded {
    my ($self, $normalizedInstPath, $instPath) = @_;
    my $forbiddenPathsList = $self->_getLssInstPathExcludeList();

    foreach my $forbiddenPathData (@{$forbiddenPathsList}){
        my $forbiddenPath = $forbiddenPathData->{path};
        my $escapedForbiddenPath = quotemeta($forbiddenPath);
        my $forbiddenPathPatternSuffix = $forbiddenPathData->{shouldMatchExactly} ? '$' : '';
        my $forbiddenPathPattern = "^$escapedForbiddenPath$forbiddenPathPatternSuffix";

        next if($normalizedInstPath !~ /$forbiddenPathPattern/);

        $self->_setLssInstPathExcludedError($normalizedInstPath, $forbiddenPath, isLink($instPath));
        return 0;
    }
    return 1;
}

sub _getLssInstPathExcludeList {
    my ($self) = @_;
    my @excludeList = ();
    my $dataPath = $self->_getDataPath();
    my $logPath = $self->_getLogPath();
    my $sapmntDir = $self->getValue('Target');
    my $hanaDataPath = dirname($dataPath);
    my $hanaLogPath = dirname($logPath);
    my $sapSIDLocation = File::Spec->catfile($gSAPLocation, $self->getTargetLssSid());
    my @dirsToExclude = ($dataPath, $logPath, $sapmntDir, $hanaDataPath, $hanaLogPath, $gSAPLocation, $sapSIDLocation);

    foreach my $dir (@dirsToExclude){
        next if !$dir;
        my $shouldMatchExactly = $dir eq $gSAPLocation ? 1 : 0;
        my $pathData = { 'path' => $dir, 'shouldMatchExactly' => $shouldMatchExactly };
        push(@excludeList, $pathData);
    }
    return \@excludeList;
}

sub _setLssInstPathExcludedError {
    my ($self, $normalizedInstPath, $forbiddenPath, $isLink) = @_;
    my $errMsg = $isLink ?
        "$gShortProductNameLSS installation path resolves to '$normalizedInstPath' which cannot be in $gProductName directory '$forbiddenPath'. Choose another $gShortProductNameLSS installation path." :
        "$gShortProductNameLSS installation path cannot be in $gProductName directory '$forbiddenPath'. Choose another $gShortProductNameLSS installation path.";
    $self->setErrorMessage($errMsg);
    return 1;
}

sub _checkTreeOwnership {
    my ($self, $instDir) = @_;
    if($self->_isDirectoryOwnedByRootOrSidcrypt($instDir)){
        return 1 if($instDir->stringify() eq '/');
        return $self->_checkTreeOwnership($instDir->parent());
    }
    return 0;
}

sub _isDirectoryOwnedByRootOrSidcrypt {
    my ($self, $directory) = @_;
    my $sidcryptUid = $self->getExistingLssUserId();
    my $sidcryptName = getSidcryptName($self->getTargetLssSid());
    my $ownerUid = getDirectoryOwnerUid($directory);
    return 1 if !defined $ownerUid;

    my $ownedByRoot = $ownerUid == 0;
    my $ownedBySidcrypt = defined $sidcryptUid && $ownerUid == $sidcryptUid;
    return 1 if $ownedByRoot || $ownedBySidcrypt;
    $self->setErrorMessage("$gShortProductNameLSS must be installed in directory owned by user root or $sidcryptName. Choose another $gShortProductNameLSS installation path or correct the ownership of the current one.");
    return 0;
}

sub _getDataPath{
    my ($self) = @_;
    my $instance = $self->getOwnInstance();
    return $instance->getDataPath(1) if defined $instance;
    return $self->getValue('BasePathDataVolumes');
}

sub _getLogPath {
    my ($self) = @_;
    my $instance = $self->getOwnInstance();
    return $instance->getLogPath(1) if defined $instance;
    return $self->getValue('BasePathLogVolumes');
}

sub checkLssInstPathOnRemoteHosts {
    my($self, $path, $errorList) = @_;
    my $success = 1;
    my $remoteLssHosts = join(',',@{$self->getRemoteLssCompatibleHosts()});
    my $output = undef;
    $errorList //= SDB::Install::MsgLst->new();

    if ($self->getComponentManager()->isSidAdmUserExecution() || $self->SDB::Install::Configuration::AnyConfig::isUseSAPHostagent()) {
        my $sidadmExecution = new SDB::Install::RemoteHostctrlHosts(hostname());
        $sidadmExecution->setMsgLstContext($self->getMsgLstContext());

        my $authSID = $self->getTargetLssSid();
        my $passwordParamKey = "Password";

        if($self->getValue("HostagentPassword")) {
            $authSID = "sapadm";
            $passwordParamKey = "HostagentPassword";
        }

        my $shaOperation;
        my $optionMap = {
            SID  => $self->getTargetLssSid(),
            AUTHSID => $authSID,
            PATH => $path
        };

        my $sapSystem = $self->getSAPSystem();
        if ($sapSystem) {
            $shaOperation = $gOperationCheckLssPath;
            $optionMap->{SAPMNT}    = $sapSystem->get_target();
            $optionMap->{HOSTNAMES} = $remoteLssHosts;
        } else {
            $shaOperation = $gOperationFileExists;
        }

        my $rc = $sidadmExecution->executeHostctrlParallel(
                                    $shaOperation,
                                    $self, # instconfig
                                    undef, # param IDs
                                    [$passwordParamKey], # password IDs
                                    undef, # remote ignore
                                    undef, # remote timeout
                                    undef, #progress mssage
                                    "$gShortProductNameLSS installation path checked", #done message
                                    undef, #error msg
                                    $optionMap,
                                    undef, # host option map
                                    undef, # only on hosts
                                    undef, # do not fail
                                    1, # suppresses console output
                                    0); # isCollectHostInfo

        if( $rc != 0 ){
            $success = 0;
        }

        $output = $sidadmExecution->getOutputBuffer();
    } else {
        my $rootUser = $self->getValue('RootUser');
        my $sid = $self->getTargetLssSid();
        my @args = (
            '-main',
            'SDB::Install::App::Console::LSS::CheckInstallationPath::main',
            "--path=$path",
            "--hostnames=$remoteLssHosts",
            $rootUser ? "--root_user=$rootUser" : '',
            "--sid=$sid",
        );
        my $app = LCM::App::ApplicationContext::getInstance()->getApplication();
        my $installer = new LCM::Installer();
        my $runtimeDirectory = $installer->getRuntimeDir();
        my $cmd = File::Spec->catfile(dirname($runtimeDirectory), $app->getProgramName());

        my $stdinLines = $self->getXmlPasswordStream(['RootPassword']);
        my $processExecutor = LCM::ProcessExecutor->new($cmd,\@args, $stdinLines);
        my $exitCode = $processExecutor->executeProgram();
        $self->getMsgLst ()->addMessage(undef, $processExecutor->getMsgLst());

        if (!defined $exitCode || $exitCode){
            $success = 0;
        }
        $output = $processExecutor->getOutputLines();
    }
    if(!$success){
        chomp @{$output};
        $errorList->addError($_) for @{$output};
    }
    return $success;
}

1;