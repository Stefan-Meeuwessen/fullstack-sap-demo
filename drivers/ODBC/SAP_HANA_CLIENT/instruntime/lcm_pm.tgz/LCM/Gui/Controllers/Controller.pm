package LCM::Gui::Controllers::Controller;

use strict;

sub new {
	my ($class, $configuration, $wizard) = @_;
	my $self = {};
	bless $self, $class;
	$self->setConfiguration($configuration);
	$self->setWizard($wizard);
	return $self;
}

sub setConfiguration {
	$_[0]->{configuration} = $_[1];
}

sub getConfiguration {
	return $_[0]->{configuration};
}

sub setWizard {
	$_[0]->{wizard} = $_[1];
}

sub getWizard {
	return $_[0]->{wizard};
}

sub getCondensedSteps {
	...
}

sub getMapDialogIdToSkipPredicates {
	...
}

1;
