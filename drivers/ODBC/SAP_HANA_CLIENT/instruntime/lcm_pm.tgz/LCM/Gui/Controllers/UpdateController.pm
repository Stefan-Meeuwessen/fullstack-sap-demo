package LCM::Gui::Controllers::UpdateController;

use strict;
use LCM::Gui::Dialogs::Update::XSTenantDatabaseCredentialsDialog;
use LCM::Gui::Dialogs::Update::SystemUpdateProperties;
use LCM::Gui::Dialogs::ConfigureFastRestartOptionPropertiesDialog;

use base 'LCM::Gui::Controllers::Controller';

use LCM::Gui::PagePredicates qw (	ShouldSkipUpgradeProperties
									ShouldSkipAdditionalHostsProperties
									ShouldSkipStreamingPropertiesPage
									ShouldSkipEsStoragePage
									ShouldSkipAcceleratorPropertiesPage
									ShouldSkipInternalNetworkPropertiesPage
									ShouldSkipXSPropertiesPage
									ShouldSkipXSSpaceIsolationPropertiesPage
									ShouldSkipSelectXSApplicationsPage
									ShouldSkipLSSPropertiesDialog
									ShouldSkipXSTenantDatabaseCredentialsDialog
									ShouldSkipSystemUpdateProperties
									ShouldSkipConfigureFastRestartOptionPropertiesDialog);

sub getCondensedSteps {
	my $self = shift;
	my $wizard = $self->getWizard ();
	my @condensedSteps = (
		new LCM::Gui::Dialogs::Update::AdditionalHostsPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::UpgradeParameterDialog($wizard),
		new LCM::Gui::Dialogs::Update::SystemUpdateProperties($wizard),
		new LCM::Gui::Dialogs::ConfigureFastRestartOptionPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::InternalNetworkPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::LSSPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::StreamingPropertiesDialog($wizard ),
		new LCM::Gui::Dialogs::EsStoragePropertiesDialog($wizard),
		new LCM::Gui::Dialogs::AcceleratorPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::XSPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::XsDomainNameDialog($wizard),
		new LCM::Gui::Dialogs::Update::XSTenantDatabaseCredentialsDialog($wizard),
		new LCM::Gui::Dialogs::XSSpaceIsolationPropertiesDialog($wizard),
		new LCM::Gui::Dialogs::SelectXsComponentsDialog($wizard),
	);
	return \@condensedSteps;
}

sub getMapDialogIdToSkipPredicates {
	return {
		'UpgradeProperties' => sub{ ShouldSkipUpgradeProperties() },
		'ConfigureFastRestartOptionProperties' => sub { ShouldSkipConfigureFastRestartOptionPropertiesDialog() },
		'SystemUpdateProperties' => sub{ ShouldSkipSystemUpdateProperties() },
		'HostsProperties' => sub{ ShouldSkipAdditionalHostsProperties() },
		'LSSPropertiesDialog' => sub { ShouldSkipLSSPropertiesDialog() },
		'StreamingProperties' => sub{ ShouldSkipStreamingPropertiesPage() },
		'EsStoragePropertiesDialog' => sub{ ShouldSkipEsStoragePage() },
		'AcceleratorProperties' => sub{ShouldSkipAcceleratorPropertiesPage()},
		'InterServiceCommunicationProperties' => sub{ ShouldSkipInternalNetworkPropertiesPage() },
		'XSProperties' => sub { ShouldSkipXSPropertiesPage() },
		'XSTenantDatabaseCredentialsDialog' => sub { ShouldSkipXSTenantDatabaseCredentialsDialog() },
		'XSSpaceIsolationProperties' => sub { ShouldSkipXSSpaceIsolationPropertiesPage() },
		'SelectXsComponents' => sub { ShouldSkipSelectXSApplicationsPage() },
	};
}

1;
