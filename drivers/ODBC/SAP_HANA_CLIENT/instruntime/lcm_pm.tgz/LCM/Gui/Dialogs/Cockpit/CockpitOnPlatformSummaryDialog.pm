package LCM::Gui::Dialogs::Cockpit::CockpitOnPlatformSummaryDialog;

use strict;
use warnings;

use parent qw(LCM::Gui::Dialogs::SummaryDialog);

sub getInstallMode{
    my $self = shift;
    return '&Install' if($self->isInstall());
    return $self->SUPER::getInstallMode();
}

sub setNextLabel{
    my $self = shift;
    $self->SUPER::setNextLabel();
    if($self->isInstall()){
        $self->GetWizard->{'nbutton'}->SetLabel("&Install");
    }
}

sub isInstall{
    my $app = Wx::wxTheApp();
    my $config = $app->getInstconfig();
     return !$config->isCockpitStackUpdate();
}
1;