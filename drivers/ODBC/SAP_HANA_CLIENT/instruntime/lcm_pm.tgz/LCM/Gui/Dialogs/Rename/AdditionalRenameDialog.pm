package LCM::Gui::Dialogs::Rename::AdditionalRenameDialog;

use strict;
use warnings;

use SDB::Install::Gui::Dialogs::GenericParameter;
use LCM::Gui::PagePredicates qw(ShouldSkipConfigureFastRestartOptionPropertiesDialog);

use parent qw(SDB::Install::Gui::Dialogs::GenericParameter);

sub new {
    my $class = shift();
    my $self = $class->SUPER::new(@_);
    $self->{name} = 'Define Additional Rename Properties';
    $self->{label_text} = 'Specify Additional Rename Properties';
    return $self;
}

sub getParamKeys {
    return ['ConfigureFastRestartOption'];
}

sub Process {
    my ($self, $config) = @_;
    my $returnHash = $self->SUPER::Process($config);

    if (ShouldSkipConfigureFastRestartOptionPropertiesDialog()) {
        $self->GetWizard()->SkipDialog('ConfigureFastRestartOptionProperties');
        return $returnHash;
    }

    $self->GetWizard()->SkipDialog('ConfigureFastRestartOptionProperties', 0); #unskip
    return $returnHash;
}

1;
