package LCM::Gui::Dialogs::OrgManagerCredentialsDialog;
use parent qw(LCM::Gui::Dialogs::GenericCredentialsDialog);
use strict;

use SDB::Install::Globals qw($gProductNameXS2);

sub new {
    my $self = shift->SUPER::new(@_);

    $self->{id}         = 'OrgManagerCredentials';
    $self->{label_text} = "Provide $gProductNameXS2 Credentials";
    $self->{name}       = "Enter $gProductNameXS2 Credentials";
    return $self;
}

sub getParamIds{
    my ($self,$config) = @_;
    my @paramIds = qw(OrgManagerUser OrgManagerPassword);
    return [@paramIds];
}

1;