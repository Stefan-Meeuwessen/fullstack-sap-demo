package LCM::Gui::Dialogs::Cockpit::CockpitTenantCredentialsDialog;

use strict;
use warnings;

use parent qw(LCM::Gui::Dialogs::GenericCredentialsDialog);

sub new {
    my ( $self ) = shift->SUPER::new( @_ );
    $self->{id}         = 'CockpitTenantCredentilsDialog';
    $self->{label_text} = "Specify Cockpit Tenant Authorization Properties";
    $self->{name}       = "Define Cockpit Tenant Authorization Properties";
    return $self;
}

sub getParamIds{
    my $self = shift;
    return ['CockpitTenantUser','CockpitTenantUserPassword'];
}

sub DirectNavigationAllowed ($) {0}

1;