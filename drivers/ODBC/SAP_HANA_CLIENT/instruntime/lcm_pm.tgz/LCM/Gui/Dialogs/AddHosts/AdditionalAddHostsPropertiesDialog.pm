package LCM::Gui::Dialogs::AddHosts::AdditionalAddHostsPropertiesDialog;

use strict;
use warnings;

use SDB::Install::Gui::Dialogs::GenericParameter;
use LCM::Gui::PagePredicates qw(ShouldSkipConfigureFastRestartOptionPropertiesDialog);

use parent qw(SDB::Install::Gui::Dialogs::GenericParameter);

sub new {
    my $class = shift();
    my $self = $class->SUPER::new(@_);
    $self->{name} = 'Define Additional Add Hosts Properties';
    $self->{label_text} = 'Specify Additional Add Hosts Properties';
    return $self;
}

sub getParamKeys{
    return ['ConfigureFastRestartOption'];
}

sub Process {
    my ($self, $config) = @_;
    my $returnHash = $self->SUPER::Process($config);
    if (ShouldSkipConfigureFastRestartOptionPropertiesDialog()) {
        $self->GetWizard()->SkipDialog('ConfigureFastRestartOptionProperties');
        return $returnHash;
    }
    $self->GetWizard()->SkipDialog('ConfigureFastRestartOptionProperties', 0); #unskip
    return $returnHash;
}

1;
