package LCM::Gui::Dialogs::Uninstall::DatabaseCredentials;
use parent qw(LCM::Gui::Dialogs::GenericCredentialsDialog);
use strict;

sub new {
    my $self = shift->SUPER::new(@_);

    $self->{id}         = 'DatabaseCredentials';
    $self->{label_text} = "Provide Database Credentials";
    $self->{name}       = "Enter Database Credentials";
    return $self;
}

sub getParamIds{
    my ($self,$config) = @_;
    my @paramIds = qw(SystemUser SQLSysPasswd AcceleratorUser AcceleratorPassword TenantUser SQLTenantUserPassword);
    return [@paramIds];
}

1;