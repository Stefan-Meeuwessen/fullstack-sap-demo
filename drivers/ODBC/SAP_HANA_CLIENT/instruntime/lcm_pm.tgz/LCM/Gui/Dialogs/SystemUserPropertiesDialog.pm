package LCM::Gui::Dialogs::SystemUserPropertiesDialog;

use base qw(LCM::Gui::Dialogs::GenericCredentialsDialog);
use strict;

sub new{
    my($self) = shift->SUPER::new(@_);
    my $flavourProductName = LCM::App::ApplicationContext::getFlavourProductName();
    $self->{id} = 'SystemUserProperties';
    $self->{label_text} = "Enter $flavourProductName authorization data";
    $self->{name} = "Define Authorization Properties";
    return $self;
}

sub getParamIds{
    my ($self,$config) = @_;
    return ['LSSPassword', 'SystemUser', 'SQLSysPasswd', 'TenantUser', 'SQLTenantUserPassword'];
}

1;
