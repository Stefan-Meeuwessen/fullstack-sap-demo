package LCM::Gui::Dialogs::AddHostRoles::AdditionalRolesDialog;

use strict;
use parent qw(LCM::Gui::Dialogs::AdditionalRolesDialog);

use SDB::Install::Globals qw ( GetAllRoles );
use LCM::App::AddHostRolesUtils qw(getPossibleRolesForExistingHosts);

sub handleRolesAccessability {
    my ($self, $hostObj) = @_;
    my $config = LCM::Gui::DialogUtilities::GetAppConfig();
    my @allValidRoles = @{GetAllRoles()};
    my $mHostToValidAdditionalRoles = getPossibleRolesForExistingHosts($config);
    my $aValidAdditionalRoles = $mHostToValidAdditionalRoles->{$hostObj->getHost()};
    for my $validRole (@allValidRoles) {
        my $isValidAdditionalRole = grep { $_ eq $validRole } @{$aValidAdditionalRoles};
        if (!$isValidAdditionalRole) {
            $self->{"role_$validRole"}->Enable(0);
        } else {
            $self->{"role_$validRole"}->Enable(1);
        }
    }
}

sub getRelevantRoles {
    my ($self) = @_;
    my $config = LCM::Gui::DialogUtilities::GetAppConfig();
    my $availableRolesForExistingHosts = getPossibleRolesForExistingHosts($config)->{$self->getHost()};
    my @relevantRoles;

    # Keep only the available roles for the given host. Otherwise the validation on the OK button will blow
    # up in the add_roles case
    foreach my $selectedRole (@{$self->getSelectedRoles()}) {
        next if !grep { $_ eq $selectedRole } @{$availableRolesForExistingHosts};
        push(@relevantRoles, $selectedRole);
    }

    return \@relevantRoles;
}

sub getValidationParamID {
    return 'AddRoles';
}

1;