package LCM::Gui::Dialogs::Update::SystemUpdateProperties;

use base qw(SDB::Install::Gui::Dialogs::GenericParameter);

use Wx::Event qw (EVT_COMBOBOX);
use strict;

sub new{
    my($self) = shift->SUPER::new(@_);

    $self->{id} = 'SystemUpdateProperties';
    $self->{label_text} = 'Specify Update Properties';
    $self->{name} = 'Specify Update Properties';

    return $self;
}

sub getParamKeys{
    my ($self) = @_;
    return ['ApplyResourceLimits', 'ConfirmPython2ToPython3Switch', 'ConfigureFastRestartOption'];
}

sub Process {
    my ($self, $config) = @_;
    my $returnHash = $self->SUPER::Process($config);
    $self->GetWizard()->RefreshSkippableDialogs();
    return $returnHash;
}

sub createDialog {
    my ($self) = @_;
    my $app = Wx::wxTheApp();
    my $instconfig = $app->getInstconfig();

    # the point of this method overriding is to reset the value of the ConfirmPython2ToPython3Switch each time the SystemUpdateProperties dialog is loaded
    # this has to be done in order to make sure that each time the dialog is loaded, the confirmation box will not be ticked
    $instconfig->resetConfirmPython2ToPython3Switch();

    return $self->SUPER::createDialog(@_);
}

1;