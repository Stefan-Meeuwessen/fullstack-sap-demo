package LCM::Gui::Dialogs::XsDomainNameDialog;

use strict;
use SDB::Install::Globals qw($gEvenShorterProductNameXSA);
use parent qw(SDB::Install::Gui::Dialogs::GenericParameter);

sub new{
    my ($self) = shift->SUPER::new(@_);

    $self->{id} = 'XsDomainName';
    $self->{label_text} = "Specify $gEvenShorterProductNameXSA Domain Name";
    $self->{name} = "Define $gEvenShorterProductNameXSA Domain Name Properties";

    return $self;
}

sub getParamKeys {
    return ['XsDomainName'];
}

1;

