package LCM::Gui::Dialogs::SLD::RegistrationPropertiesDialog;

use base qw(SDB::Install::Gui::Dialogs::GenericParameter);
use strict;

sub new{
    my($self) = shift->SUPER::new(@_);
    
    $self->{id} = 'SLDRegistrationProperties';
    $self->{label_text} = "SLD Registration Configuration";
    $self->{name} = 'Enter SLD Properties';
    
    return $self;
}

sub getParamKeys{
    my ($self) = @_;
    my $paramKeys = ['SLDHostname', 'SLDPort', 'SLDUsername', 'SLDPassword', 'UseHTTPS'];
    return $paramKeys;
}

1;
