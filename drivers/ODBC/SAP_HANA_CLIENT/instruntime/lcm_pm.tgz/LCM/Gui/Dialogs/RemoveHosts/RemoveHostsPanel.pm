package LCM::Gui::Dialogs::RemoveHosts::RemoveHostsPanel;


use Wx qw ( wxVERTICAL wxEXPAND wxGROW wxDefaultPosition wxDefaultSize wxDefaultValidator wxLB_MULTIPLE);

use LCM::Gui::DialogUtilities qw ( GetAppConfig );

use base (LCM::Gui::Dialogs::HostsPanel);

sub createHostsListCtrl {
    my($self) = @_;
    my $list = $self->_createListCtrl();
    return $list;
}

sub _createListCtrl {
    my ($self) = @_;
    my $window = $self->getWindow();
    my $instconfig = LCM::Gui::DialogUtilities::GetAppConfig();
   
    return new Wx::CheckListBox($window, 0, wxDefaultPosition, wxDefaultSize, [], wxLB_MULTIPLE, wxDefaultValidator);

}

sub newAddHostsSizer {
    my ( $self) = @_;
    my $sizer = new Wx::BoxSizer(wxVERTICAL);

    my $hostsList = $self->createHostsListCtrl( );
    $self->addWindowControl( 'HostsList',  $hostsList);
    $sizer->Add( $hostsList, 1, wxEXPAND | wxGROW);
    $sizer->AddSpacer(10);
   
    return $sizer;
   
}
1;