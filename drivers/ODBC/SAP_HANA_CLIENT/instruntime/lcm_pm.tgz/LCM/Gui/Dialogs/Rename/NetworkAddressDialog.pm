package LCM::Gui::Dialogs::Rename::NetworkAddressDialog;

use strict;
use parent 'LCM::Gui::Dialogs::InternalNetworkPropertiesDialog';

sub new {
    my($self) = shift->SUPER::new(@_);

    $self->{id} 		= 'NetworkAddressDialog';
    $self->{name}		= 'Define Network Properties';
    $self->{label_text} = 'Define Network Properties';

    return $self;
}

1;