package LCM::Gui::Dialogs::AdditionalInstallationDialog;

use strict;
use warnings;

use SDB::Install::Gui::Dialogs::GenericParameter;
use SDB::Install::Gui::Design;
use SDB::Install::Configuration qw($bool_true_pattern);
use Wx qw(
	wxALIGN_CENTER_VERTICAL
	wxEXPAND
	wxALIGN_TOP
	wxSL_HORIZONTAL
	wxSL_LABELS
);
use Wx::Event qw(EVT_CHECKBOX);

use parent qw(SDB::Install::Gui::Dialogs::GenericParameter);

sub new {
	my $class = shift();
	my $self = $class->SUPER::new(@_);

	$self->{name} = 'Define Additional Installation Properties';
	$self->{label_text} = 'Specify Additional Installation Properties';

	return $self;
}

sub getParamKeys{
	return ['BackupEncryption', 'VolumeEncryption', 'ApplyResourceLimits', 'ConfigureFastRestartOption'];
}

sub init {
	my ($self) = @_;
	my $instconfig = Wx::wxTheApp()->getInstconfig();
	my $rc = $self->SUPER::init($instconfig);
	return $rc if defined $rc->{'errstate'};

	my $ctrl;
	for my $paramId ('AutoStart', 'RestrictMaxMem', 'MaxMem') {
		$ctrl = $self->getParamCtrl ($paramId);
		next unless(exists($instconfig->{params}->{$paramId}) && defined ($instconfig->{params}->{$paramId}));
		next if (!defined $ctrl);

		my $param = $instconfig->{params}->{$paramId};
		$instconfig->setBatchValue($paramId) if !defined $param->{value};

		my $value = (defined $param->{value} ? $param->{value} : $instconfig->getDefault($paramId));
		$ctrl->SetValue($value);
	}

	$ctrl = $self->getParamCtrl('MaxMem');
	$ctrl->Enable($instconfig->getValue('RestrictMaxMem')) if defined $ctrl;
	return $rc;
}

sub addControls {
	my ($self) = @_;
	my $instconfig = Wx::wxTheApp()->getInstconfig();

	if (!(exists $self->{dynctrl}->{'AutoStart_ctrl'})) {
		$self->_addAutoStart();
	}

	if (defined $instconfig->{params}->{'EnableXSEngine'}){
		$self->_addEnableXSEngine();
	}

	if ($self->_shouldAddRestrictMaxMemoryControls()) {
		$self->_addRestrictMaxMemory();
		$self->_addMaxMemory();
	}
	return 1;
}

sub SyncCtrls{
	my ($self, $instconfig) = @_;
	my $hasValidValues;
	my $ctrl;
	foreach my $param_id (@{$instconfig->getParamIds ()}){
		$hasValidValues = defined $instconfig->{params}->{$param_id}->{valid_values};
		$ctrl = $self->getParamCtrl($param_id);
		if (defined $ctrl){
			if (defined $instconfig->{params}->{$param_id}->{value}){
				$ctrl->SetValue ($hasValidValues ? $instconfig->getUIStringFromValue($param_id, $instconfig->{params}->{$param_id}->{value}) : $instconfig->{params}->{$param_id}->{value});
				$ctrl->Enable (0);
			}
			else{
				$ctrl->SetValue ($hasValidValues ? $instconfig->getUIStringFromValue($param_id, $instconfig->getDefault ($param_id)) : $instconfig->getDefault ($param_id));
				$ctrl->Enable (1);
			}
		}
	}

	my $param = $instconfig->{params}->{'AutoStart'};
	my $value = (defined $param->{value} ? $param->{value} : $instconfig->getDefault('AutoStart'));
	$ctrl = $self->getParamCtrl ('AutoStart');
	$ctrl->SetValue($value);
	if (defined $param->{value}) {
		$ctrl->Enable(0);
	} else {
		$ctrl->Enable(1);
	}
	$ctrl = $self->getParamCtrl ('EnableXSEngine');
	if(defined $ctrl) {
		$param = $instconfig->{params}->{'EnableXSEngine'};
		$value = (defined $param->{value} ? $param->{value} : $instconfig->getDefault('EnableXSEngine'));
		$ctrl->SetValue($value);
		if (defined $param->{value}) {
			$ctrl->Enable(0);
		} else {
			$ctrl->Enable(1);
		}
	}
	return 1;
}

sub Cleanup{
	my ($self) = @_;
	delete $self->{dynctrl}->{'AutoStart_ctrl'} if defined $self->{dynctrl}->{'AutoStart_ctrl'};
	delete $self->{dynctrl}->{'EnableXSEngine_ctrl'} if defined $self->{dynctrl}->{'EnableXSEngine_ctrl'};
	$self->SUPER::Cleanup();
	return 1;
}

sub Process{
    my ($self,$config) = @_;
    my $returnHash = $self->SUPER::Process($config);
    my $instconfig = Wx::wxTheApp->{instconfig};

    my $param;
    my $ctrl;
    foreach my $param_id ('AutoStart', 'RestrictMaxMem', 'EnableXSEngine'){
        $param = $instconfig->{params}->{$param_id};
        next if !defined $param;
        next if defined $param->{set_interactive} && !$param->{set_interactive};
        $ctrl = $self->getParamCtrl($param_id);
        next if !defined $ctrl; # skip if there is no control added for this parameter
        $param->{value} = $ctrl->GetValue() ? 1 : 0;
    }

    $self->GetWizard()->RefreshSkippableDialogs();

    my $restrictMaxMem = $instconfig->{params}->{RestrictMaxMem}->{value};
    if (defined $restrictMaxMem && $restrictMaxMem =~ /$bool_true_pattern/i){
        $instconfig->{params}->{MaxMem}->{value} = $self->{dynctrl}->{'MaxMem_ctrl'}->GetValue();
        return $returnHash;
    }
    $instconfig->{params}->{MaxMem}->{value} = 0;
    return $returnHash;
}

sub _shouldAddRestrictMaxMemoryControls {
	my ($self,) = @_;
	my $instconfig = Wx::wxTheApp()->{instconfig};
	my $controlsAreNotCreated = ( ! exists $self->{dynctrl}->{'RestrictMaxMem_ctrl'} || ! exists $self->{dynctrl}->{'MaxMem_ctrl'} ) ? 1 : 0;
	my $parametersAreNotSkipped = ( ! $instconfig->isSkipped('RestrictMaxMem') && ! $instconfig->isSkipped('MaxMem')) ? 1 : 0;
	return $controlsAreNotCreated && $parametersAreNotSkipped;
}

sub _addRestrictMaxMemory {
	my ($self) = @_;
	my $instconfig = Wx::wxTheApp()->{instconfig};
	my $rMemParam = $instconfig->{params}->{'RestrictMaxMem'};

	my $restrictMaxMemCheckBox = new Wx::CheckBox($self, -1, $rMemParam->{'ui_str'}, [-1,-1], [-1,-1]);
	EVT_CHECKBOX($self, $restrictMaxMemCheckBox->GetId(), \&_onRestrictMaxMem);
	my %ctrlOptions = (
		'parameterId' => 'RestrictMaxMem',
		'controlType' => 'ctrl',
		'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
	);
	my $value = (defined $rMemParam->{value} ? $rMemParam->{value} : $instconfig->getDefault('RestrictMaxMem'));
	$restrictMaxMemCheckBox->SetValue($value);
	if (defined $rMemParam->{set_interactive} && !$rMemParam->{set_interactive} && !$rMemParam->{skip}){
		$restrictMaxMemCheckBox->Show(0);
	}

	if (defined $rMemParam->{value} && !$rMemParam->{skip}) {
		$restrictMaxMemCheckBox->Enable(0);
	}
	my %labelOptions = (
		'parameterId' => 'RestrictMaxMem',
		'controlType' => 'label',
		'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
	);
	$self->addControlToGridSizer(new Wx::StaticText($self, -1, ''), \%labelOptions);
	$self->addControlToGridSizer($restrictMaxMemCheckBox, \%ctrlOptions );
	return 1;
}

sub _addMaxMemory {
	my ($self) = @_;
	my $labelText = 'Memory in MB';
	my $maxMemLabel = new Wx::StaticText($self, -1, $labelText);
	my %options = (
		'parameterId' => 'MaxMem',
		'controlType' => 'label',
		'controlOptions' => [0, wxALIGN_CENTER_VERTICAL]
	);
	$self->addControlToGridSizer($maxMemLabel, \%options );

	my $instconfig = Wx::wxTheApp()->{instconfig};
	my $memParam = $instconfig->{params}->{'MaxMem'};
	my $value = (defined $memParam->{value} ? $memParam->{value} :	$instconfig->getDefault('MaxMem'));
	my $maxMemControl = new Wx::Slider($self, -1, $value, $memParam->{minValue} ,$memParam->{maxValue}, [-1,-1], [-1,-1], wxSL_HORIZONTAL | wxSL_LABELS);
	%options = (
		'parameterId' => 'MaxMem',
		'controlType' => 'ctrl',
		'controlOptions' => [1, wxEXPAND | wxALIGN_TOP]
	);
	$self->addControlToGridSizer($maxMemControl, \%options );

	if (defined $memParam->{set_interactive} && !$memParam->{set_interactive} && !$memParam->{skip}){
		$maxMemControl->Show(0);
	}

	if ((defined $memParam->{value} && !$memParam->{skip}) || $self->{dynctrl}->{'RestrictMaxMem_ctrl'}->IsEnabled()) {
		$maxMemControl->Enable(0);
	}
	return 1;
}

sub _onRestrictMaxMem {
	my ($self,$evt) = @_;
	$self->{dynctrl}->{'MaxMem_ctrl'}->Enable($evt->IsChecked());
	return 1;
}

sub _addAutoStart {
	my ($self,) = @_;
	my $instconfig = Wx::wxTheApp()->{instconfig};
	my $param = $instconfig->{params}->{'AutoStart'};

	my $autoStartControl = new Wx::CheckBox($self, -1, $param->{'ui_str'}, [-1,-1], [-1,-1]);
	my %ctrlOptions = (
			'parameterId' => 'AutoStart',
			'controlType' => 'ctrl',
			'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
	);
	my $value = (defined $param->{value} ? $param->{value} : $instconfig->getDefault('AutoStart'));
	$autoStartControl->SetValue($value);
	if (defined $param->{set_interactive} && !$param->{set_interactive}){
		$autoStartControl->Show(0);
	}
	if (defined $param->{value}) {
		$autoStartControl->Enable(0);
	}

	my %labelOptions = (
			'parameterId' => 'AutoStartSpace',
			'controlType' => 'label',
			'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
	);
	$self->addControlToGridSizer(new Wx::StaticText($self, -1, ''), \%labelOptions);
	$self->addControlToGridSizer($autoStartControl, \%ctrlOptions );
	return 1;
}

sub _addEnableXSEngine {
	my ($self,) = @_;
	my $instconfig = Wx::wxTheApp()->{instconfig};
	my $param = $instconfig->{params}->{'EnableXSEngine'};
	my $enableXSEngineControl = new Wx::CheckBox($self, -1,$param->{'str'}, [-1,-1], [-1,-1]);
	my %options = (
			'parameterId' => 'EnableXSEngine',
			'controlType' => 'ctrl',
			'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
	);
	my $value = (defined $param->{value} ? $param->{value} : $instconfig->getDefault('EnableXSEngine'));
	$enableXSEngineControl->SetValue($value);
	if (defined $param->{set_interactive} && !$param->{set_interactive}){
		$enableXSEngineControl->Show(0);
	}
	if (defined $param->{value}) {
		$enableXSEngineControl->Enable(0);
	}
	$self->addControlToGridSizer($enableXSEngineControl, \%options );
	return 1;
}

1;
