package LCM::Gui::Dialogs::Update::XSTenantDatabaseCredentialsDialog;

use strict;
use warnings;
use SDB::Install::Globals qw($gShortProductNameXS2);

use parent qw(LCM::Gui::Dialogs::GenericCredentialsDialog);

sub new {
    my ( $self ) = shift->SUPER::new( @_ );
    $self->{id}         = 'XSTenantDatabaseCredentialsDialog';
    $self->{label_text} = "$gShortProductNameXS2 Tenant Database Authorization Properties";
    $self->{name}       = "Define $gShortProductNameXS2 Tenant Authorization Properties";
    return $self;
}

sub getParamIds{
    my $self = shift;
    return ['TenantUser', 'SQLTenantUserPassword'];
}

sub DirectNavigationAllowed ($) {0}

1;