package LCM::Gui::Dialogs::ConfigurationExecutionProgressHandler;
use SDB::Install::Gui::Dialogs::Install;
use SDB::Common::Utils qw( trim );
use parent qw(SDB::Install::Gui::Dialogs::PackageProgressHandler);
use strict;

sub new {
    my $self = shift->SUPER::new (@_);
    $self->{label} = $_[1];
    $self->{id} = 'configurationProgressHandler';
    return $self;
}

sub addLine{
    my ($self, $text) = @_;
    $self->{label}->SetLabel (trim($text));
    $self->SetProgress ($text);
}

1;