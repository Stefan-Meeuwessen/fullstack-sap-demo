package LCM::Gui::Dialogs::ConfigureFastRestartOptionPropertiesDialog;

use strict;
use warnings;

use SDB::Install::Configuration qw($bool_true_pattern);
use Wx qw(
    wxALIGN_CENTER_VERTICAL
    wxEXPAND
    wxALIGN_TOP
    wxSL_HORIZONTAL
    wxSL_LABELS
);
use Wx::Event qw(EVT_CHECKBOX);

use parent qw(SDB::Install::Gui::Dialogs::GenericParameter);

sub new {
    my $class = shift();
    my $self = $class->SUPER::new(@_);

    $self->{id} = 'ConfigureFastRestartOptionProperties';
    $self->{label_text} = 'Specify Fast Restart Option Properties';
    $self->{name} = 'Define Fast Restart Option Properties';

    return $self;
}

sub Process {
    my ($self, $config) = @_;
    my $returnHash = $self->SUPER::Process($config);
    my $instconfig = Wx::wxTheApp()->getInstconfig();

    my $restrictTgalControl = $self->getParamCtrl('RestrictTmpfsGlobalAllocationLimit');
    $instconfig->{params}->{'RestrictTmpfsGlobalAllocationLimit'}->{value} = $restrictTgalControl->GetValue();

    $self->GetWizard()->RefreshSkippableDialogs();

    my $restrictTgalValue = $instconfig->{params}->{RestrictTmpfsGlobalAllocationLimit}->{value};
    if (defined $restrictTgalValue && $restrictTgalValue =~ /$bool_true_pattern/i){
        $instconfig->{params}->{TmpfsGlobalAllocationLimit}->{value} = $self->{dynctrl}->{'TmpfsGlobalAllocationLimit_ctrl'}->GetValue();
        return $returnHash;
    }
    $instconfig->{params}->{TmpfsGlobalAllocationLimit}->{value} = 0;
    return $returnHash;
}

sub getParamKeys {
    return ['TmpfsMountpointsPath'];
}

sub addControls {
    my ($self) = @_;
    $self->_addRestrictTmpfsGlobalAllocationLimit();
    $self->_addTmpfsGlobalAllocationLimit();
    return 1;
}

sub _addRestrictTmpfsGlobalAllocationLimit {
    my ($self) = @_;
    my $instconfig = Wx::wxTheApp()->getInstconfig();
    my $rTmpfsParam = $instconfig->{params}->{'RestrictTmpfsGlobalAllocationLimit'};

    my $restrictTmpfsCheckBox = new Wx::CheckBox($self, -1, $rTmpfsParam->{'ui_str'}, [-1, -1], [-1, -1]);
    EVT_CHECKBOX($self, $restrictTmpfsCheckBox->GetId(), \&_onRestrictTmpfsGlobalAllocationLimit);

    my %ctrlOptions = (
        'parameterId' => 'RestrictTmpfsGlobalAllocationLimit',
        'controlType' => 'ctrl',
        'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
    );

    my $value = defined $rTmpfsParam->{value} ? $rTmpfsParam->{value} : $instconfig->getDefault('RestrictTmpfsGlobalAllocationLimit');
    $restrictTmpfsCheckBox->SetValue($value);

    $self->_setRestrictTmpfsGlobalAllocationLimitVisibility($restrictTmpfsCheckBox, $rTmpfsParam);

    my %labelOptions = (
        'parameterId' => 'RestrictTmpfsGlobalAllocationLimit',
        'controlType' => 'label',
        'controlOptions' => [0, wxEXPAND | wxALIGN_TOP]
    );

    $self->addControlToGridSizer(new Wx::StaticText($self, -1, ''), \%labelOptions);
    $self->addControlToGridSizer($restrictTmpfsCheckBox, \%ctrlOptions);
    return 1;
}

sub _setRestrictTmpfsGlobalAllocationLimitVisibility {
    my ($self, $control, $param) = @_;
    $self->_showParamControlIfNeeded($control, $param);
    $control->Enable(0) if $param->{skip};
    return 1;
}

sub _addTmpfsGlobalAllocationLimit {
    my ($self) = @_;
    my $labelText = 'Tmpfs Allocation in MB';
    my $tmpfsLabel = new Wx::StaticText($self, -1, $labelText);

    my %labelOptions = (
        'parameterId' => 'TmpfsGlobalAllocationLimit',
        'controlType' => 'label',
        'controlOptions' => [0, wxALIGN_CENTER_VERTICAL]
    );

    $self->addControlToGridSizer($tmpfsLabel, \%labelOptions);

    my $instconfig = Wx::wxTheApp()->getInstconfig();
    my $tmpfsParam = $instconfig->{params}->{'TmpfsGlobalAllocationLimit'};
    my $value = defined $tmpfsParam->{value} ? $tmpfsParam->{value} : $instconfig->getDefault('TmpfsGlobalAllocationLimit');
    my ($maxValue) = $instconfig->getTmpfsGlobalAllocationLimitMaxValue();
    my $tmpfsSlider = new Wx::Slider(
        $self, -1, $value, $tmpfsParam->{minValue}, $maxValue, [-1, -1], [-1, -1], wxSL_HORIZONTAL | wxSL_LABELS
    );

    my %controlOptions = (
        'parameterId' => 'TmpfsGlobalAllocationLimit',
        'controlType' => 'ctrl',
        'controlOptions' => [1, wxEXPAND | wxALIGN_TOP]
    );

    $self->_setTmpfsGlobalAllocationLimitVisibility($tmpfsSlider, $tmpfsParam);
    $self->addControlToGridSizer($tmpfsSlider, \%controlOptions);
    return 1;
}

sub _setTmpfsGlobalAllocationLimitVisibility {
    my ($self, $control, $param) = @_;
    $self->_showParamControlIfNeeded($control, $param);

    my $paramIsNotSkipped = defined $param->{value} && !$param->{skip};
    my $restrictTgalCheckbox = $self->{dynctrl}->{'RestrictTmpfsGlobalAllocationLimit_ctrl'};
    if (($paramIsNotSkipped || $restrictTgalCheckbox->IsEnabled()) && !$restrictTgalCheckbox->IsChecked()) {
        $control->Enable(0);
    }
    return 1;
}

sub _showParamControlIfNeeded {
    my ($self, $control, $param) = @_;
    if (defined $param->{set_interactive} && !$param->{set_interactive} && !$param->{skip}) {
        $control->Show(0);
    }
    return 1;
}

sub _onRestrictTmpfsGlobalAllocationLimit {
    my ($self, $evt) = @_;
    $self->{dynctrl}->{'TmpfsGlobalAllocationLimit_ctrl'}->Enable($evt->IsChecked());
    return 1;
}

1;
