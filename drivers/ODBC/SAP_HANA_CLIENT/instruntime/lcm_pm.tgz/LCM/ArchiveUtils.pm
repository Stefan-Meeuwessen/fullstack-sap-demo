package LCM::ArchiveUtils;

use strict;
use warnings;

use Archive::Zip qw(:ERROR_CODES);
use LCM::FileUtils qw(MyRealPath);
use SDB::Install::System qw(isRegularFile);
use SDB::Install::MsgLst;

use parent qw(Exporter);

our @EXPORT = qw(extractZip);

sub extractZip {
    my ($zipFilePath, $destFilePath, $msgList) = @_;

    # Prevent Archive::Zip from outputting errors to the screen
    # as we'll be using our own handling for that
    Archive::Zip::setErrorHandler(sub{});

    $msgList //= SDB::Install::MsgLst->new();

    if(!defined $zipFilePath || length($zipFilePath) == 0) {
        $msgList->addError("ZIP file path cannot be empty");
        return 0;
    }

    if(!defined $destFilePath || length($destFilePath) == 0) {
        $msgList->addError("Destination file path cannot be empty");
        return 0;
    }

    my $zipRouteMessage = "'$zipFilePath'";
    my $destRouteMessage = "'$destFilePath'";

    if(!isRegularFile($zipFilePath)) {
        $msgList->addError("File $zipRouteMessage does not exist or is a directory");
        return 0;
    }

    my $realZipFilePath = MyRealPath($zipFilePath);
    $realZipFilePath = $zipFilePath if length($realZipFilePath) == 0;
    my $realDestFilePath = MyRealPath($destFilePath);
    $realDestFilePath = $destFilePath if length($realDestFilePath) == 0;

    $zipRouteMessage  .= " ($realZipFilePath)" if $zipFilePath ne $realZipFilePath;
    $destRouteMessage .= " ($realDestFilePath)" if $destFilePath ne $realDestFilePath;

    my $errorOpeningPrefix = "Failed to open ZIP file $zipRouteMessage:";
    my $errorExtractingPrefix = "Failed to extract ZIP file $zipRouteMessage to $destRouteMessage:";

    my $zip = Archive::Zip->new();
    my $readingStatus = $zip->read($realZipFilePath);

    if($readingStatus == AZ_FORMAT_ERROR) {
        $msgList->addError("$errorOpeningPrefix $zipRouteMessage is an invalid ZIP file");
        return 0;
    }

    if($readingStatus != AZ_OK) {
        $msgList->addError("$errorOpeningPrefix $!");
        return 0;
    }

    my $extractingStatus = $zip->extractTree("", $realDestFilePath);
    if($extractingStatus != AZ_OK) {
        $msgList->addError("$errorExtractingPrefix $!");
        return 0;
    }

    $msgList->addMessage("Extracted $zipRouteMessage to $destRouteMessage");

    return 1;
}

1;