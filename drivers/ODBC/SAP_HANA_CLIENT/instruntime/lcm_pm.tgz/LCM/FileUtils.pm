package LCM::FileUtils;

use strict;
use SDB::Install::SysVars;
use Cwd qw (realpath);
use Fcntl ':mode';
use File::Spec;
use File::Basename;
use File::stat;
use IO::File;
use SDB::Common::BuiltIn;
use SDB::Install::System qw(isDirectory);
use SDB::Install::DirectoryWalker;

our @ISA = qw (Exporter);
our @EXPORT = qw (	MyRealPath
					isEmptyDirectory
					createDirectory
					listDirectory
					getDirectoryOwnerUid
					readFile
					findInFile
					writeToFile
					deleteFile
					changeFileOwnership
					changeFilePermissions
					getFilesOwnedByUser
					getFilesOwnedByGroup
					getFilesOwnedByUserAndGroup
					getFileOwnership
					GetPermissions
					hasFileExecutePermissions
					isEmptyFile);

sub myRealPathWin {
    my $path = $_[0] ? Cwd::realpath( $_[0] ) : "";
    $path =~ s/\//\\/g;
    return $path;
}

sub MyRealPath;
*MyRealPath = $isWin ? \&myRealPathWin : \&Cwd::realpath;

sub isEmptyDirectory {
	my ($absoluteDirPath, $errorMessageList) = @_;
	my $dirHandle = undef;

	unless(-d $absoluteDirPath){
		_addErrorMessage("Invalid value '$absoluteDirPath'. Path '$absoluteDirPath' does not point to a directory", $errorMessageList);
		return undef;
	}

	unless(opendir($dirHandle, $absoluteDirPath)){
		_addErrorMessage("Failed to open directory '$absoluteDirPath' for reading : " . $!, $errorMessageList);
		return undef;
	}

	my @fileList = readdir($dirHandle);
	closedir($dirHandle);
	return scalar(@fileList) == 2 ? 1 : 0;	
}

sub isEmptyFile {
    my ($filePath, $errorMessageList) = @_;
    my $linesRef = readFile($filePath, $errorMessageList);
    return 1 if !defined $linesRef || scalar @{$linesRef} == 0;
    return 0;
}

# $fileMode must be an octal number (for example 0755) but NOT a string starting with zero
# does not modify properties of existing directories along the path
sub createDirectory {
	my ($absoluteDirPath, $fileMode, $uid, $gid, $isRecursive, $errorMessageList) = @_;
	my $builtIn = SDB::Common::BuiltIn->get_instance();
	my $parentDir = dirname($absoluteDirPath);

	if($isRecursive && !isDirectory($parentDir)) {
		return undef if !createDirectory($parentDir, $fileMode, $uid, $gid, $isRecursive, $errorMessageList);
	}

	my $wasCreated = $builtIn->mkdir($absoluteDirPath);
	my $mkdirErrorMessage = $!;

	if (!isDirectory($absoluteDirPath) || !$wasCreated) {
		_addErrorMessage("Failed to create directory '$absoluteDirPath': ${mkdirErrorMessage}", $errorMessageList);
		return 0;
	}

	if (!$builtIn->chmod($fileMode, $absoluteDirPath) ){
		_addErrorMessage("Failed to change permissions of directory '$absoluteDirPath'", $errorMessageList);
		return 0;
	}

	if (!$builtIn->chown($uid, $gid, $absoluteDirPath) ){
		_addErrorMessage("Failed to change ownership of directory '$absoluteDirPath'", $errorMessageList);
		return 0;
	}

	return 1;
}

sub listDirectory {
	my ($directory, $errorMessageList) = @_;
	my $dirHandle = undef;
	if(!opendir($dirHandle, $directory)){
		_addErrorMessage("Failed to open directory '$directory': " . $!, $errorMessageList);
		return undef;
	}
	my @fileList = readdir($dirHandle);
	closedir($dirHandle);
	return \@fileList;
}

sub getDirectoryOwnerUid {
    my ($path) = @_;
    return File::stat::stat($path)->uid() if -d $path;
    return undef;
}

sub readFile {
	my ($filePath, $errorMessageList) = @_;
	my $fh = IO::File->new($filePath, 'r');
	if(!defined $fh){
		_addErrorMessage("Failed to open file '$filePath' for reading: $!", $errorMessageList);
		return undef;
	}
	my @lines = $fh->getlines();
	if(!$fh->close()) {
		_addErrorMessage("Cannot close read file '$filePath': $!", $errorMessageList);
		return undef;
	}
	return \@lines;
}

sub findInFile {
	my ($filePath, $pattern, $errorMessageList) = @_;
	my $lines = readFile($filePath, $errorMessageList);
	if (!defined $lines) {
		_addErrorMessage("Failed to read file '$filePath': " . $!, $errorMessageList);
		return undef;
	}
	my $match = undef;
	for my $line (@$lines) {
		$match = $line if ($line =~ /$pattern/);
		last if (defined $match);
	}
	return $match;
}

sub deleteFile {
	my ($path, $errorMessageList) = @_;
    if(!unlink($path)){
    	_addErrorMessage("Deleting file '$path' failed: $!", $errorMessageList);
        return 0;
    }
    return 1;
}

sub changeFileOwnership {
	my ($filePath, $uid, $gid, $errorMessageList) = @_;
	my $builtIn = SDB::Common::BuiltIn->get_instance();

	if (!defined $uid) {
		$uid = -1;
	}

	if (!defined $gid) {
		$gid = -1;
	}

	if (!$builtIn->chown($uid, $gid, $filePath)) {
		_addErrorMessage("Could not chown '$filePath' to uid=$uid and gid=$gid: $!", $errorMessageList);
		return undef;
	}

	return 1;
}

# $fileMode must be an octal numer (for example 0755), but NOT a string
sub changeFilePermissions {
	my ($filePath, $fileMode, $errorMessageList) = @_;
	my $builtIn = SDB::Common::BuiltIn->get_instance();

	if (!defined $fileMode) {
		return undef;
	}

	if (!$builtIn->chmod($fileMode, $filePath)) {
		my $errMsg = sprintf("Could not chmod '%s' to mode '%o': %s", $filePath, $fileMode, $!);
		_addErrorMessage($errMsg, $errorMessageList);
		return undef;
	}

	return 1;
}

sub writeToFile {
	my ($filePath, $content, $mode, $uid, $gid, $errorMessageList, $shouldChangeFileOwnership, $shouldChangeFilePermissions) = @_;
	$shouldChangeFileOwnership //= 1;
	$shouldChangeFilePermissions //= 1;
	my $fileHandle = IO::File->new($filePath, 'w');

	if(!$fileHandle){
		_addErrorMessage("Failed to open file '$filePath' for writing: $!", $errorMessageList);
		return undef;
	}
	if(!$fileHandle->print($content)) {
		_addErrorMessage("Cannot write into file '$filePath': $!", $errorMessageList);
		return undef;
	}
	if(!$fileHandle->close()) {
		_addErrorMessage("Cannot close created file '$filePath': $!", $errorMessageList);
		return undef;
	}
	if($shouldChangeFileOwnership && !changeFileOwnership($filePath, $uid, $gid, $errorMessageList)) {
		return undef;
	}
	if($shouldChangeFilePermissions && !changeFilePermissions($filePath, $mode, $errorMessageList)) {
		return undef;
	}
	return 1;
}

sub _addErrorMessage {
	my ($message, $errorMessageList) = @_;
	if(defined($errorMessageList)){
		$errorMessageList->addError($message);
	}
}

# Format: 777
sub GetPermissions {
	my ($path) = @_;
	my $file = File::stat::stat($path);
	return undef if (!$file);
	my $mode = $file->mode();
	return sprintf "%03o", S_IMODE($mode);
}

sub getFilesOwnedByUser {
	my ($directoryPath, $targetUID, $msgLst) = @_;
	return getFilesOwnedByUserAndGroup($directoryPath, $targetUID, undef, $msgLst);
}

sub getFilesOwnedByGroup {
	my ($directoryPath, $targetGID, $msgLst) = @_;
	return getFilesOwnedByUserAndGroup($directoryPath, undef, $targetGID, $msgLst);
}

sub getFilesOwnedByUserAndGroup {
	my ($directoryPath, $targetUID, $targetGID, $msgLst) = @_;

	my @ownedFiles = ();
	my $dirWalker = SDB::Install::DirectoryWalker->new(
		sub {
			my ($fileUid, $fileGid) = getFileOwnership(File::Spec->catfile($_[3], $_[4]));

			return 1 if defined $targetGID && $fileGid != $targetGID;
			return 1 if defined $targetUID && $fileUid != $targetUID;

			push @ownedFiles, File::Spec->catfile($_[3], $_[4]);
		},
		undef, undef, undef, undef, undef, undef, undef, 0, 1
	);

	$dirWalker->setMsgLstContext([$msgLst, $msgLst]);
	$dirWalker->findAndProcess($directoryPath);

	my ($rootDirUID, $rootDirGID) = getFileOwnership($directoryPath);

	if (!defined $rootDirUID || !defined $rootDirGID) {
		_addErrorMessage("Could not get ownership of directory '$directoryPath'", $msgLst);
		return \@ownedFiles;
	}

	my $desiredRootUID = $targetUID // $rootDirUID;
	my $desiredRootGID = $targetGID // $rootDirGID;

	if (($rootDirUID == $desiredRootUID) && ($rootDirGID == $desiredRootGID)) {
		push @ownedFiles, $directoryPath;
	}

	return \@ownedFiles;
}

sub getFileOwnership {
	my ($filePath) = @_;
	return undef if !defined $filePath;

	my $statObj = File::stat::stat($filePath);
	return undef if !defined $statObj;

	return ($statObj->uid(), $statObj->gid());
}

sub hasFileExecutePermissions {
    my ($filePath, $uid, $gid) = @_;
    return 0 if(!$filePath);
    return 1 if(defined $uid && $uid == 0);
    my $file = File::stat::stat($filePath);
    return 0 if(! defined $file);
    my $mode = $file->mode();
    my $isExecutable = 0;

    if(defined $uid && $file->uid() == $uid){
        $isExecutable = ($mode & S_IXUSR);
    } elsif (defined $gid && $file->gid() == $gid){
        $isExecutable = ($mode & S_IXGRP);
    } else {
        $isExecutable = ($mode & S_IXOTH);
    }

    return $isExecutable;
}

1;
