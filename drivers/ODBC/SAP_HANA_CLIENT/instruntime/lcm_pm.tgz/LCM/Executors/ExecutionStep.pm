package LCM::Executors::ExecutionStep;

# This class is used in LCM::Gui::Dialogs::FinalizeDialog to represent execution step (e.g. AddHosts scenario)
sub new{
	my ($class) = @_;
	my $self = {};
	bless $self, $class;
	
	return $self;
}

sub getName{
	my ($self) = @_;
	return $self->{name};
}

sub setName{
	$_[0]->{name} = $_[1];
}

sub getStatus{
	my ($self) = @_;
	return $self->{status};
}

sub setStatus{
	$_[0]->{status} = $_[1];
}

sub getLogLocation{
	my ($self) = @_;
	return $self->{logLocation};
}

sub setLogLocation{
	$_[0]->{logLocation} = $_[1];
}

sub getWarnings{
	my ($self) = @_;
	return $self->{warnings};
	
}

sub setWarnings{
	$_[0]->{warnings} = $_[1];
}

1;
