package LCM::Component::Installed::XS::XS2Sidadm;
use parent LCM::Component::Installed::XS2;

use SDB::Install::Globals qw($gOperationDeleteXSADirectories);

sub deleteXSPostUninstallData{
	my ( $self, $instconfig, $sapSystem ) = @_;
	my $optionsMap =  {
		SAPMNT => $instconfig->getValue('Target'),
        SID => $instconfig->getSID(),
    };

    my $exitCode = $self->_executeThroughSHAOperation($instconfig, $gOperationDeleteXSADirectories, $optionsMap, undef, 1, 'Delete XSA Directories');
    return $exitCode if (! defined($exitCode) || $exitCode != 0);
}

1;