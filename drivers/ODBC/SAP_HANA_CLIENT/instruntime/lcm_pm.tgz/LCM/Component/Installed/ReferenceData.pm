package LCM::Component::Installed::ReferenceData;

use strict;

use base 'LCM::Component::Installed';

sub canSelectComponent{
    return 0;
}

sub uninstallComponent{
    my ( $self, $instconfig ) = @_;
    #TODO
    return 1;
}

sub getNumberOfExpectedOutputLines{
    return 15;
}

sub getSlppLogFileName {
	return 'refdata.log'
}

1;
