package LCM::Component::Installed::XS2Application;

use strict;
use base 'LCM::Component::Installed';
use SDB::Install::Globals qw($gXSASpaceSAP $gKeynameCockpitApp);

# Override
sub uninstallComponent {
	# Uninstallation of XS2 Apps through hdblcm is not supported
    return undef;
}

sub setRegistryID {
    my ($self, $registryID) = @_;
    $self->{registryID} = $registryID;
}

sub getRegistryID {
    my ($self) = @_;
    return $self->{registryID};
}

sub isCockpit {
    my ($self) = @_;
    return lc($self->getComponentKeyName()) eq lc($gKeynameCockpitApp) ? 1 : 0;
}

1;
