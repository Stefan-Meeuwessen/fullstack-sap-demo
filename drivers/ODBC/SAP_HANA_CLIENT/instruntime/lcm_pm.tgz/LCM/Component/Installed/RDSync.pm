package LCM::Component::Installed::RDSync;
use base 'LCM::Component::Installed';
use strict;
use warnings;

use SDB::Install::Globals qw($gProductNameRDSync);

sub getComponentName {
	return $gProductNameRDSync;
}

sub getDeprecatedInfo {
    return "See SAP Note 2641466 for additional details.";
}

1;
