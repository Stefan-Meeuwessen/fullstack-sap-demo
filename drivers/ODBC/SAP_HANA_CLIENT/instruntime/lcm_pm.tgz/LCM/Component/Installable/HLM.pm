package LCM::Component::Installable::HLM;

use SDB::Install::Globals qw ($gProductName);
use File::Basename qw (dirname);
use strict;

use base qw (LCM::Component::Installable);

sub getComponentName {
	return "$gProductName Lifecycle Manager";
}

1;
