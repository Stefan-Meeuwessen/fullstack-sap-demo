package LCM::Component::Registrable;

use strict;
use Exporter;
use base qw (Exporter);

our $RETURN_CODE_SUCCESS = 1;
our $RETURN_CODE_ERROR = undef;

our @EXPORT_OK = qw(
    $RETURN_CODE_SUCCESS
    $RETURN_CODE_ERROR
    );
    
sub new {
    # Override via inheritance
}

sub register{
	# Override via inheritance  
}

sub unregister{
    # Override via inheritance  
}

return 1;