package LCM::ComponentManager::PrintDetectedComponentsOutputHandler;

use strict;
use warnings;

use parent qw(LCM::ComponentManager::LogDetectedComponentsOutputHandler);

sub startLog {
    my($self, $msg) = @_;
    return if($self->{_logStarted});
    $self->{_msgObj} = $self->log($msg);
    $self->{_logStarted} = 1;
}

sub endLog {
    my($self, $msg) = @_;
    $self->{_msgObj}->endMessage($msg);
}

sub log {
    my($self, $msg) = @_;
    $self->getMsgLst()->addProgressMessage($msg);
}

1;
