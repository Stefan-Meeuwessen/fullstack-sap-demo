package LCM::DirectoryUtils;

use strict;
use warnings;

use SDB::Install::System qw(isDirectory setFilePermissions);
use SDB::Install::DirectoryWalker;

use parent qw(Exporter);

our @EXPORT = qw(
    changePermissionsRecursively
);

sub changePermissionsRecursively {
    my ($permissions, $path, $msglst) = @_;
    return undef if !defined $permissions || !defined $path;

    my $initialMessage = sprintf("Setting permissions recursively for '%s'", $path);
    my $processingCallback = $permissions;

    if (ref($permissions) ne 'CODE') {
        $initialMessage .= sprintf(" to %o", $permissions);
        $processingCallback = sub {
            my ($path, $msglst) = @_;
            return setFilePermissions($permissions, $path, $msglst);
        }
    }

    my $msg = $msglst->addMessage($initialMessage);

    my $rc = $processingCallback->($path, $msg->getSubMsgLst());
    my $dirWalker = SDB::Install::DirectoryWalker->new(undef, undef, undef, undef, undef, undef, sub {
        my ($globalRoot, $relEntry) = ($_[3], $_[4]);
        my $filePath = File::Spec->catfile($globalRoot, $relEntry);
        return $processingCallback->($filePath, $msg->getSubMsgLst());
    }, undef, undef, 1, 1);

    $rc &&= defined $dirWalker->findAndProcess($path);

    if(!$rc) {
        $msglst->addError("Setting permissions recursively for '$path' failed");
        return undef;
    }

    return 1;
}

1;