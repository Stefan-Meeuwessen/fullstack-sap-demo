package LCM::ActionsDetector::NotApplicableActionReason;

use strict;
use warnings;

sub new {
    my ($class, $message, $isVisible) = @_;
    my $self = bless({}, $class);
    $self->{_message} = $message;
    $self->{_isVisible} = $isVisible;
    return $self;
}

sub getMessage {
    my ($self) = @_;
    return $self->{_message};
}

sub isVisible {
    my ($self) = @_;
    return $self->{_isVisible};
}

1;