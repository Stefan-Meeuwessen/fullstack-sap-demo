package LCM::ActionsDetector::Action::ConfigureSLD;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';
use SDB::Install::Globals qw($gFlavourPlatform $gFlavourCockpit);


sub getSupportedFlavours {
    my ($self) = @_;
    return [ $gFlavourPlatform, $gFlavourCockpit ];
}

sub getKey {
    my ($self) = @_;
    return 'ConfigureSLD';
}

sub getBatchKey {
    my ($self) = @_;
    return 'configure_sld';
}

sub getUIString {
    my ($self) = @_;
    return "Configure System Landscape Directory Registration";
}

1;