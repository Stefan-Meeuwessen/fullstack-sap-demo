package LCM::ActionsDetector::Action::UpdateComponentList;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';
use SDB::Install::Globals qw($gFlavourPlatform $gFlavourCockpit);


sub getSupportedFlavours {
    my ($self) = @_;
    return [ $gFlavourPlatform, $gFlavourCockpit ];
}

sub getKey {
    my ($self) = @_;
    return 'UpdateComponentList';
}

sub getBatchKey {
    my ($self) = @_;
    return 'update_component_list';
}

sub getUIString {
    my ($self) = @_;
    return "Update Component List";
}

1;