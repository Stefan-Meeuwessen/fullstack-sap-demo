package LCM::ActionsDetector::Action::PrintComponentList;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';
use SDB::Install::Globals qw($gFlavourPlatform);


sub getSupportedFlavours {
    return [ $gFlavourPlatform ];
}

sub getKey {
    my ($self) = @_;
    return 'PrintComponentList';
}

sub getBatchKey {
    my ($self) = @_;
    return 'print_component_list';
}

sub getUIString {
    my ($self) = @_;
    return "Print Component List";
}

sub supportsGUI {
    return 0;
}

1;