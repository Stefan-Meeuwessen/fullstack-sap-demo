package LCM::ActionsDetector::Action::UpdateHost;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';


sub getKey {
    my ($self) = @_;
    return 'UpdateHost';
}

sub getBatchKey {
    my ($self) = @_;
    return 'update_host';
}

sub getUIString {
    my ($self) = @_;
    return sprintf("Update the %s Instance Host integration", $self->_getProductName());
}

sub supportsGUI {
    return 0;
}

1;