package LCM::ActionsDetector::Action::PrintDetectedComponents;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';

sub getKey {
    my ($self) = @_;
    return 'PrintDetectedComponents';
}

sub getBatchKey {
    my ($self) = @_;
    return 'print_detected_components';
}

sub getUIString {
    my ($self) = @_;
    return "Print Detected Components";
}

sub supportsGUI {
    return 0;
}

1;