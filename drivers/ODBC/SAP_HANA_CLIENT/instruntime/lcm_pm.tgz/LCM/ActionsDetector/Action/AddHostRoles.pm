package LCM::ActionsDetector::Action::AddHostRoles;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';
use SDB::Install::Globals qw($gFlavourPlatform);


sub getSupportedFlavours {
    return [ $gFlavourPlatform ];
}

sub getKey {
    my ($self) = @_;
    return 'AddHostRoles';
}

sub getBatchKey {
    my ($self) = @_;
    return 'add_host_roles';
}

sub getUIString {
    my ($self) = @_;
    return "Add Host Roles";
}

1;