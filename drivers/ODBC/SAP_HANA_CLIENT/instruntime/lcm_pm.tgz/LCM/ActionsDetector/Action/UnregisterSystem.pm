package LCM::ActionsDetector::Action::UnregisterSystem;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';


sub getKey {
    my ($self) = @_;
    return 'UnregisterSystem';
}

sub getBatchKey {
    my ($self) = @_;
    return 'unregister_system';
}

sub getUIString {
    my ($self) = @_;
    return sprintf("Unregister the %s System", $self->_getProductName());
}

sub requiresRoot {
    return 1;
}

1;