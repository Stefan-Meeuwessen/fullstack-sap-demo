package LCM::ActionsDetector::Action::RemoveHostRoles;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';
use SDB::Install::Globals qw($gFlavourPlatform);


sub getSupportedFlavours {
    return [ $gFlavourPlatform ];
}

sub getKey {
    my ($self) = @_;
    return 'RemoveHostRoles';
}

sub getBatchKey {
    my ($self) = @_;
    return 'remove_host_roles';
}

sub getUIString {
    my ($self) = @_;
    return "Remove Host Roles";
}

1;