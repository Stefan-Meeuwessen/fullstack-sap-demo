package LCM::ActionsDetector::Action::ExtractComponents;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';


sub getKey {
    my ($self) = @_;
    return 'ExtractComponents';
}

sub getBatchKey {
    my ($self) = @_;
    return 'extract_components';
}

sub getUIString {
    my ($self) = @_;
    return "Extract Components";
}

sub supportsGUI {
    return 0;
}

1;