package LCM::ActionsDetector::Action::CheckInstallation;

use strict;
use warnings;
use parent 'LCM::ActionsDetector::Action';


sub getKey {
    my ($self) = @_;
    return 'CheckInstallation';
}

sub getBatchKey {
    my ($self) = @_;
    return 'check_installation';
}

sub getUIString {
    my ($self) = @_;
    return sprintf("Check %s Installation", $self->_getProductName());
}

sub supportsGUI {
    return 0;
}

1;